import { useState, useEffect, useRef } from "react";
import {
  Home, Calendar, CreditCard, Sparkles, Users, User,
  Bell, Settings, ShoppingCart, Coffee,
  Zap, Package, Film, Music, Pill, Shirt,
  TrendingUp, Shield, CheckCircle,
  Target, PiggyBank, DollarSign,
  ShoppingBag, Flame, Star, Car, BarChart2
} from "lucide-react";

const STYLES = `
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
@keyframes fadeUp    { from{opacity:0;transform:translateY(22px)}  to{opacity:1;transform:translateY(0)} }
@keyframes fadeIn    { from{opacity:0}                              to{opacity:1} }
@keyframes slideUp   { from{opacity:0;transform:translateY(10px)}  to{opacity:1;transform:translateY(0)} }
@keyframes slideIn   { from{opacity:0;transform:translateX(-14px)} to{opacity:1;transform:translateX(0)} }
@keyframes pulse     { 0%,100%{opacity:1} 50%{opacity:0.45} }
@keyframes shimmer   { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
@keyframes mintGlow  { 0%,100%{box-shadow:0 0 0 0 rgba(0,214,143,0)} 50%{box-shadow:0 0 60px 8px rgba(0,214,143,0.12)} }
@keyframes goldGlow  { 0%,100%{box-shadow:0 0 0 0 rgba(240,196,66,0)} 50%{box-shadow:0 0 60px 8px rgba(240,196,66,0.10)} }
@keyframes ringPulse { 0%{transform:scale(1);opacity:0.7} 100%{transform:scale(2.4);opacity:0} }
@keyframes floatUp   { 0%{transform:translateY(0)} 50%{transform:translateY(-4px)} 100%{transform:translateY(0)} }
@keyframes numberIn  { from{opacity:0;transform:translateY(8px) scale(0.97)} to{opacity:1;transform:translateY(0) scale(1)} }
@keyframes gradShift { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
* { -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale; box-sizing:border-box; }
::-webkit-scrollbar { width:0; background:transparent; }
input,button,select,textarea { font-family:inherit; }
`;


// ─── COUNTRY CONFIG ────────────────────────────────────────────────────────────
const CC = {
  CA:{
    currency:"CAD", symbol:"$", flag:"🇨🇦", name:"Canada",
    locale:"en-CA",
    banks:[
      {name:"TD Bank",color:"#00B140"},{name:"RBC",color:"#003168"},
      {name:"Scotiabank",color:"#DA1710"},{name:"BMO",color:"#0079C1"},
      {name:"CIBC",color:"#D31145"},{name:"Tangerine",color:"#E46C00"},
      {name:"EQ Bank",color:"#00A94F"},{name:"Desjardins",color:"#00713C"},
      {name:"Simplii Financial",color:"#E31837"},{name:"National Bank",color:"#E31837"},
      {name:"ATB Financial",color:"#0066B2"},{name:"PC Financial",color:"#FF6600"},
    ],
    incomeTypes:[
      ["employment","💼 Employment / T4"],["selfemployed","🧾 Self-Employed / T4A"],
      ["cpp","🏛️ CPP / Pension"],["ei","📋 EI Benefits"],
      ["odsp","♿ ODSP / Ontario Works"],["ccb","👶 Canada Child Benefit"],
      ["rental","🏠 Rental Income"],["gig","🚗 Gig / Freelance"],["other","➕ Other"],
    ],
    debtTypes:["Credit Card","Line of Credit","HELOC","Car Loan","OSAP / Student Loan","Personal Loan","Mortgage","Buy Now Pay Later","Other"],
    taxTips:[
      {title:"RRSP Contribution",body:"Every RRSP dollar reduces your taxable income. At a 30% marginal rate, putting in $5,000 gets you ~$1,500 back at tax time. Deadline is March 1.",savings:"Up to 33%",flag:"🇨🇦",priority:"high",action:"Check My RRSP Room"},
      {title:"TFSA — You're Probably Under-Using It",body:"Your TFSA isn't just for savings — it's for investing. Any growth inside is 100% tax-free forever. If you opened one at 18, you may have $75,000+ of contribution room sitting unused.",savings:"Tax-free growth",flag:"🇨🇦",priority:"high",action:"Calculate My Room"},
      {title:"FHSA (First Home Savings Account)",body:"If you've never owned a home, you can contribute up to $8,000/year and get a tax deduction — like an RRSP. Unused room carries forward. Withdraw tax-free to buy your first home.",savings:"Up to $8,000/yr",flag:"🇨🇦",priority:"high",action:"Open an FHSA"},
      {title:"GST/HST Credit",body:"Filing your taxes means CRA automatically checks if you qualify for quarterly GST/HST credits. Under ~$50k income? You likely qualify and may not know it. File every year even if you owe nothing.",savings:"Up to $519/yr",flag:"🇨🇦",priority:"medium",action:"File Your Taxes"},
      {title:"Canada Child Benefit (CCB)",body:"Tax-free monthly payments if you have children under 18. A family earning $50k with two kids can get $12,000+/year. Apply on CRA My Account or when registering the birth.",savings:"Up to $7,787/child",flag:"🇨🇦",priority:"high",action:"Apply on CRA"},
      {title:"Home Office Deduction",body:"Work from home? Even employees can claim a flat $2/day (up to $500) without receipts. Self-employed? Claim actual rent, internet, hydro proportionally.",savings:"$200–$1,200",flag:"🇨🇦",priority:"medium",action:"Track Home Office Days"},
      {title:"Ontario Trillium Benefit",body:"Ontario residents: combines the Ontario Sales Tax Credit, Ontario Energy Credit, and Northern Ontario Energy Credit into one monthly payment. Low-to-mid income earners often miss this.",savings:"Up to $1,421/yr",flag:"🏙️ ON",priority:"medium",action:"Apply on CRA"},
      {title:"Disability Tax Credit (DTC)",body:"If you or a dependent has a severe disability, the DTC provides up to ~$1,300/year in federal tax credits, plus retroactive claims. Often missed — a doctor fills out T2201.",savings:"Up to $1,300/yr",flag:"🇨🇦",priority:"medium",action:"Get T2201 Form"},
      {title:"Child Care Expense Deduction",body:"Daycare, after-school programs, summer camp — most childcare costs are deductible from the lower-income spouse's return. Families earning $50k often leave $2,000–$4,000 on the table.",savings:"$1,200–$4,000",flag:"🇨🇦",priority:"high",action:"Gather Receipts"},
      {title:"RESP — Free Government Money",body:"Open an RESP for your child and the government adds 20% on the first $2,500/year = $500 free per child. Canada Learning Bond adds another $500 for lower-income families.",savings:"$500–$1,000/yr free",flag:"🇨🇦",priority:"high",action:"Open an RESP"},
      {title:"Working Income Tax Benefit (CWB)",body:"Working but earning under ~$36k? CRA may owe you a refundable tax credit just for filing. Many low-income workers miss this entirely.",savings:"Up to $1,428",flag:"🇨🇦",priority:"medium",action:"Check Eligibility"},
    ],
    learnCards:[
      {emoji:"🏦",title:"TFSA vs RRSP — The Real Difference",body:"RRSP lowers your taxes now but you pay tax when you withdraw. TFSA has no upfront deduction but all growth and withdrawals are 100% tax-free. If you're in a low tax bracket now, use TFSA first. If you're in a high bracket, RRSP first.",key:"Low income now → TFSA. High income now → RRSP."},
      {emoji:"🏠",title:"The FHSA: Best Account Most Canadians Don't Have",body:"The First Home Savings Account opened in 2023. You get an RRSP-style deduction going in AND tax-free withdrawals for a first home. Up to $40,000 lifetime room. If you're not a homeowner, this should be your first account.",key:"Open an FHSA before your RRSP if you want to buy a home."},
      {emoji:"👶",title:"Canada Child Benefit vs US Child Tax Credit",body:"The CCB is more generous than most Canadians realize. A single parent earning $40k with two kids under 6 can receive over $14,000/year. Unlike US credits, CCB is completely tax-free and paid monthly.",key:"Apply at birth — retroactive claims are possible but painful."},
      {emoji:"📋",title:"What EI Actually Covers",body:"Employment Insurance isn't just for job loss. It also covers maternity (15 weeks), parental (up to 35 weeks standard or 61 weeks extended), sickness (26 weeks), and compassionate care. Many employees don't claim what they're entitled to.",key:"Know your EI benefits before you need them."},
      {emoji:"💳",title:"Why minimum payments are a trap",body:"If you owe $3,000 at 20% and pay only the minimum, it takes 8+ years and costs nearly $3,000 extra. You buy everything twice.",key:"Never just pay the minimum."},
      {emoji:"🆘",title:"The emergency fund rule",body:"One car repair without savings = credit card debt at 20%. A $1,000 cushion breaks that cycle. In Canada, keep it in a TFSA high-interest savings account.",key:"Build $1,000 in a TFSA HISA first."},
    ],
    retirementAccounts:[
      {id:"rrsp",name:"RRSP",fullName:"Registered Retirement Savings Plan",icon:"🏦",color:"#2E8B2E",annualLimit:"18% of income (max $31,560)",taxNote:"Contributions deductible. Withdrawals taxed as income.",tip:"Contribute in high-income years. Use spousal RRSP for income splitting."},
      {id:"tfsa",name:"TFSA",fullName:"Tax-Free Savings Account",icon:"🛡️",color:"#2FADA6",annualLimit:"$7,000 (2024). Unused room accumulates.",taxNote:"No deduction on contribution. All growth and withdrawals tax-free.",tip:"Invest in ETFs inside your TFSA — don't just park cash."},
      {id:"fhsa",name:"FHSA",fullName:"First Home Savings Account",icon:"🏠",color:"#CFA03E",annualLimit:"$8,000/yr (max $40,000 lifetime)",taxNote:"Deductible going in. Tax-free withdrawal for first home purchase.",tip:"Best account for first-time buyers. Open even if you're not buying immediately — room accumulates."},
      {id:"resp",name:"RESP",fullName:"Registered Education Savings Plan",icon:"👶",color:"#8A5FC8",annualLimit:"$2,500/yr to maximize CESG grant",taxNote:"No deduction. Government adds 20% (CESG) on first $2,500/yr.",tip:"Even $2,500/yr gets $500 free from government. Start at birth."},
    ],
    benefitsChecker:[
      {name:"Canada Child Benefit",icon:"👶",eligible:"Has children under 18",amount:"Up to $7,787/child under 6",apply:"CRA My Account",url:"https://canada.ca/ccb"},
      {name:"GST/HST Credit",icon:"🛒",eligible:"Under ~$50k income",amount:"Up to $519/yr",apply:"File your taxes",url:"https://canada.ca/gst-credit"},
      {name:"Ontario Trillium Benefit",icon:"🏙️",eligible:"Ontario residents, low-mid income",amount:"Up to $1,421/yr",apply:"ON-BEN form with taxes",url:"https://canada.ca/trillium"},
      {name:"Canada Workers Benefit",icon:"💼",eligible:"Working, under ~$36k",amount:"Up to $1,428",apply:"Schedule 6 with taxes",url:"https://canada.ca/cwb"},
      {name:"CERB / CRB Replacements",icon:"📋",eligible:"Income disruption",amount:"Varies",apply:"CRA My Account",url:"https://canada.ca/ei"},
      {name:"Disability Tax Credit",icon:"♿",eligible:"Severe disability",amount:"~$1,300 credit",apply:"T2201 with doctor",url:"https://canada.ca/dtc"},
    ],
    creditBureaus:["Equifax (Borrowell — free)","TransUnion (Credit Karma — free)"],
    emergencyMonths:3,
    healthcareNote:"Healthcare is covered — emergency fund is for income disruption, not medical bills.",
  },
  US:{
    currency:"USD", symbol:"$", flag:"🇺🇸", name:"United States",
    locale:"en-US",
    banks:[
      {name:"Chase",color:"#117ACA"},{name:"Bank of America",color:"#E31837"},
      {name:"Wells Fargo",color:"#D71E28"},{name:"Citi",color:"#003B8E"},
      {name:"Capital One",color:"#D03027"},{name:"Ally Bank",color:"#5A1F8E"},
      {name:"Chime",color:"#00D062"},{name:"SoFi",color:"#0F3D5C"},
      {name:"Discover",color:"#F76400"},{name:"US Bank",color:"#002B6C"},
      {name:"PNC",color:"#CC0000"},{name:"TD Bank US",color:"#00B140"},
    ],
    incomeTypes:[
      ["employment","💼 W2 Employment"],["selfemployed","🧾 Self-Employed / 1099"],
      ["socialsecurity","🏛️ Social Security / SSI"],["disability","♿ SSDI / Disability"],
      ["childsupport","👶 Child Support / Alimony"],["gig","🚗 Gig / Freelance"],
      ["rental","🏠 Rental Income"],["investment","📈 Investment / Dividends"],["other","➕ Other"],
    ],
    debtTypes:["Credit Card","Student Loan (Federal)","Student Loan (Private)","Medical Debt","Car Loan","Personal Loan","Mortgage","HELOC","Payday Loan","Buy Now Pay Later","Other"],
    taxTips:[
      {title:"Earned Income Tax Credit (EITC)",body:"One of the most under-claimed credits in America. Under ~$63k with qualifying children? You could get up to $7,430 back — even if you owe nothing. Must file to claim.",savings:"Up to $7,430",flag:"🇺🇸",priority:"high",action:"Check EITC Eligibility"},
      {title:"Child Tax Credit",body:"Up to $2,000 per qualifying child under 17. Partially refundable — meaning you can get money back even if you owe nothing. File even if your income is low.",savings:"$2,000/child",flag:"🇺🇸",priority:"high",action:"Claim on Schedule 8812"},
      {title:"401(k) — Get the Full Match First",body:"If your employer matches 401(k) contributions, not contributing enough to get the full match is leaving free money on the table. A 4% match on $50k = $2,000/year you're giving up.",savings:"Up to $23,000/yr",flag:"🇺🇸",priority:"high",action:"Increase 401k Contributions"},
      {title:"HSA: The Triple Tax Advantage",body:"If you have a high-deductible health plan, an HSA lets you contribute pre-tax, grow tax-free, and withdraw tax-free for medical expenses. It's legally the most tax-advantaged account available.",savings:"Up to $4,150/yr",flag:"🇺🇸",priority:"high",action:"Open an HSA"},
      {title:"Roth IRA: Tax-Free Retirement",body:"Under $146k single / $230k married? You can contribute $7,000/year to a Roth IRA. You pay tax now, but all growth and withdrawals are 100% tax-free in retirement.",savings:"$7,000/yr tax-free",flag:"🇺🇸",priority:"high",action:"Open a Roth IRA"},
      {title:"Student Loan Interest Deduction",body:"Paying student loans? You may be able to deduct up to $2,500 of interest per year, reducing taxable income directly — even without itemizing.",savings:"Up to $2,500",flag:"🇺🇸",priority:"medium",action:"Find 1098-E Form"},
      {title:"Child & Dependent Care Credit",body:"Paying for daycare, after-school, or a caregiver while you work? You can claim 20–35% of up to $3,000 in care expenses as a tax credit — not just a deduction.",savings:"$600–$1,050",flag:"🇺🇸",priority:"medium",action:"Track Care Receipts"},
      {title:"Saver's Credit",body:"Low-to-mid income and contributing to a 401k or IRA? The Saver's Credit gives you up to 50% of your contribution back as a tax credit. Under $36k single? You likely qualify.",savings:"Up to $1,000",flag:"🇺🇸",priority:"medium",action:"Check Form 8880"},
      {title:"American Opportunity Tax Credit",body:"Paying for the first 4 years of college? You can claim up to $2,500/year per student — and 40% is refundable even if you owe nothing.",savings:"Up to $2,500/yr",flag:"🇺🇸",priority:"medium",action:"Claim on Form 8863"},
      {title:"Medical Expense Deduction",body:"Medical expenses exceeding 7.5% of your AGI are deductible if you itemize. For Americans with significant medical debt, this can mean thousands back.",savings:"Varies",flag:"🇺🇸",priority:"low",action:"Track Medical Receipts"},
      {title:"Home Office Deduction",body:"Self-employed and work from home? The simplified method allows $5 per square foot (up to 300 sq ft = $1,500). No complex calculations needed.",savings:"Up to $1,500",flag:"🇺🇸",priority:"medium",action:"Measure Your Office"},
    ],
    learnCards:[
      {emoji:"🏦",title:"401(k) vs Roth IRA: Which First?",body:"Your 401(k) lowers taxes now — great if you're in a high bracket. A Roth IRA gives tax-free income in retirement — great if you're younger or lower income. Rule of thumb: get the full 401k employer match first, then max your Roth IRA, then go back to the 401k.",key:"Always get the full employer match first. It's a 50–100% instant return."},
      {emoji:"🏥",title:"The Emergency Fund is Different in the US",body:"Unlike Canada, a medical emergency in the US can mean a $10,000–$50,000 bill. Your emergency fund isn't just for job loss — it's healthcare insurance. Most financial planners recommend 6 months of expenses, not 3.",key:"Aim for 6 months of expenses, not 3."},
      {emoji:"📋",title:"Medical Debt: Know Your Rights",body:"Medical debt under $500 was removed from credit reports in 2023. Negotiate bills before paying — hospitals routinely accept 40–60 cents on the dollar. Never pay full price without asking for a discount.",key:"Always negotiate medical bills before paying."},
      {emoji:"🎓",title:"Federal vs Private Student Loans",body:"Federal loans have income-driven repayment, deferment, and forgiveness programs. Private loans have none of these protections. If you have both, pay private first — federal loans have a safety net.",key:"Never refinance federal loans to private. You lose your safety net."},
      {emoji:"💳",title:"Why minimum payments are a trap",body:"If you owe $3,000 at 20% and pay only the minimum, it takes 8+ years and costs nearly $3,000 extra. You buy everything twice.",key:"Never just pay the minimum."},
      {emoji:"🆘",title:"The emergency fund rule",body:"Medical emergencies are the #1 cause of bankruptcy in America. A $1,000 cushion in a high-yield savings account (4–5% APY) breaks the cycle of borrowing.",key:"Keep your emergency fund in a high-yield savings account."},
    ],
    retirementAccounts:[
      {id:"401k",name:"401(k)",fullName:"Employer Retirement Plan",icon:"🏦",color:"#2E8B2E",annualLimit:"$23,000/yr ($30,500 if 50+)",taxNote:"Traditional: contributions pre-tax, withdrawals taxed. Roth 401k: after-tax contributions, tax-free withdrawals.",tip:"Always contribute enough to get the full employer match — it's free money."},
      {id:"roth",name:"Roth IRA",fullName:"Individual Retirement Account",icon:"🛡️",color:"#2FADA6",annualLimit:"$7,000/yr ($8,000 if 50+). Phaseout at $146k+",taxNote:"After-tax contributions. All growth and qualified withdrawals 100% tax-free.",tip:"Open early — the tax-free compounding over decades is massive. Use Fidelity or Vanguard."},
      {id:"hsa",name:"HSA",fullName:"Health Savings Account",icon:"🏥",color:"#CFA03E",annualLimit:"$4,150 single / $8,300 family (2024)",taxNote:"Triple tax advantage: pre-tax in, tax-free growth, tax-free for medical expenses.",tip:"After 65, HSA funds can be used for anything (taxed like a 401k). Best account in the US tax code."},
      {id:"529",name:"529 Plan",fullName:"Education Savings Account",icon:"🎓",color:"#8A5FC8",annualLimit:"No annual limit. $18k/yr gift tax exclusion.",taxNote:"State deduction varies. Federal tax-free growth and withdrawals for education.",tip:"Start when kids are young. Some states give immediate tax deductions."},
    ],
    benefitsChecker:[
      {name:"Earned Income Tax Credit",icon:"💰",eligible:"Working, under ~$63k",amount:"Up to $7,430",apply:"File taxes (IRS Free File)",url:"https://irs.gov/eitc"},
      {name:"SNAP (Food Stamps)",icon:"🛒",eligible:"Low income households",amount:"$291/mo average",apply:"Benefits.gov",url:"https://benefits.gov"},
      {name:"Medicaid / CHIP",icon:"🏥",eligible:"Low-income adults and children",amount:"Free/low-cost healthcare",apply:"Healthcare.gov",url:"https://healthcare.gov"},
      {name:"Child Tax Credit",icon:"👶",eligible:"Children under 17",amount:"Up to $2,000/child",apply:"File taxes",url:"https://irs.gov/ctc"},
      {name:"LIHEAP Energy Assistance",icon:"⚡",eligible:"Low income, utility hardship",amount:"Varies by state",apply:"Benefits.gov",url:"https://benefits.gov"},
      {name:"WIC Program",icon:"🍼",eligible:"Pregnant/postpartum, children under 5",amount:"Food + support",apply:"Local health dept",url:"https://wic.fns.usda.gov"},
    ],
    creditBureaus:["Equifax","Experian","TransUnion — all three count for FICO"],
    emergencyMonths:6,
    healthcareNote:"Medical emergencies are the #1 cause of US bankruptcy. 6 months of expenses is the minimum.",
  },
};

const C = {
  // ── Backgrounds ─────────────────────────────────────────────
  bg:         "#060A0E",
  surface:    "#0C1219",
  card:       "#0F1720",
  cardAlt:    "#141F2A",
  // ── Text ────────────────────────────────────────────────────
  cream:      "#EDE8E1",
  muted:      "rgba(237,232,225,0.38)",
  mutedHi:    "rgba(237,232,225,0.65)",
  // ── Mint green (primary positive) ───────────────────────────
  green:      "#00D68F",
  greenBright:"#00EFA0",
  greenDim:   "rgba(0,214,143,0.11)",
  // ── Gold (attention / money) ─────────────────────────────────
  gold:       "#E8B84B",
  goldBright: "#F5CC6A",
  goldDim:    "rgba(232,184,75,0.11)",
  // ── Red (danger) ────────────────────────────────────────────
  red:        "#FF4F6A",
  redBright:  "#FF6B84",
  redDim:     "rgba(255,79,106,0.11)",
  // ── Blue ─────────────────────────────────────────────────────
  blue:       "#4DA8FF",
  blueBright: "#6DBCFF",
  blueDim:    "rgba(77,168,255,0.11)",
  // ── Teal ─────────────────────────────────────────────────────
  teal:       "#00C8E0",
  tealBright: "#22D8EE",
  tealDim:    "rgba(0,200,224,0.11)",
  // ── Orange ──────────────────────────────────────────────────
  orange:     "#FF8C42",
  orangeBright:"#FFA060",
  orangeDim:  "rgba(255,140,66,0.11)",
  // ── Purple ──────────────────────────────────────────────────
  purple:     "#9B7DFF",
  purpleBright:"#B09AFF",
  purpleDim:  "rgba(155,125,255,0.11)",
  // ── Pink ────────────────────────────────────────────────────
  pink:       "#FF6B9D",
  pinkBright: "#FF85AE",
  pinkDim:    "rgba(255,107,157,0.11)",
  // ── Borders & hero ──────────────────────────────────────────
  border:     "rgba(255,255,255,0.07)",
  borderHi:   "rgba(255,255,255,0.15)",
  heroGreen:  "linear-gradient(160deg,#061510 0%,#0A1E14 45%,#060A0E 100%)",
  heroRed:    "linear-gradient(160deg,#160609 0%,#1E0A0E 45%,#060A0E 100%)",
};


const CAT_ICON = {
  "Groceries":      "cart",
  "Coffee & Dining":"coffee",
  "Income":         "income",
  "Gas & Transport":"gas",
  "Subscriptions":  "film",
  "Shopping":       "bag",
  "Health":         "pill",
  "Utilities":      "zap",
  "Investments":    "chartUp",
  "Default":        "card",
};
function txnIcon(txn){return CAT_ICON[txn.cat]||"card";}

const MOCK_TXN = [
  {id:"t1", date:"2026-03-06",name:"Loblaws",         amount:67.43,  cat:"Groceries",      icon:"🛒",color:"#2E8B2E",dow:4},
  {id:"t2", date:"2026-03-06",name:"Tim Hortons",      amount:4.85,   cat:"Coffee & Dining",icon:"☕",color:"#D97A3A",dow:4},
  {id:"t3", date:"2026-03-06",name:"Tim Hortons",      amount:5.10,   cat:"Coffee & Dining",icon:"☕",color:"#D97A3A",dow:4},
  {id:"t4", date:"2026-03-05",name:"Payroll Deposit",  amount:-DEMO.income,cat:"Income",         icon:"💰",color:"#6FE494",dow:3},
  {id:"t5", date:"2026-03-05",name:"Shell Gas",        amount:62.10,  cat:"Gas & Transport",icon:"⛽",color:"#CFA03E",dow:3},
  {id:"t6", date:"2026-03-04",name:"Starbucks",        amount:6.75,   cat:"Coffee & Dining",icon:"☕",color:"#D97A3A",dow:2},
  {id:"t7", date:"2026-03-03",name:"Netflix",          amount:18.99,  cat:"Subscriptions",  icon:"🎬",color:"#8A5FC8",dow:1},
  {id:"t8", date:"2026-03-03",name:"Amazon.ca",        amount:34.99,  cat:"Shopping",       icon:"📦",color:"#C45898",dow:1},
  {id:"t9", date:"2026-03-02",name:"Uber Eats",        amount:28.40,  cat:"Coffee & Dining",icon:"🍕",color:"#D97A3A",dow:0},
  {id:"t10",date:"2026-03-01",name:"LCBO",             amount:24.15,  cat:"Shopping",       icon:"🛍️",color:"#C45898",dow:6},
  {id:"t11",date:"2026-02-29",name:"Walmart",          amount:89.22,  cat:"Groceries",      icon:"🛒",color:"#2E8B2E",dow:5},
  {id:"t12",date:"2026-02-28",name:"Hydro One",        amount:124.00, cat:"Utilities",      icon:"⚡",color:"#CFA03E",dow:4},
  {id:"t13",date:"2026-02-28",name:"Starbucks",        amount:6.50,   cat:"Coffee & Dining",icon:"☕",color:"#D97A3A",dow:4},
  {id:"t14",date:"2026-02-27",name:"Spotify",          amount:11.99,  cat:"Subscriptions",  icon:"🎵",color:"#8A5FC8",dow:3},
  {id:"t15",date:"2026-02-27",name:"Rexall Pharmacy",  amount:18.40,  cat:"Health",         icon:"💊",color:"#4A8FCC",dow:3},
  {id:"t16",date:"2026-02-26",name:"H&M",              amount:67.00,  cat:"Shopping",       icon:"👕",color:"#C45898",dow:2},
  {id:"t17",date:"2026-02-25",name:"Harvey's",         amount:14.50,  cat:"Coffee & Dining",icon:"🍔",color:"#D97A3A",dow:1},
  {id:"t18",date:"2026-02-25",name:"Tim Hortons",      amount:4.25,   cat:"Coffee & Dining",icon:"☕",color:"#D97A3A",dow:1},
  {id:"t19",date:"2026-02-24",name:"Amazon.ca",        amount:29.99,  cat:"Shopping",       icon:"📦",color:"#C45898",dow:0},
  {id:"t20",date:"2026-02-22",name:"Payroll Deposit",  amount:-DEMO.income,cat:"Income",         icon:"💰",color:"#6FE494",dow:6},
  {id:"t21",date:"2026-02-21",name:"Loblaws",          amount:73.18,  cat:"Groceries",      icon:"🛒",color:"#2E8B2E",dow:5},
  {id:"t22",date:"2026-02-21",name:"Uber Eats",        amount:31.20,  cat:"Coffee & Dining",icon:"🍕",color:"#D97A3A",dow:5},
  {id:"t23",date:"2026-02-19",name:"Winners",          amount:45.00,  cat:"Shopping",       icon:"🛍️",color:"#C45898",dow:3},
  {id:"t24",date:"2026-02-18",name:"Apple.com/bill",   amount:3.99,   cat:"Subscriptions",  icon:"☁️",color:"#8A5FC8",dow:2},
  {id:"t25",date:"2026-02-17",name:"Starbucks",        amount:7.10,   cat:"Coffee & Dining",icon:"☕",color:"#D97A3A",dow:1},
  {id:"t26",date:"2026-02-15",name:"Bell Canada",      amount:65.00,  cat:"Utilities",      icon:"📱",color:"#CFA03E",dow:6},
  {id:"t27",date:"2026-02-14",name:"Kelsey's",         amount:54.20,  cat:"Coffee & Dining",icon:"🍷",color:"#D97A3A",dow:5},
  {id:"t28",date:"2026-02-12",name:"Shopify/Etsy",     amount:38.00,  cat:"Shopping",       icon:"🎁",color:"#C45898",dow:3},
  {id:"t29",date:"2026-02-10",name:"Costco Gas",       amount:55.80,  cat:"Gas & Transport",icon:"⛽",color:"#CFA03E",dow:1},
  {id:"t30",date:"2026-02-08",name:"Payroll Deposit",  amount:-DEMO.income,cat:"Income",         icon:"💰",color:"#6FE494",dow:6},
];

const MOCK_ACCOUNTS = [
  {id:"a1",name:"TD Chequing ••4521",type:"checking",balance:DEMO.balance,institution:"TD Bank"},
  {id:"a2",name:"TD Savings ••8803",type:"savings",balance:1840.00,institution:"TD Bank"},
  {id:"a3",name:"TD Visa ••2291",type:"credit",balance:-3420.00,institution:"TD Bank"},
  {id:"a4",name:"Questrade TFSA ••7723",type:"investment",balance:12480.00,institution:"Questrade",ticker:"XEQT",gain:2140,gainPct:20.7},
  {id:"a5",name:"TD e-Series RRSP ••9910",type:"investment",balance:8650.00,institution:"TD Bank",ticker:"TDB902",gain:890,gainPct:11.4},
];
const MOCK_ACCOUNTS_US = [
  {id:"a1",name:"Chase Checking ••2891",type:"checking",balance:DEMO.balance,institution:"Chase"},
  {id:"a2",name:"Chase Savings ••5504",type:"savings",balance:1840.00,institution:"Chase"},
  {id:"a3",name:"Chase Sapphire ••4471",type:"credit",balance:-3420.00,institution:"Chase"},
  {id:"a4",name:"Fidelity Roth IRA ••0033",type:"investment",balance:14200.00,institution:"Fidelity",ticker:"FXAIX",gain:2980,gainPct:26.5},
  {id:"a5",name:"Fidelity 401(k) ••8812",type:"investment",balance:23400.00,institution:"Fidelity",ticker:"Target 2055",gain:3890,gainPct:19.9},
];

// ─── DEMO DEFAULTS — used when no real data is connected ─────────────────────
const DEMO = {
  balance:     1_243.88,
  income:      1_847.50,
  netWorthAdd:   1_840,   // mock savings/TFSA for net worth calc
};


// ── ICON SYSTEM: Lucide React ─────────────────────────────────────────────────

// Map string IDs → Lucide components (all icons same visual language, 1.5px stroke)
const ICON_MAP = {
  home:      Home,
  calendar:  Calendar,
  card:      CreditCard,
  sparkles:  Sparkles,
  users:     Users,
  user:      User,
  bell:      Bell,
  settings:  Settings,
  bank:      BarChart2,
  cart:      ShoppingCart,
  coffee:    Coffee,
  zap:       Zap,
  package:   Package,
  film:      Film,
  music:     Music,
  pill:      Pill,
  shirt:     Shirt,
  gas:       Car,
  income:    DollarSign,
  bag:       ShoppingBag,
  house2:    Home,
  target:    Target,
  piggy:     PiggyBank,
  chartUp:   TrendingUp,
  trendUp:   TrendingUp,
  shield:    Shield,
  check:     CheckCircle,
  star:      Star,
  flame:     Flame,
};

function Icon({ id, size=20, color="currentColor", strokeWidth=1.5, style={} }){
  const Comp = ICON_MAP[id];
  if(!Comp) return null;
  return <Comp size={size} color={color} strokeWidth={strokeWidth} style={{flexShrink:0,...style}}/>;
}
// ──────────────────────────────────────────────────────────────────────────────


// ── DECISION ENGINE ─────────────────────────────────────────────────────────────
function DecisionEngine({data, safe, bal, monthlyIncome, soonBills, todayDate, setScreen}) {
  const bills = data.bills || [];
  const debts = data.debts || [];

  // Find next payday (assume monthly income on the 15th or 1st, whichever is sooner)
  const today = todayDate || new Date().getDate();
  const paydayGuess = today < 15 ? 15 : 1;
  const daysToPayday = paydayGuess >= today ? paydayGuess - today : (31 - today + paydayGuess);
  const incomeAmt = parseFloat(data.profile?.income || DEMO.income);

  // Decision Engine calculations
  const daysLeft = daysToPayday > 0 ? daysToPayday : 14;
  const safePerDay = safe > 0 ? safe / daysLeft : 0;
  const safeToday = Math.floor(safePerDay);

  // Debt payoff impact
  const topDebt = debts.sort((a,b)=>parseFloat(b.rate||0)-parseFloat(a.rate||0))[0];
  const extraPayment = 150;
  let monthsSaved = 0;
  if (topDebt) {
    const rate = parseFloat(topDebt.rate || 19.99) / 100 / 12;
    const balance = parseFloat(topDebt.balance || 0);
    const minPay = Math.max(25, balance * 0.02);
    const calcMonths = (bal, pay) => {
      if (pay <= 0 || bal <= 0) return 0;
      let m = 0, b = bal;
      while (b > 0 && m < 240) { b = b * (1 + rate) - pay; m++; }
      return m;
    };
    monthsSaved = Math.max(0, calcMonths(balance, minPay) - calcMonths(balance, minPay + extraPayment));
  }

  // Savings move suggestion
  const safeToMove = Math.max(0, Math.floor(safe * 0.25));

  // Spending spike warning — if safe < 20% of income
  const lowCash = safe < monthlyIncome * 0.15;

  // Build decision cards
  const decisions = [];
  if (safeToday > 0) {
    decisions.push({
      type: "daily",
      icon: "💡",
      color: C.teal,
      title: `Spend max $${safeToday} today`,
      detail: `Keeps you safe until ${daysToPayday <= 1 ? "tomorrow's" : `your payday in ${daysToPayday}d`} deposit of $${incomeAmt.toLocaleString()}`,
      action: "See forecast", screen: "plan"
    });
  }
  if (lowCash) {
    decisions.push({
      type: "warning",
      icon: "⚠️",
      color: C.orange,
      title: "Cash is running tight",
      detail: `Your balance is below 15% of monthly income. Hold non-essential spending for ${daysToPayday} days.`,
      action: "See Plan", screen: "plan"
    });
  }
  if (safeToMove > 20) {
    decisions.push({
      type: "savings",
      icon: "💚",
      color: C.green,
      title: `Move $${safeToMove} to savings`,
      detail: "You can do this now and still stay safe until your next deposit.",
      action: "See Goals", screen: "goals"
    });
  }
  if (topDebt && monthsSaved > 0) {
    decisions.push({
      type: "debt",
      icon: "🎯",
      color: C.purple,
      title: `Pay $${extraPayment} extra on ${topDebt.name}`,
      detail: `Cuts ${monthsSaved} month${monthsSaved!==1?"s":""} off your payoff date. Worth more than any subscription cancel.`,
      action: "Debt Plan", screen: "goals"
    });
  }

  if (decisions.length === 0) return null;

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
        <div style={{color:C.cream,fontSize:13,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"flex",alignItems:"center",gap:7}}>
          <Icon id="zap" size={15} color={C.goldBright} strokeWidth={2}/>
          What to do today
        </div>
        <span style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Decision Engine</span>
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        {decisions.map((d,i)=>(
          <button key={i} onClick={()=>setScreen(d.screen)} style={{background:C.card,border:`1.5px solid ${d.color}28`,borderRadius:18,padding:"14px 16px",cursor:"pointer",textAlign:"left",fontFamily:"inherit",display:"flex",gap:12,alignItems:"flex-start",transition:"all .2s",width:"100%"}}
            onMouseEnter={e=>{e.currentTarget.style.borderColor=d.color+"66";e.currentTarget.style.background=d.color+"0A";}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor=d.color+"28";e.currentTarget.style.background=C.card;}}>
            <span style={{fontSize:20,flexShrink:0,marginTop:1}}>{d.icon}</span>
            <div style={{flex:1,minWidth:0}}>
              <div style={{color:d.color,fontWeight:700,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:3}}>{d.title}</div>
              <div style={{color:C.muted,fontSize:11.5,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.55}}>{d.detail}</div>
            </div>
            <div style={{color:d.color,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,whiteSpace:"nowrap",marginTop:3}}>{d.action} →</div>
          </button>
        ))}
      </div>
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════════
// ██ AUTOPILOT ENGINE — Daily Money Plan                                       ██
// ██ "What should happen with my money today?"                                 ██
// ═══════════════════════════════════════════════════════════════════════════════

const AutopilotEngine = {
  /**
   * ADAPTIVE AUTOPILOT ENGINE
   * Continuously adjusts the daily money plan based on:
   *   1. Behavior patterns (spikeRatio, stability)
   *   2. Forecast risk (upcoming low-balance events)
   *   3. Income schedule (detects payday from onboarding data)
   *   4. Risk mode (Low / Medium / High) that gates all allocations
   */
  generate(data) {
    const { safeAmount, balance, soonBills, riskLevel: rawRisk } = SafeSpendEngine.calculate(data);
    const { monthlyIncome, cashFlow, totalExpenses } = FinancialCalcEngine.cashFlow(data);
    const { forecast, overdraftRisk, lowBalanceWarnings } = ForecastEngine.generate(data, 30);
    const { spendingStability, spikeRatio } = BehaviorEngine.analyze(data);
    const debts = (data.debts || []).sort((a,b) => parseFloat(b.rate||0) - parseFloat(a.rate||0));
    const goals  = data.goals || [];
    const today  = new Date();
    const todayNum = today.getDate();

    // ── ADAPTIVE: Detect payday from income frequency data ───────────────────
    const incomes = (data.incomes || []).filter(i => parseFloat(i.amount) > 0);
    const freq = incomes[0]?.freq || "monthly";
    let daysLeft;
    if (freq === "biweekly") {
      // Approximate: next biweekly is in 7–14 days
      daysLeft = 14 - (todayNum % 14);
    } else if (freq === "weekly") {
      daysLeft = 7 - (todayNum % 7);
    } else {
      // Monthly: 1st or 15th
      daysLeft = todayNum < 15 ? (15 - todayNum) :
        Math.ceil((new Date(today.getFullYear(), today.getMonth()+1, 1) - today) / 86400000);
    }
    daysLeft = Math.max(1, daysLeft);

    // ── ADAPTIVE: Base safeDaily, then adjust for behavior ───────────────────
    let safeDaily = daysLeft > 0 ? Math.floor(safeAmount / daysLeft) : safeAmount;

    // Behavior adjustment ①: spike ratio → tighten daily limit
    if (spikeRatio > 1.4) {
      const reduction = Math.round(safeDaily * 0.15);
      safeDaily = Math.max(0, safeDaily - reduction);
    }
    // Behavior adjustment ②: consistent underspend → loosen daily limit
    if (spendingStability > 0.85 && spikeRatio < 1.1) {
      safeDaily = Math.round(safeDaily * 1.08);
    }

    // ── ADAPTIVE: Forecast-driven pre-emptive tightening ─────────────────────
    // If balance will drop dangerously within 7 days, reduce today's limit now
    const nearTermLow = lowBalanceWarnings.find(w => w.day <= 7);
    if (nearTermLow) {
      const daysUntilLow = nearTermLow.day;
      const urgency = 1 - (daysUntilLow / 7); // 0 = 7 days away, 1 = tomorrow
      safeDaily = Math.round(safeDaily * (1 - urgency * 0.30));
    }

    // ── ADAPTIVE: Risk mode gates all downstream allocations ─────────────────
    // Derived from SafeSpendEngine risk + forecast signals
    const forecastDanger = overdraftRisk.length > 0;
    const mode = forecastDanger ? "high" :
                 rawRisk === "critical" || rawRisk === "high" ? "high" :
                 rawRisk === "medium" || nearTermLow ? "medium" : "low";

    const modeMultipliers = {
      low:    { savings: 0.40, debt: 0.40, goal: 0.50 },
      medium: { savings: 0.20, debt: 0.30, goal: 0.25 },
      high:   { savings: 0,    debt: 0,    goal: 0    },
    };
    const mult = modeMultipliers[mode];

    // ── Safe floor & surplus ──────────────────────────────────────────────────
    const safeFloor = monthlyIncome * 0.15;
    const surplus = Math.max(0,
      balance
      - soonBills.reduce((s,b) => s + parseFloat(b.amount||0), 0)
      - (totalExpenses / 30 * daysLeft)   // forecast remaining spend this period
      - safeFloor
    );

    // ── ① Daily spend limit (adaptive) ───────────────────────────────────────
    const dailySpendLimit = Math.max(0, safeDaily);

    // ── ② Savings transfer (mode-gated, adaptive amount) ─────────────────────
    let savingsTransfer = 0;
    let savingsTarget = "Emergency Fund";
    if (mode !== "high" && surplus > monthlyIncome * 0.12) {
      const efMonths = typeof FinancialCalcEngine.emergencyFundMonths === 'function' ? FinancialCalcEngine.emergencyFundMonths(data) : 0;
      const invAcct  = (data.accounts||[]).find(a => a.type === "investment");
      savingsTarget  = efMonths < 3 ? "Emergency Fund" : invAcct ? "TFSA / Investment" : "Savings";
      // Adaptive: reduce savings amount if spending is volatile
      const volatilityFactor = spendingStability > 0.7 ? 1.0 : 0.7;
      savingsTransfer = Math.round(surplus * mult.savings * volatilityFactor);
    }

    // ── ③ Debt acceleration (mode-gated) ─────────────────────────────────────
    let debtPayment = 0;
    let debtTarget  = null;
    const remainAfterSavings = surplus - savingsTransfer;
    if (mode !== "high" && remainAfterSavings > 30 && debts.length > 0 && parseFloat(debts[0].rate||0) > 8) {
      debtPayment = Math.round(Math.min(remainAfterSavings * mult.debt, 200));
      debtTarget  = debts[0];
    }

    // ── ④ Goal contribution (mode-gated) ─────────────────────────────────────
    let goalContribution = 0;
    let goalTarget = null;
    const remainAfterDebt = remainAfterSavings - debtPayment;
    if (mode === "low" && remainAfterDebt > 20 && goals.length > 0) {
      goalContribution = Math.round(remainAfterDebt * mult.goal);
      goalTarget = goals[0];
    }

    // ── ⑤ Buffer ─────────────────────────────────────────────────────────────
    const buffer = Math.max(0, balance - dailySpendLimit - savingsTransfer - debtPayment - goalContribution);

    // ── ⑥ Adaptive alerts (contextual, not generic) ──────────────────────────
    const alerts = [];
    if (mode === "high") {
      const msg = forecastDanger
        ? `Balance projected to go negative in ${overdraftRisk[0]?.day} days. Hold all non-essential spending.`
        : "Cash is critically low. Bills protection mode active — savings and extras paused.";
      alerts.push({ type:"danger", msg });
    } else if (nearTermLow) {
      alerts.push({ type:"warning", msg:`Balance drops near your safety floor in ${nearTermLow.day} days — daily limit tightened by 15% as a precaution.` });
    }
    if (spikeRatio > 1.4 && mode !== "high") {
      alerts.push({ type:"tip", msg:`Payday spike habit detected (+${Math.round((spikeRatio-1)*100)}%). Daily limit reduced by 15% to smooth your cash flow.` });
    }

    // ── ⑦ Adherence — based on spending stability (0-100) ────────────────────
    const adherence = Math.min(100, Math.round(spendingStability * 100));

    // ── ⑧ Mode label for UI ──────────────────────────────────────────────────
    const modeLabel = mode === "low" ? "On Track" : mode === "medium" ? "Monitor" : "At Risk";
    const adaptations = [
      spikeRatio > 1.4 && `Limit -15% (payday spike habit)`,
      nearTermLow && `Limit tightened (low balance in ${nearTermLow.day}d)`,
      spendingStability > 0.85 && `Limit +8% (consistent spending)`,
      mode === "high" && `Extras paused (protect bills first)`,
    ].filter(Boolean);

    return {
      dailySpendLimit, savingsTransfer, savingsTarget,
      debtPayment, debtTarget, goalContribution, goalTarget,
      buffer, alerts, mode, modeLabel,
      daysLeft, adherence, surplus, adaptations,
      riskLevel: rawRisk,
    };
  }
};

// ── AUTOPILOT CARD (Dashboard component) ──────────────────────────────────────
function AutopilotCard({data, setScreen}) {
  const [revealed, setRevealed] = useState(false);
  const plan = AutopilotEngine.generate(data);
  const today = new Date().toLocaleDateString("en-CA", {weekday:"long", month:"long", day:"numeric"});
  const hasActions = plan.savingsTransfer > 0 || plan.debtPayment > 0 || plan.goalContribution > 0;

  const lineItems = [
    plan.dailySpendLimit > 0 && {
      icon:"💡", label:"Safe to spend today", amount:`$${plan.dailySpendLimit}`,
      color:C.green, detail:`for the next ${plan.daysLeft} day${plan.daysLeft!==1?"s":""}`,
    },
    plan.savingsTransfer > 0 && {
      icon:"🐷", label:`Move to ${plan.savingsTarget}`, amount:`$${plan.savingsTransfer}`,
      color:C.teal, detail:"builds your safety net",
    },
    plan.debtPayment > 0 && plan.debtTarget && {
      icon:"🎯", label:`Extra toward ${plan.debtTarget.name}`, amount:`$${plan.debtPayment}`,
      color:C.purple, detail:`saves on ${plan.debtTarget.rate}% interest`,
    },
    plan.goalContribution > 0 && plan.goalTarget && {
      icon:"🌱", label:plan.goalTarget.name||"Goal contribution", amount:`$${plan.goalContribution}`,
      color:C.gold, detail:"progress toward your goal",
    },
    plan.buffer > 100 && {
      icon:"🔒", label:"Untouched buffer", amount:`$${plan.buffer.toFixed(0)}`,
      color:C.muted, detail:"stays in your account",
    },
  ].filter(Boolean);

  return (
    <div style={{background:`linear-gradient(155deg,#061510 0%,#0B1E14 50%,#080D10 100%)`,borderRadius:26,overflow:"hidden",border:`1px solid ${C.green}30`,boxShadow:`0 16px 64px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.03), inset 0 1px 0 rgba(0,214,143,0.08)`,backdropFilter:"blur(12px)"}}>
      {/* Header */}
      <div style={{padding:"18px 20px 0",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div>
          <div style={{color:"rgba(237,232,225,0.4)",fontSize:9,textTransform:"uppercase",letterSpacing:3,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,marginBottom:5}}>Autopilot · {today}</div>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:900,color:"#fff",lineHeight:1.2}}>Today's Money Plan</div>
            <span style={{background:C.teal+"33",color:C.tealBright,fontSize:8,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,letterSpacing:1,textTransform:"uppercase",padding:"3px 7px",borderRadius:99,border:`1px solid ${C.teal}44`}}>Adaptive</span>
          </div>
        </div>
        <div style={{background:plan.mode==="low"?"rgba(110,240,160,0.15)":plan.mode==="medium"?"rgba(255,193,69,0.15)":"rgba(255,100,100,0.15)",border:`1px solid ${plan.mode==="low"?C.green+"55":plan.mode==="medium"?C.gold+"55":C.red+"55"}`,borderRadius:99,padding:"4px 10px"}}>
          <span style={{color:plan.mode==="low"?C.greenBright:plan.mode==="medium"?C.goldBright:C.redBright,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,textTransform:"uppercase",letterSpacing:0.5}}>
            {plan.modeLabel}
          </span>
        </div>
      </div>

      {/* Alert banner */}
      {plan.alerts.length > 0 && (
        <div style={{margin:"12px 20px 0",background:"rgba(255,100,100,0.12)",border:"1px solid rgba(255,100,100,0.25)",borderRadius:12,padding:"10px 14px",display:"flex",gap:8,alignItems:"flex-start"}}>
          <span style={{fontSize:14,flexShrink:0}}>⚠️</span>
          <span style={{color:"rgba(255,160,160,0.9)",fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.5}}>{plan.alerts[0].msg}</span>
        </div>
      )}

      {/* Line items */}
      <div style={{padding:"14px 20px 6px",display:"flex",flexDirection:"column",gap:10}}>
        {lineItems.map((item,i)=>(
          <div key={i} style={{display:"flex",alignItems:"center",justifyContent:"space-between",paddingBottom:10,borderBottom:i<lineItems.length-1?"1px solid rgba(255,255,255,0.06)":"none"}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:18,flexShrink:0}}>{item.icon}</span>
              <div>
                <div style={{color:"rgba(255,255,255,0.85)",fontWeight:600,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{item.label}</div>
                <div style={{color:"rgba(255,255,255,0.35)",fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",marginTop:1}}>{item.detail}</div>
              </div>
            </div>
            <div style={{fontFamily:"'Playfair Display',serif",fontWeight:900,fontSize:18,color:item.color==="muted"?"rgba(255,255,255,0.3)":item.color,flexShrink:0}}>{item.amount}</div>
          </div>
        ))}
      </div>

      {/* Weekly adherence bar */}
      <div style={{margin:"0 20px",padding:"12px 0 16px",borderTop:"1px solid rgba(255,255,255,0.06)"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
          <span style={{color:"rgba(255,255,255,0.4)",fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,textTransform:"uppercase",letterSpacing:0.8}}>Plan adherence</span>
          <span style={{color:plan.adherence>=75?C.greenBright:plan.adherence>=50?C.goldBright:C.redBright,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800}}>{plan.adherence}%</span>
        </div>
        <div style={{height:4,borderRadius:99,background:"rgba(255,255,255,0.08)",overflow:"hidden"}}>
          <div style={{height:"100%",width:`${plan.adherence}%`,background:`linear-gradient(to right,${plan.adherence>=75?C.green:plan.adherence>=50?C.gold:C.red}88,${plan.adherence>=75?C.greenBright:plan.adherence>=50?C.goldBright:C.redBright})`,borderRadius:99,transition:"width 1.2s ease"}}/>
        </div>
      </div>
      {/* Adaptive adjustments made to this plan */}
      {plan.adaptations && plan.adaptations.length > 0 && (
        <div style={{margin:"0 0 4px",padding:"0 0 12px",display:"flex",gap:5,flexWrap:"wrap"}}>
          {plan.adaptations.map((a,i)=>(
            <span key={i} style={{background:"rgba(255,255,255,0.07)",color:"rgba(255,255,255,0.4)",fontSize:9,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,padding:"3px 8px",borderRadius:99,letterSpacing:0.3}}>⚙ {a}</span>
          ))}
        </div>
      )}
    </div>
  );
}

// ── FINANCIAL TIME MACHINE (Timeline + What-If overlay) ───────────────────────
function TimeMachine({data}) {
  const [whatIfAmount, setWhatIfAmount] = useState(0);
  const [whatIfLabel, setWhatIfLabel] = useState("");
  const [inputVal, setInputVal] = useState("");
  const [activePreset, setActivePreset] = useState(null);
  const [expanded, setExpanded] = useState(false);

  // Single source of truth: ForecastEngine (uses real income schedule, not mocked payday)
  const { forecast } = ForecastEngine.generate(data, 30);
  const safeFloor = SafeSpendEngine.calculate(data).balance * 0.12;

  // Filter to meaningful events
  const events = forecast.filter(f => f.isPayday || f.bills.length > 0 || f.day === 0 || f.day === 30);
  const displayed = expanded ? events : events.slice(0, 5);

  // What-if overlay: deduct the amount from every day after today
  const overlayBalance = (f) => {
    if (whatIfAmount <= 0) return null;
    return f.day > 0 ? f.balance - whatIfAmount : f.balance;
  };

  const presets = [
    {label:"$500 vacation", amount:500},
    {label:"$900 laptop",   amount:900},
    {label:"$300/mo invest", amount:300},
    {label:"$1,200 car repair", amount:1200},
  ];

  const applyWhatIf = (label, amount) => {
    setWhatIfLabel(label); setWhatIfAmount(amount);
    setInputVal(label); setActivePreset(label);
  };
  const clearWhatIf = () => {
    setWhatIfAmount(0); setWhatIfLabel(""); setInputVal(""); setActivePreset(null);
  };

  const parseInput = (v) => {
    const m = v.match(/\$?([\d,]+)/);
    return m ? parseFloat(m[1].replace(/,/g,"")) : 0;
  };

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
        <div style={{color:C.cream,fontSize:13,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"flex",alignItems:"center",gap:7}}>
          <span style={{fontSize:15}}>⏳</span> Financial Time Machine
        </div>
        <button onClick={()=>setExpanded(e=>!e)} style={{background:"none",border:"none",color:C.teal,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,cursor:"pointer"}}>
          {expanded?"Collapse ↑":"30 days ↓"}
        </button>
      </div>

      {/* What-if input */}
      <div style={{background:"rgba(255,255,255,0.04)",borderRadius:16,padding:"12px 14px",border:`1px solid ${whatIfAmount>0?C.purple+"55":C.border}`,marginBottom:12,transition:"border-color .2s"}}>
        <div style={{color:C.muted,fontSize:9,textTransform:"uppercase",letterSpacing:1.5,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,marginBottom:8}}>
          {whatIfAmount > 0 ? `Showing impact of ${whatIfLabel}` : "What if I…"}
        </div>
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:8}}>
          {presets.map(p=>(
            <button key={p.label} onClick={()=>applyWhatIf(p.label, p.amount)} style={{background:activePreset===p.label?C.purple+"33":C.surface,border:`1px solid ${activePreset===p.label?C.purple+"66":C.border}`,color:activePreset===p.label?C.purpleBright:C.muted,borderRadius:99,padding:"5px 10px",fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,cursor:"pointer",transition:"all .15s"}}>{p.label}</button>
          ))}
        </div>
        <div style={{display:"flex",gap:7}}>
          <input
            value={inputVal}
            onChange={e=>setInputVal(e.target.value)}
            onKeyDown={e=>{if(e.key==="Enter"&&inputVal){const amt=parseInput(inputVal);if(amt>0)applyWhatIf(inputVal,amt);}}}
            placeholder="Type e.g. $650 TV…"
            style={{flex:1,padding:"9px 12px",borderRadius:11,border:`1px solid ${C.border}`,background:C.surface,color:C.cream,fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:12,outline:"none"}}
          />
          {whatIfAmount > 0
            ? <button onClick={clearWhatIf} style={{background:C.red+"22",border:`1px solid ${C.red}44`,color:C.redBright,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,fontSize:11,padding:"9px 12px",borderRadius:11,cursor:"pointer",whiteSpace:"nowrap"}}>Clear ✕</button>
            : <button onClick={()=>{const amt=parseInput(inputVal);if(amt>0)applyWhatIf(inputVal,amt);}} style={{background:C.purple+"22",border:`1px solid ${C.purple}44`,color:C.purpleBright,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,fontSize:11,padding:"9px 12px",borderRadius:11,cursor:"pointer",whiteSpace:"nowrap"}}>Apply →</button>
          }
        </div>
      </div>

      {/* Timeline */}
      <div style={{position:"relative"}}>
        <div style={{position:"absolute",left:19,top:8,bottom:8,width:2,background:`linear-gradient(to bottom,${C.teal}55,${C.border}22)`,borderRadius:99}}/>
        <div style={{display:"flex",flexDirection:"column",gap:0}}>
          {displayed.map((ev, idx) => {
            const baseBalance = ev.balance;
            const overlayBal = overlayBalance(ev);
            const isLow = baseBalance < safeFloor;
            const overlayLow = overlayBal !== null && overlayBal < safeFloor;
            const dotColor = ev.day===0 ? C.green : ev.isPayday ? C.greenBright : ev.bills.length>0 ? C.gold : isLow ? C.red : C.border;
            const balColor = isLow ? C.redBright : ev.isPayday ? C.greenBright : C.mutedHi;
            const overlaydiff = overlayBal !== null ? overlayBal - baseBalance : 0;

            return (
              <div key={idx} style={{display:"flex",gap:14,paddingBottom:14,position:"relative"}}>
                <div style={{width:40,display:"flex",justifyContent:"center",flexShrink:0,paddingTop:3}}>
                  <div style={{width:14,height:14,borderRadius:"50%",background:dotColor,border:`3px solid ${C.bg}`,zIndex:1,boxShadow:ev.day===0||ev.isPayday?`0 0 8px ${dotColor}88`:"none",flexShrink:0}}/>
                </div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:ev.day===0?800:600,fontSize:13,color:ev.day===0?C.cream:C.mutedHi,marginBottom:ev.isPayday||ev.bills.length>0?3:0}}>
                        {ev.day===0?"Today":ev.day===1?"Tomorrow":ev.date.toLocaleDateString("en-CA",{weekday:"short",month:"short",day:"numeric"})}
                      </div>
                      {ev.isPayday && <div style={{color:C.greenBright,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700}}>+${FinancialCalcEngine.cashFlow(data).monthlyIncome.toFixed(0)} paycheck</div>}
                      {ev.bills.map((b,bi)=><div key={bi} style={{color:C.gold,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{b.name} −${b.amount}</div>)}
                      {isLow && !ev.isPayday && <div style={{color:C.redBright,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,marginTop:2}}>⚠ Low balance</div>}
                    </div>
                    <div style={{textAlign:"right",flexShrink:0,minWidth:80}}>
                      {/* Base balance */}
                      <div style={{fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,fontSize:13,color:balColor}}>${baseBalance.toFixed(0)}</div>
                      {/* What-if overlay balance */}
                      {overlayBal !== null && (
                        <div style={{fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,fontSize:11,color:overlayLow?C.redBright:C.purpleBright,marginTop:2}}>
                          → ${overlayBal.toFixed(0)}
                          <span style={{color:overlaydiff<0?C.redBright:C.greenBright,fontSize:9,marginLeft:3}}>
                            ({overlaydiff>0?"+":""}{overlaydiff.toFixed(0)})
                          </span>
                        </div>
                      )}
                      <div style={{color:C.muted,fontSize:9,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>balance</div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        {whatIfAmount > 0 && (
          <div style={{background:C.purple+"10",border:`1px solid ${C.purple}22`,borderRadius:12,padding:"10px 14px",marginTop:4,display:"flex",gap:8,alignItems:"flex-start"}}>
            <span style={{fontSize:14,flexShrink:0}}>🔮</span>
            <div style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.6}}>
              <strong style={{color:C.purpleBright}}>{whatIfLabel}</strong> would reduce your balance by <strong style={{color:C.purpleBright}}>${whatIfAmount}</strong> immediately.
              {(() => {
                const firstDanger = events.find(e => e.day > 0 && (e.balance - whatIfAmount) < safeFloor);
                return firstDanger
                  ? <> Your balance would drop below safe levels on <strong style={{color:C.redBright}}>{firstDanger.date.toLocaleDateString("en-CA",{month:"short",day:"numeric"})}</strong>.</>
                  : <> <strong style={{color:C.greenBright}}>Your timeline stays safe</strong> — you can afford this.</>
              })()}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── FINANCIAL TIMELINE — powered exclusively by ForecastEngine ──────────────────
// Fix: replaced manual payday loop (isPayday = i === 7 mock) with ForecastEngine
// which reads income frequency from onboarding. Single source of truth.
function FinancialTimeline({data}) {
  const [expanded, setExpanded] = useState(false);
  // ── Delegate to ForecastEngine — no duplicate forecasting logic ──
  const { forecast } = ForecastEngine.generate(data, 30);
  const safeFloor = SafeSpendEngine.calculate(data).balance * 0.12;
  const { monthlyIncome } = FinancialCalcEngine.cashFlow(data);

  const events = forecast.filter(f => f.day === 0 || f.isPayday || f.bills.length > 0 || f.day === 30);
  const displayed = expanded ? events : events.slice(0, 4);

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
        <div style={{color:C.cream,fontSize:13,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"flex",alignItems:"center",gap:7}}>
          <Icon id="calendar" size={15} color={C.teal} strokeWidth={2}/>
          Financial Timeline
        </div>
        <button onClick={()=>setExpanded(e=>!e)} style={{background:"none",border:"none",color:C.teal,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,cursor:"pointer"}}>
          {expanded ? "Collapse ↑" : "See 30 days ↓"}
        </button>
      </div>
      <div style={{position:"relative"}}>
        <div style={{position:"absolute",left:19,top:8,bottom:8,width:2,background:`linear-gradient(to bottom,${C.teal}55,${C.border}22)`,borderRadius:99}}/>
        <div style={{display:"flex",flexDirection:"column",gap:0}}>
          {displayed.map((ev, idx) => {
            const isLow = ev.balance < safeFloor;
            const dotColor = ev.day===0 ? C.green : ev.isPayday ? C.greenBright : ev.bills.length>0 ? C.gold : isLow ? C.red : C.border;
            const balColor = isLow ? C.redBright : ev.isPayday ? C.greenBright : C.mutedHi;
            const label = ev.day===0?"Today":ev.day===1?"Tomorrow":ev.date.toLocaleDateString("en-CA",{weekday:"short",month:"short",day:"numeric"});
            return (
              <div key={idx} style={{display:"flex",gap:14,paddingBottom:14,position:"relative"}}>
                <div style={{width:40,display:"flex",justifyContent:"center",flexShrink:0,paddingTop:2}}>
                  <div style={{width:14,height:14,borderRadius:"50%",background:dotColor,border:`3px solid ${C.bg}`,zIndex:1,boxShadow:ev.day===0||ev.isPayday?`0 0 10px ${dotColor}88`:"none",flexShrink:0}}/>
                </div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:ev.day===0?800:600,fontSize:13,color:ev.day===0?C.cream:C.mutedHi,marginBottom:2}}>{label}</div>
                      {ev.isPayday && <div style={{color:C.greenBright,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700}}>+${monthlyIncome.toFixed(0)} paycheck</div>}
                      {ev.bills.map((b,bi)=><div key={bi} style={{color:C.gold,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{b.name} −${b.amount}</div>)}
                      {isLow && !ev.isPayday && <div style={{color:C.redBright,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,marginTop:2}}>⚠ Low balance</div>}
                    </div>
                    <div style={{textAlign:"right",flexShrink:0}}>
                      <div style={{fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,fontSize:13,color:balColor}}>${ev.balance.toFixed(0)}</div>
                      <div style={{color:C.muted,fontSize:9,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>balance</div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── WHAT IF SIMULATOR ──────────────────────────────────────────────────────────
function WhatIfSimulator({data, onClose}) {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [inputVal, setInputVal] = useState("");
  const presets = [
    "Buy a $800 laptop",
    "Take a $1,200 vacation",
    "Get a $600 phone",
    "Pay off my credit card",
    "Invest $300/month",
    "Buy a used car for $8,000",
  ];

  const bal = parseFloat((data.accounts?.[0]?.balance || DEMO.balance).toString().replace(/,/g,""));
  const monthlyIncome = parseFloat(data.profile?.income || DEMO.income) * 2.2;
  const totalDebt = (data.debts||[]).reduce((s,d) => s + parseFloat(d.balance||0), 0);
  const bills = (data.bills||[]).reduce((s,b) => s + parseFloat(b.amount||0), 0);
  const {score} = calcHealthScore(data);

  const simulate = async (q) => {
    const qText = q || inputVal;
    if (!qText.trim()) return;
    setQuery(qText);
    setLoading(true);
    setResult(null);

    const prompt = `You are a financial simulator. The user wants to know the impact of: "${qText}".
Current financial data: Balance $${bal.toFixed(0)}, Monthly income ~$${monthlyIncome.toFixed(0)}, Total debt $${totalDebt.toFixed(0)}, Monthly bills $${bills.toFixed(0)}, Financial Health Score ${score}/100.
Respond ONLY with valid JSON (no markdown) like:
{"cashImpact":"safe"|"tight"|"risky","cashDetail":"1 sentence","debtImpact":"none"|"increases"|"decreases","debtDetail":"1 sentence","savingsDelay":"none"|"X weeks"|"X months","healthScoreDelta":-5,"healthDetail":"1 sentence","verdict":"Go for it"|"Proceed carefully"|"Think twice"|"Not recommended","verdictReason":"1 sentence","tip":"1 actionable alternative if risky, else empty string"}`;

    try {
      const r = await fetch("/api/coach", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ type:"simulator", payload:{ prompt } })
      });
      const d = await r.json();
      const text = d.content?.[0]?.text || "{}";
      const clean = text.replace(/```json|```/g,"").trim();
      setResult(JSON.parse(clean));
    } catch {
      setResult({cashImpact:"tight",cashDetail:"Could reduce your safe-to-spend buffer significantly.",debtImpact:"none",debtDetail:"No direct debt change.",savingsDelay:"2 weeks",healthScoreDelta:-3,healthDetail:"Temporary dip in your financial health score.",verdict:"Proceed carefully",verdictReason:"Make sure you have enough buffer after this purchase.",tip:""});
    }
    setLoading(false);
  };

  const verdictColor = result ? (result.verdict==="Go for it"?C.greenBright:result.verdict==="Proceed carefully"?C.goldBright:result.verdict==="Think twice"?C.orangeBright:C.redBright) : C.muted;
  const verdictBg = result ? (result.verdict==="Go for it"?C.greenDim:result.verdict==="Proceed carefully"?C.goldDim:result.verdict==="Think twice"?C.orangeDim:C.redDim) : C.surface;
  const impactIcon = (v) => v==="safe"||v==="none"||v==="decreases"?"✓":v==="tight"||v==="increases"?"~":"✗";
  const impactColor = (v) => v==="safe"||v==="none"||v==="decreases"?C.greenBright:v==="tight"||v==="increases"?C.goldBright:C.redBright;

  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.55)",backdropFilter:"blur(6px)",zIndex:999,display:"flex",alignItems:"flex-end",justifyContent:"center"}} onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{background:C.bg,borderRadius:"28px 28px 0 0",padding:"28px 24px 44px",width:"100%",maxWidth:520,maxHeight:"90vh",overflowY:"auto",boxShadow:"0 -20px 60px rgba(0,0,0,0.2)"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:20}}>
          <div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:900,color:C.cream,lineHeight:1.2}}>What If Simulator</div>
            <div style={{color:C.muted,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",marginTop:3}}>Test any financial decision instantly</div>
          </div>
          <button onClick={onClose} style={{background:"none",border:"none",color:C.muted,fontSize:24,cursor:"pointer",padding:"4px 8px",lineHeight:1}}>×</button>
        </div>

        {/* Quick presets */}
        <div style={{marginBottom:16}}>
          <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,marginBottom:8}}>Quick scenarios</div>
          <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
            {presets.map(p=>(
              <button key={p} onClick={()=>simulate(p)} style={{background:query===p?C.greenDim:C.cardAlt,border:`1px solid ${query===p?C.green+"55":C.border}`,color:query===p?C.green:C.mutedHi,borderRadius:99,padding:"6px 12px",fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,cursor:"pointer",transition:"all .15s"}}>{p}</button>
            ))}
          </div>
        </div>

        {/* Custom input */}
        <div style={{display:"flex",gap:8,marginBottom:20}}>
          <input
            value={inputVal}
            onChange={e=>setInputVal(e.target.value)}
            onKeyDown={e=>e.key==="Enter"&&simulate()}
            placeholder="e.g. Buy a $450 TV…"
            style={{flex:1,padding:"12px 16px",borderRadius:14,border:`1.5px solid ${C.border}`,background:C.surface,color:C.cream,fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:13,outline:"none"}}
          />
          <button onClick={()=>simulate()} style={{background:`linear-gradient(135deg,${C.green},${C.greenBright})`,color:"#fff",border:"none",borderRadius:14,padding:"12px 18px",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,fontSize:13,cursor:"pointer",whiteSpace:"nowrap"}}>Simulate →</button>
        </div>

        {/* Loading */}
        {loading && (
          <div style={{textAlign:"center",padding:"30px 0"}}>
            <div style={{fontSize:36,marginBottom:12,animation:"spin 1s linear infinite"}}>⚙️</div>
            <div style={{color:C.cream,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,fontSize:15}}>Simulating "{query}"…</div>
            <div style={{color:C.muted,fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:12,marginTop:6}}>Running your numbers</div>
          </div>
        )}

        {/* Result */}
        {result && !loading && (
          <div style={{display:"flex",flexDirection:"column",gap:12,animation:"fadeUp 0.3s ease both"}}>
            {/* Verdict */}
            <div style={{background:verdictBg,border:`2px solid ${verdictColor}33`,borderRadius:20,padding:"18px 20px",textAlign:"center"}}>
              <div style={{fontSize:36,marginBottom:6}}>{result.verdict==="Go for it"?"🟢":result.verdict==="Proceed carefully"?"🟡":result.verdict==="Think twice"?"🟠":"🔴"}</div>
              <div style={{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:900,color:verdictColor,marginBottom:6}}>{result.verdict}</div>
              <div style={{color:C.mutedHi,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.6}}>{result.verdictReason}</div>
            </div>

            {/* Impact grid */}
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              {[
                {label:"Cash Impact",    val:result.cashImpact,    detail:result.cashDetail,    icon:"💵"},
                {label:"Debt Impact",    val:result.debtImpact,    detail:result.debtDetail,    icon:"💳"},
                {label:"Savings Delay",  val:result.savingsDelay,  detail:"Impact on savings goals", icon:"🐷"},
                {label:"Health Score",   val:result.healthScoreDelta>=0?`+${result.healthScoreDelta}`:String(result.healthScoreDelta), detail:result.healthDetail, icon:"💚"},
              ].map((item,i)=>(
                <div key={i} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:16,padding:"14px 14px 12px"}}>
                  <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:6}}>
                    <span style={{fontSize:16}}>{item.icon}</span>
                    <span style={{color:C.muted,fontSize:9,textTransform:"uppercase",letterSpacing:1.2,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>{item.label}</span>
                  </div>
                  <div style={{fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:14,color:i===3?(result.healthScoreDelta>=0?C.greenBright:C.redBright):impactColor(item.val),marginBottom:4}}>{i===3?(result.healthScoreDelta>=0?`+${result.healthScoreDelta}`:`${result.healthScoreDelta}`)+" pts":impactIcon(item.val)+" "+item.val}</div>
                  <div style={{color:C.muted,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.5}}>{item.detail}</div>
                </div>
              ))}
            </div>

            {/* Tip */}
            {result.tip && (
              <div style={{background:C.tealDim,border:`1px solid ${C.teal}33`,borderRadius:14,padding:"12px 14px",display:"flex",gap:10,alignItems:"flex-start"}}>
                <span style={{fontSize:18,flexShrink:0}}>💡</span>
                <div style={{color:C.mutedHi,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.6}}><strong style={{color:C.teal}}>Better option:</strong> {result.tip}</div>
              </div>
            )}

            {/* Try another */}
            <button onClick={()=>{setResult(null);setQuery("");setInputVal("");}} style={{background:"none",border:`1px solid ${C.border}`,color:C.mutedHi,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,fontSize:13,padding:"12px",borderRadius:14,cursor:"pointer"}}>Try another scenario</button>
          </div>
        )}
      </div>
    </div>
  );
}


// ── MONEY PERSONALITY ──────────────────────────────────────────────────────────
function calcPersonality(txns, data) {
  const t = txns || MOCK_TXN;
  const neg = t.filter(x => x.amount < 0);
  const total = neg.reduce((s,x) => s + Math.abs(x.amount), 0) || 1;

  const food    = neg.filter(x=>["Food","Coffee","Dining"].includes(x.cat)).reduce((s,x)=>s+Math.abs(x.amount),0);
  const shop    = neg.filter(x=>x.cat==="Shopping").reduce((s,x)=>s+Math.abs(x.amount),0);
  const subs    = neg.filter(x=>x.cat==="Subscriptions").reduce((s,x)=>s+Math.abs(x.amount),0);
  const ent     = neg.filter(x=>x.cat==="Entertainment").reduce((s,x)=>s+Math.abs(x.amount),0);
  const income  = (data.incomes||[]).length;

  const scores = {
    convenience: food/total,
    lifestyle:   (shop+ent)/total,
    digital:     subs/total,
    builder:     income > 1 ? 0.8 : 0.3,
  };
  const top = Object.entries(scores).sort((a,b)=>b[1]-a[1])[0][0];

  const personas = {
    convenience: {
      name:"The Convenience Spender", emoji:"🛍️",
      color:C.orange,
      traits:["High food delivery spend","Values time over money","Subscription-heavy lifestyle"],
      insight:"Your biggest lever is replacing 3 deliveries/week with home cooking — saves ~$180/mo.",
      shareText:"I'm a Convenience Spender 🛍️ on @flourishmoney"
    },
    lifestyle: {
      name:"The Experience Collector", emoji:"✈️",
      color:C.purple,
      traits:["Prioritizes experiences","Shopping for quality","Social spending peaks"],
      insight:"You spend richly on life. Automating $200/mo to savings before spending keeps goals on track.",
      shareText:"I'm an Experience Collector ✈️ on @flourishmoney"
    },
    digital: {
      name:"The Digital Native", emoji:"💻",
      color:C.teal,
      traits:["Heavy subscription stack","Tech-first spending","Optimizes with apps"],
      insight:"You have ~$82/mo in subscriptions. Auditing unused ones could free up a full investment contribution.",
      shareText:"I'm a Digital Native 💻 on @flourishmoney"
    },
    builder: {
      name:"The Wealth Builder", emoji:"🏗️",
      color:C.green,
      traits:["Multiple income streams","Disciplined with spending","Goal-oriented mindset"],
      insight:"You're already ahead — make sure your savings are in a high-interest account earning 4%+.",
      shareText:"I'm a Wealth Builder 🏗️ on @flourishmoney"
    }
  };
  return {...personas[top], scores, topKey:top};
}

function MoneyPersonality({data}) {
  const [revealed, setRevealed] = useState(false);
  const txns = data.transactions || MOCK_TXN;
  const p = calcPersonality(txns, data);
  const bars = [
    {label:"Convenience", pct:Math.round(p.scores.convenience*100), color:C.orange},
    {label:"Lifestyle",   pct:Math.round(p.scores.lifestyle*100),   color:C.purple},
    {label:"Digital",     pct:Math.round(p.scores.digital*100),      color:C.teal},
    {label:"Builder",     pct:Math.round(p.scores.builder*100),      color:C.green},
  ];

  return (
    <div style={{background:C.card,borderRadius:20,padding:"20px",border:`1.5px solid ${p.color}33`,position:"relative",overflow:"hidden"}}>
      <div style={{position:"absolute",top:-40,right:-40,width:140,height:140,borderRadius:"50%",background:`radial-gradient(circle,${p.color}12 0%,transparent 70%)`,pointerEvents:"none"}}/>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
        <div style={{color:C.cream,fontSize:13,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"flex",alignItems:"center",gap:7}}>
          <span style={{fontSize:16}}>{p.emoji}</span> Money Personality
        </div>
        <span style={{background:p.color+"22",color:p.color,fontSize:9,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",padding:"3px 8px",borderRadius:99,textTransform:"uppercase",letterSpacing:0.8}}>Your type</span>
      </div>

      {!revealed ? (
        <div style={{textAlign:"center",padding:"16px 0 8px"}}>
          <div style={{fontSize:48,marginBottom:10,filter:"blur(8px)",transition:"filter .3s"}}>?</div>
          <div style={{color:C.muted,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:16}}>Based on your spending patterns</div>
          <button onClick={()=>setRevealed(true)} style={{background:`linear-gradient(135deg,${p.color},${p.color}BB)`,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:14,padding:"12px 28px",borderRadius:99,border:"none",cursor:"pointer",boxShadow:`0 4px 16px ${p.color}44`}}>Reveal My Type →</button>
        </div>
      ) : (
        <div style={{animation:"fadeUp 0.4s ease both"}}>
          <div style={{textAlign:"center",marginBottom:16}}>
            <div style={{fontSize:52,marginBottom:6}}>{p.emoji}</div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:21,fontWeight:900,color:p.color,lineHeight:1.2,marginBottom:8}}>{p.name}</div>
            <div style={{display:"flex",gap:6,justifyContent:"center",flexWrap:"wrap",marginBottom:12}}>
              {p.traits.map((t,i)=>(
                <span key={i} style={{background:p.color+"18",color:p.color,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,padding:"4px 10px",borderRadius:99}}>{t}</span>
              ))}
            </div>
            <div style={{background:p.color+"12",border:`1px solid ${p.color}33`,borderRadius:14,padding:"12px 14px",textAlign:"left",marginBottom:14}}>
              <div style={{color:C.muted,fontSize:9,textTransform:"uppercase",letterSpacing:1.2,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,marginBottom:5}}>Coach Insight</div>
              <div style={{color:C.cream,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.65}}>{p.insight}</div>
            </div>
          </div>
          <div style={{marginBottom:14}}>
            {bars.map(b=>(
              <div key={b.label} style={{marginBottom:7}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                  <span style={{color:C.muted,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>{b.label}</span>
                  <span style={{color:b.color,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700}}>{b.pct}%</span>
                </div>
                <div style={{height:5,borderRadius:99,background:C.border,overflow:"hidden"}}>
                  <div style={{height:"100%",width:`${b.pct}%`,background:`linear-gradient(to right,${b.color}88,${b.color})`,borderRadius:99,transition:"width 1s ease"}}/>
                </div>
              </div>
            ))}
          </div>
          <button onClick={()=>{if(navigator.share)navigator.share({title:"My Money Personality",text:p.shareText,url:"https://flourishmoney.app"}).catch(()=>{});}} style={{width:"100%",background:"none",border:`1.5px solid ${p.color}44`,color:p.color,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,fontSize:12,padding:"10px",borderRadius:14,cursor:"pointer"}}>Share My Type 🔗</button>
        </div>
      )}
    </div>
  );
}

// ── FUTURE WEALTH FORECAST ─────────────────────────────────────────────────────
function WealthForecast({data}) {
  const [extra, setExtra] = useState(0);
  const [horizon, setHorizon] = useState(20);
  const monthlyIncome = (data.incomes||[]).reduce((s,i)=>s+parseFloat(i.amount||0),0) || 4200;
  const totalDebt = (data.debts||[]).reduce((s,d)=>s+parseFloat(d.balance||0),0);
  const bal = parseFloat((data.accounts?.[0]?.balance||1243).toString().replace(/,/g,""));
  const invBal = (data.accounts||[]).filter(a=>a.type==="investment").reduce((s,a)=>s+parseFloat(a.balance||0),0);
  const savingsRate = 0.10; // assume 10% baseline savings
  const monthlyInvest = monthlyIncome * savingsRate + extra;
  const annualReturn = 0.07;

  const project = (monthly, years) => {
    let val = invBal + bal * 0.5;
    for (let y = 0; y < years; y++) {
      val = val * (1 + annualReturn) + monthly * 12;
    }
    return Math.round(val - totalDebt * Math.max(0, 1 - years * 0.1));
  };

  const scenarios = [
    {label:"Current Path",        monthly:monthlyInvest,           color:C.teal,    icon:"📍"},
    {label:"+$200/mo saved",       monthly:monthlyInvest+200,       color:C.green,   icon:"📈"},
    {label:"+$500/mo invested",    monthly:monthlyInvest+500,       color:C.purple,  icon:"🚀"},
  ];

  const vals = scenarios.map(s => project(s.monthly, horizon));
  const maxVal = Math.max(...vals);

  const fmt = n => n >= 1000000 ? `$${(n/1000000).toFixed(2)}M` : `$${(n/1000).toFixed(0)}k`;

  return (
    <div style={{background:C.card,borderRadius:20,padding:"20px",border:`1px solid ${C.border}`}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14}}>
        <div style={{color:C.cream,fontSize:13,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"flex",alignItems:"center",gap:7}}>
          <span style={{fontSize:16}}>🔭</span> Future Wealth Forecast
        </div>
        <div style={{display:"flex",gap:4}}>
          {[10,20,30].map(y=>(
            <button key={y} onClick={()=>setHorizon(y)} style={{background:horizon===y?C.purple+"33":C.cardAlt,border:`1px solid ${horizon===y?C.purple:C.border}`,color:horizon===y?C.purpleBright:C.muted,borderRadius:99,padding:"4px 10px",cursor:"pointer",fontSize:11,fontWeight:700,fontFamily:"inherit"}}>{y}y</button>
          ))}
        </div>
      </div>

      {/* Bars */}
      <div style={{display:"flex",flexDirection:"column",gap:10,marginBottom:18}}>
        {scenarios.map((s,i)=>{
          const pct = maxVal > 0 ? (vals[i]/maxVal)*100 : 0;
          return (
            <div key={i}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:5}}>
                <div style={{display:"flex",alignItems:"center",gap:6}}>
                  <span style={{fontSize:14}}>{s.icon}</span>
                  <span style={{color:C.mutedHi,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>{s.label}</span>
                </div>
                <span style={{color:s.color,fontWeight:900,fontFamily:"'Playfair Display',serif",fontSize:18}}>{fmt(vals[i])}</span>
              </div>
              <div style={{height:8,borderRadius:99,background:C.border,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${pct}%`,background:`linear-gradient(to right,${s.color}88,${s.color})`,borderRadius:99,transition:"width 0.8s ease"}}/>
              </div>
            </div>
          );
        })}
      </div>

      {/* Extra investment slider */}
      <div style={{background:C.surface,borderRadius:14,padding:"14px 16px",border:`1px solid ${C.border}`}}>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
          <span style={{color:C.mutedHi,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>Extra monthly investment</span>
          <span style={{color:C.greenBright,fontWeight:800,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>${extra}/mo</span>
        </div>
        <input type="range" min={0} max={1000} step={25} value={extra} onChange={e=>setExtra(Number(e.target.value))}
          style={{width:"100%",accentColor:C.green,cursor:"pointer"}}/>
        <div style={{display:"flex",justifyContent:"space-between",marginTop:6}}>
          <span style={{color:C.muted,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>$0</span>
          <span style={{color:C.muted,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>$1,000/mo</span>
        </div>
      </div>
      {extra > 0 && (
        <div style={{marginTop:10,background:C.greenDim,border:`1px solid ${C.green}33`,borderRadius:12,padding:"10px 14px",textAlign:"center"}}>
          <span style={{color:C.green,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700}}>
            +${extra}/mo → {fmt(project(monthlyInvest+extra,horizon))} in {horizon} years vs {fmt(project(monthlyInvest,horizon))} now
          </span>
        </div>
      )}
    </div>
  );
}

// ── OPPORTUNITY DETECTION ──────────────────────────────────────────────────────
function OpportunityDetector({data, setScreen}) {
  const txns = data.transactions || MOCK_TXN;
  const debts = data.debts || [];
  const cc = CC[data.profile?.country || "CA"];
  const opportunities = [];

  // Subscription audit
  const subTxns = txns.filter(t => t.cat === "Subscriptions" && t.amount < 0);
  const subTotal = subTxns.reduce((s,t) => s + Math.abs(t.amount), 0);
  if (subTotal > 40) {
    const dupes = subTxns.length > 3 ? subTxns.slice(-2).map(t=>t.merchant||t.name).join(", ") : subTxns.map(t=>t.merchant||t.name).join(", ");
    opportunities.push({
      id:"subs", icon:"📱", color:C.teal,
      title:`$${subTotal.toFixed(0)}/mo in subscriptions`,
      detail:`${subTxns.length} active subscriptions detected. Cancelling unused ones could free $${Math.round(subTotal*0.3)}/mo.`,
      action:"Review", screen:"spend", badge:"Save $"+Math.round(subTotal*0.3)+"/mo"
    });
  }

  // High-rate debt refinancing
  const highRateDebt = debts.find(d => parseFloat(d.rate||0) > 12);
  if (highRateDebt) {
    const bal = parseFloat(highRateDebt.balance||0);
    const saving = Math.round(bal * (parseFloat(highRateDebt.rate||0)/100 - 0.065));
    if (saving > 0) opportunities.push({
      id:"refi", icon:"💳", color:C.orange,
      title:`Refinance ${highRateDebt.name}`,
      detail:`At ${highRateDebt.rate}% you're overpaying. A 6.5% personal loan could save ~$${saving}/yr in interest.`,
      action:"Debt Plan", screen:"goals", badge:"Save $"+saving+"/yr"
    });
  }

  // Tax benefits (country-specific)
  if (cc.currency === "CAD") {
    opportunities.push({
      id:"tax", icon:"🍁", color:C.red,
      title:"Tax benefits you may qualify for",
      detail:`Based on your profile you may be eligible for the Canada Workers Benefit, GST/HST credit, or Ontario Trillium Benefit.`,
      action:"Tax Tips", screen:"goals", badge:"Claim now"
    });
  } else {
    opportunities.push({
      id:"tax", icon:"🦅", color:C.blue,
      title:"US tax credits available",
      detail:`You may qualify for the Earned Income Tax Credit or Saver's Credit — worth up to $2,000/yr.`,
      action:"Tax Tips", screen:"goals", badge:"Claim now"
    });
  }

  // Low-yield savings
  const savingsAcct = (data.accounts||[]).find(a => a.type==="savings");
  if (savingsAcct) {
    const bal = parseFloat(savingsAcct.balance||0);
    if (bal > 500) opportunities.push({
      id:"hisa", icon:"🏦", color:C.gold,
      title:`Earn more on your savings`,
      detail:`$${bal.toFixed(0)} in savings at typical 0.3% earns $${(bal*0.003).toFixed(0)}/yr. A HISA at 4%+ earns $${(bal*0.04).toFixed(0)}/yr.`,
      action:"Learn More", screen:"goals", badge:"+$"+(Math.round((bal*0.04)-(bal*0.003)))+"/yr"
    });
  }

  if (opportunities.length === 0) return null;

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
        <div style={{color:C.cream,fontSize:13,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"flex",alignItems:"center",gap:7}}>
          <span style={{fontSize:15}}>🔍</span> Opportunities Detected
        </div>
        <span style={{background:C.goldDim,color:C.goldBright,fontSize:10,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",padding:"3px 8px",borderRadius:99}}>{opportunities.length} found</span>
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        {opportunities.map(o=>(
          <button key={o.id} onClick={()=>setScreen(o.screen)} style={{background:C.card,border:`1.5px solid ${o.color}28`,borderRadius:18,padding:"14px 16px",cursor:"pointer",textAlign:"left",fontFamily:"inherit",display:"flex",gap:12,alignItems:"flex-start",transition:"all .18s",width:"100%"}}
            onMouseEnter={e=>{e.currentTarget.style.borderColor=o.color+"66";e.currentTarget.style.background=o.color+"08";}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor=o.color+"28";e.currentTarget.style.background=C.card;}}>
            <span style={{fontSize:20,flexShrink:0,marginTop:1}}>{o.icon}</span>
            <div style={{flex:1,minWidth:0}}>
              <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:3,flexWrap:"wrap"}}>
                <span style={{color:o.color,fontWeight:700,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{o.title}</span>
                <span style={{background:o.color+"22",color:o.color,fontSize:9,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",padding:"2px 7px",borderRadius:99}}>{o.badge}</span>
              </div>
              <div style={{color:C.muted,fontSize:11.5,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.5}}>{o.detail}</div>
            </div>
            <div style={{color:o.color,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,whiteSpace:"nowrap",marginTop:3}}>{o.action} →</div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ── MONEY WRAPPED ──────────────────────────────────────────────────────────────
function MoneyWrapped({data, onClose}) {
  const [slide, setSlide] = useState(0);
  const txns = (data.transactions || MOCK_TXN).filter(t => t.amount < 0);
  const income = (data.incomes||[]).reduce((s,i)=>s+parseFloat(i.amount||0),0)*12 || 50400;
  const totalSpent = txns.reduce((s,t)=>s+Math.abs(t.amount),0);
  const totalDebt = (data.debts||[]).reduce((s,d)=>s+parseFloat(d.balance||0),0);
  const invBal = (data.accounts||[]).filter(a=>a.type==="investment").reduce((s,a)=>s+parseFloat(a.balance||0),0);
  const bal = parseFloat((data.accounts?.[0]?.balance||1243).toString().replace(/,/g,""));

  // Category analysis
  const cats = {};
  txns.forEach(t => { cats[t.cat||"Other"] = (cats[t.cat||"Other"]||0) + Math.abs(t.amount); });
  const topCat = Object.entries(cats).sort((a,b)=>b[1]-a[1])[0] || ["Food","340"];
  const lowestCat = Object.entries(cats).sort((a,b)=>a[1]-b[1])[0] || ["Transport","45"];
  const biggestTxn = txns.sort((a,b)=>Math.abs(b.amount)-Math.abs(a.amount))[0];
  const netWorthChange = Math.round(invBal + bal - totalDebt + 2400); // mock positive change
  const {score} = calcHealthScore(data);
  const year = new Date().getFullYear();

  const slides = [
    // Slide 0: Opener
    {
      bg:`linear-gradient(160deg,${C.green} 0%,#1A3D2A 100%)`,
      content:(
        <div style={{textAlign:"center",padding:"0 8px"}}>
          <div style={{fontSize:56,marginBottom:16}}>🌱</div>
          <div style={{color:"#ffffff99",fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",letterSpacing:3,textTransform:"uppercase",marginBottom:8}}>Your {year} in review</div>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:38,fontWeight:900,color:"#fff",lineHeight:1.1,marginBottom:12}}>Money Wrapped</div>
          <div style={{color:"#ffffff88",fontSize:14,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.7}}>A year of growth, decisions,<br/>and financial wisdom.</div>
        </div>
      )
    },
    // Slide 1: Net Worth Change
    {
      bg:`linear-gradient(160deg,${C.teal} 0%,#0A3A4A 100%)`,
      content:(
        <div style={{textAlign:"center"}}>
          <div style={{color:"#ffffff88",fontSize:11,letterSpacing:2.5,fontFamily:"'Plus Jakarta Sans',sans-serif",textTransform:"uppercase",marginBottom:12}}>Your net worth changed by</div>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:64,fontWeight:900,color:netWorthChange>=0?"#6EF0A0":"#FF7070",letterSpacing:-2,lineHeight:1,marginBottom:8}}>{netWorthChange>=0?"+":""}{netWorthChange>=0?`$${(netWorthChange/1000).toFixed(1)}k`:`-$${Math.abs(netWorthChange/1000).toFixed(1)}k`}</div>
          <div style={{color:"#ffffff88",fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:24}}>{netWorthChange>=0?"You grew richer this year 🚀":"You're building the foundation 🏗️"}</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            {[
              {label:"Invested",   val:`$${(invBal/1000).toFixed(1)}k`, icon:"📈"},
              {label:"Health Score", val:`${score}/100`,               icon:"💚"},
            ].map((s,i)=>(
              <div key={i} style={{background:"rgba(255,255,255,0.12)",borderRadius:16,padding:"14px 12px",textAlign:"center"}}>
                <div style={{fontSize:24,marginBottom:6}}>{s.icon}</div>
                <div style={{color:"#fff",fontWeight:900,fontFamily:"'Playfair Display',serif",fontSize:20}}>{s.val}</div>
                <div style={{color:"#ffffff77",fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",marginTop:3}}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      )
    },
    // Slide 2: Spending Story
    {
      bg:`linear-gradient(160deg,${C.purple} 0%,#1A0A3A 100%)`,
      content:(
        <div style={{textAlign:"center"}}>
          <div style={{color:"#ffffff88",fontSize:11,letterSpacing:2.5,fontFamily:"'Plus Jakarta Sans',sans-serif",textTransform:"uppercase",marginBottom:12}}>Your spending story</div>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:48,fontWeight:900,color:"#fff",letterSpacing:-1,marginBottom:6}}>${(totalSpent/1000).toFixed(1)}k</div>
          <div style={{color:"#ffffff88",fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:20}}>spent across {txns.length} transactions</div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            {[
              {label:"Biggest splurge", val:biggestTxn?`$${Math.abs(biggestTxn.amount).toFixed(0)} — ${biggestTxn.merchant||biggestTxn.name}`:"None", icon:"💸", color:"#FF9EBC"},
              {label:"Top category",    val:`${topCat[0]} ($${Number(topCat[1]).toFixed(0)})`, icon:"🏆", color:"#FFD166"},
              {label:"Lowest spend",    val:`${lowestCat[0]} ($${Number(lowestCat[1]).toFixed(0)})`, icon:"✨", color:"#6EF0A0"},
            ].map((item,i)=>(
              <div key={i} style={{background:"rgba(255,255,255,0.1)",borderRadius:14,padding:"12px 16px",display:"flex",alignItems:"center",gap:12,textAlign:"left"}}>
                <span style={{fontSize:22,flexShrink:0}}>{item.icon}</span>
                <div>
                  <div style={{color:"#ffffff66",fontSize:9,textTransform:"uppercase",letterSpacing:1.2,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:3}}>{item.label}</div>
                  <div style={{color:item.color,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:13}}>{item.val}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )
    },
    // Slide 3: Money Personality
    {
      bg:`linear-gradient(160deg,${C.orange} 0%,#3A1500 100%)`,
      content:(()=>{
        const p = calcPersonality(txns, data);
        return (
          <div style={{textAlign:"center"}}>
            <div style={{color:"#ffffff88",fontSize:11,letterSpacing:2.5,fontFamily:"'Plus Jakarta Sans',sans-serif",textTransform:"uppercase",marginBottom:12}}>Your money personality</div>
            <div style={{fontSize:64,marginBottom:10}}>{p.emoji}</div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:26,fontWeight:900,color:"#fff",marginBottom:12,lineHeight:1.3}}>{p.name}</div>
            <div style={{display:"flex",gap:6,justifyContent:"center",flexWrap:"wrap",marginBottom:20}}>
              {p.traits.map((t,i)=>(
                <span key={i} style={{background:"rgba(255,255,255,0.15)",color:"#fff",fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,padding:"5px 12px",borderRadius:99}}>{t}</span>
              ))}
            </div>
            <div style={{background:"rgba(255,255,255,0.12)",borderRadius:16,padding:"14px 16px"}}>
              <div style={{color:"#ffffff88",fontSize:10,textTransform:"uppercase",letterSpacing:1.2,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:6}}>Your coach says</div>
              <div style={{color:"#fff",fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.65}}>{p.insight}</div>
            </div>
          </div>
        );
      })()
    },
    // Slide 4: Share / CTA
    {
      bg:`linear-gradient(160deg,#1A3D2A 0%,${C.green} 100%)`,
      content:(
        <div style={{textAlign:"center"}}>
          <div style={{fontSize:52,marginBottom:12}}>🌱</div>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:28,fontWeight:900,color:"#fff",lineHeight:1.2,marginBottom:8}}>Here's to an even better {year+1}</div>
          <div style={{color:"#ffffff88",fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.7,marginBottom:24}}>Keep checking in, keep improving your score, and let Flourish guide every money decision.</div>
          <div style={{background:"rgba(255,255,255,0.12)",borderRadius:16,padding:"16px",marginBottom:20}}>
            <div style={{color:"#ffffff88",fontSize:10,textTransform:"uppercase",letterSpacing:1.4,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:8}}>Your {year} number</div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:52,fontWeight:900,color:"#6EF0A0",letterSpacing:-2}}>{score}</div>
            <div style={{color:"#ffffff88",fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",marginTop:4}}>Financial Health Score</div>
          </div>
          <button onClick={()=>{if(navigator.share)navigator.share({title:"My Flourish Money Wrapped",text:`My Financial Health Score is ${score}/100. Check yours on Flourish! 🌱`,url:"https://flourishmoney.app"}).catch(()=>{});}} style={{width:"100%",background:"rgba(255,255,255,0.2)",border:"2px solid rgba(255,255,255,0.4)",color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:14,padding:"14px",borderRadius:99,cursor:"pointer",marginBottom:10}}>Share My Wrapped 🔗</button>
          <button onClick={onClose} style={{width:"100%",background:"none",border:"none",color:"#ffffff66",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,fontSize:13,padding:"10px",cursor:"pointer"}}>Back to Flourish</button>
        </div>
      )
    }
  ];

  const cur = slides[slide];

  return (
    <div style={{position:"fixed",inset:0,zIndex:999,background:cur.bg,transition:"background 0.5s ease",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"0"}}>
      {/* Top bar */}
      <div style={{position:"absolute",top:0,left:0,right:0,padding:"48px 24px 16px",display:"flex",gap:6}}>
        {slides.map((_,i)=>(
          <div key={i} style={{flex:1,height:3,borderRadius:99,background:i<=slide?"rgba(255,255,255,0.9)":"rgba(255,255,255,0.25)",transition:"background 0.3s"}}/>
        ))}
      </div>
      <button onClick={onClose} style={{position:"absolute",top:52,right:24,background:"rgba(255,255,255,0.15)",border:"none",color:"#fff",fontSize:18,width:36,height:36,borderRadius:"50%",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>

      {/* Slide content */}
      <div style={{width:"100%",maxWidth:400,padding:"0 24px",animation:"fadeUp 0.4s ease both"}}>
        {cur.content}
      </div>

      {/* Navigation */}
      <div style={{position:"absolute",bottom:48,left:24,right:24,display:"flex",gap:12}}>
        {slide > 0 && (
          <button onClick={()=>setSlide(s=>s-1)} style={{flex:1,background:"rgba(255,255,255,0.15)",border:"2px solid rgba(255,255,255,0.2)",color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,fontSize:14,padding:"14px",borderRadius:99,cursor:"pointer"}}>← Back</button>
        )}
        {slide < slides.length-1 ? (
          <button onClick={()=>setSlide(s=>s+1)} style={{flex:2,background:"rgba(255,255,255,0.25)",border:"2px solid rgba(255,255,255,0.5)",color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:15,padding:"14px",borderRadius:99,cursor:"pointer",boxShadow:"0 4px 20px rgba(0,0,0,0.2)"}}>Next →</button>
        ) : null}
      </div>
    </div>
  );
}


// ── EMPTY STATE COMPONENT ──────────────────────────────────────────────────────
function EmptyState({icon, title, body, action, onAction, color}) {
  const c = color || C.teal;
  return (
    <div style={{textAlign:"center",padding:"32px 20px",background:C.card,borderRadius:20,border:`1px solid ${C.border}`}}>
      <div style={{fontSize:44,marginBottom:14}}>{icon}</div>
      <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:900,color:C.cream,marginBottom:8,lineHeight:1.3}}>{title}</div>
      <div style={{color:C.muted,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.7,marginBottom:20,maxWidth:260,margin:"0 auto 20px"}}>{body}</div>
      {action&&onAction&&(
        <button onClick={onAction} style={{background:`linear-gradient(135deg,${c},${c}CC)`,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,fontSize:13,padding:"12px 28px",borderRadius:99,border:"none",cursor:"pointer",boxShadow:`0 4px 16px ${c}33`}}>{action}</button>
      )}
    </div>
  );
}

// ── FLOURISH LOGO MARK ────────────────────────────────────────────────────────
function FlourishMark({ size = 24, style = {} }) {
  return (
    <img
      src="data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAQABAADASIAAhEBAxEB/8QAHQABAAMAAgMBAAAAAAAAAAAAAAECAwQFBgcICf/EAF8QAAIBAgQEAwQECQUKCQoGAwABAgMRBAUhMQYSQVEHYXEiMoGRCBOhsRQjQlJicsHR0hUzlbPhFhckQ1OCkpSi8CUmNTdEVld0wjQ2RlRjZJOjsvEJGEVHVYOFc4T/xAAbAQEAAwEBAQEAAAAAAAAAAAAAAQIDBAUGB//EADoRAQACAgEDAQMJBgYDAQEAAAABAgMRBBIhMQUTQVEGFCIyYXGBkdEVI0JSobEWM1PB4fAkQ/Fyov/aAAwDAQACEQMRAD8A+wAAAAAAAAAAAAAAAhgSCESAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIdyQAAAAAAQCSGgAIAEkkIkAAAAAAC4AAAAQwHuQBNySpIEgi5IAAAQyCWQAJRAAsCLkgALkXAkggmwBEgAACLgSAADKksgCSSCQAAIAAEgAAAAAAAAAAAAAAAAAAAAAAAAAAABDYE3BUm4Egi5IAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADKlrgCpK3DCAkAAAAAAAAAAQ9yCWQAAAAAACSAAAAAAAACwFSbEgAAAAAAEWJAAAAQyAABKIJQEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAhkFhYCoJIAEkACwIRIAAAAAAAAAAAAAAAAAAAARckAAAAAAAAAAAAAAAAAAAAAAAAAAAIuEyABYAAAAAAAAAAAAAAAAAXAAi5AFgVAAsVAAAASmSVAFgRclMAAAAAAEElQAAAAAASQWAqCWgBAJIAFkVJQEgAAAAAAAAAAQySGBAAAlIkAAAAAAAAAAAGBDYIAEpkkEgAAAAAAAAAAAAAEEoixIAAAQyCSAABYAAAAAAAAAAAAAAAAAAABAZAAkgAWBBIAEEgAAAAAAAAAAAAAAhsMgACSABYqAJRJUsgAAAAAAAAAAAAAAAQwFyAAAAAAEgQAAAAAAAAAALAAAAABUsQwIAAAlCxAFgQSAAIYEkEEgQStyCQJAAEAgAWQIRIAAACGGSgIsSAAAAAC5CYDqSAAAAAAAVBYARYkAAAAAHUAAAAAAAC4AAAAAADKlioAsipKAK9yQAAFxcAAAAAAAACGybhogCQRclgVBNhYCCRYkCoJZAAsipKAkAAAAAAAAAAQSABFiQAAAAgglkAAABZAhEgAAAAAAAAAAAKliAIAAAAAAABKDRBYCoJsLAQAAAAAsAAABFwJBFybgABcAQ0SAIBBIEgABYMBgVAAAEk2AqAAJW5JUsAAAAAAAAAAIYEErcglASAAAAAAAAAAAAAAAAAAAAYAi4IAFkVLLYAAAAAAFSWLAQSLEgQmSQwBAAAEkFkAQAAAAAGABFiQAAAAAACGQABJIQAAAAAAAAAAENgTcXKgCwIJAAACoJsLAQCbE2AgkAAAAAIuAJBCJAAAAAGBUAAAAAJIJQCxIAAAAVBLIAEpEFgAAAqCSAAJsLASQyQBAIAAlEEpgSBci4EkMXIAAACUSQhcCAAALIgkAAAAAAAAAQwyAJRJCJAi4uGQBZAhEgAAAAAAAAAAAAAAAAVBJAAsQSAAAAAAAAADBDAgAACQkSBFiQAAAAAAAAAAAAAAAAAIFiQAAAAAAAABGpIIAgAAAABKJIRIAAAAAAIuSQ0BIZFiSBUAEgCbBAESABBIAAPYBgVAAAAACxCJAAAAAABDRIYFSxUsgIvqSAAAAAAAAABUFmQBAAAAAAAAAAAAlIkCoJsLAECSoEpklSUwJAAAAABYAAAAAAAi+pJUATcEEgSgAAAAAAAAAAIZJDAgAlIASAAAAAAAAAAAACxFiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBAAAAmwEAlkASiQAAAAAAAAAAAAggsRYCCULEgAAAAAAMACoLACoLWFgIW5JC3JAAAAAAAAAWAAAAAAAAAAAAACHuSVAAAAAAAAAAAAWKkoCQAAIZIAqTYWJAAAAAAAAAAXIuAD2AsBAJsLAQWFgAAAAAAAAAAAAAAVJDIAm5KKkoCQAAAAAAAAABDYuGQBNyAALAIAAAAAAAAAAAAAAAAAAAAAAAAAAABDQsSAAAAh7hB7hASAAAAYAFQBYEIkAyLhkASiQgAAAEdSQAAAAAAAAABDJuQBBYqWAAAAAAAAAAAAAACAAAAAAA2BDIJIAAAAAAAAAEoglbgSAAAAAAEXAkAAAAAAAAhklQAAAkkqTcCQRckAAAAAAAAAAAAAAAAAAAAAAAAAAAADIAkEJkgBYABYixIAAhi4Egi4uBIAAAAAAAAAAAAAAAAIbFwJBFyQAAAAAAAAKlkAAAAAAAVJQYQEgACoJIAEoglASAAAAAAAAAABDDGoEAAAWKlgAAAEXDIAsmCpIBsXIAFrghEgAAAAIYBsgAAAAAAAkWC3JAAAAAAAAAAEMAQABKJKkgSCpKAkAACCQBUAAAAAJIAFgQiQAAAAAAAVAsCCQAAAAAAAAAAAEMkhgQASgCJAAAAAGCGgBBNhYCATYWAgsLAAAAAAAAAAAAAAAhkFgBUsLAAAAAAAAAAAAAAAAACOpIAAAAQyCXuQALIgkAAAAAAAAAQyQBFiQAAAAWAAAAhgQAAAAAAEpAESAAAAAh7kgCEiQABFiQBAsSAISJAAAAAAAAAAEMkAVBYh7gQAWQEWJAAAAAAAIZBYMCoAAAmwsAJAAAAAAQBJUAASiCUBIAAAAAAAAAABgARYWJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEPcgEoAiQAAAAAAAAAAAAAAAAAAAAEMkAVBNiAAAAEogAWAWwAAAAwmQyALAqALAqWAAAAAAAAAAXAEEgAAAwBUACVuSQiQAAAAAAAABDJAFQSyALAgm4AAAALHV8QcR8P8AD9B188zrL8tguuJxEYP4Ju7CJmI7y7Qg9R8QfSK8Mcsc4YbNMTmtRaKODw8nF/50rI8Hzn6VWEjdZNwlVqPpLF4lR+yKZDC/Kw182fSlhofHmZ/Se49xEpfgOX5JgYvb8TKq18W0dBi/H7xTxV/+McMP5UMHSj96Y2wt6jhjxt9x28hZ9n8j4JxHi94l1n+M40zTXpCUY/cjhVfEjj6tfn4zzv4YuS+4jqZT6rj/AJZfoJyy/NfyHLL81/I/PWXHPGk7ufF2eyv1/Dqn7yY8ZcXJf+deff0lW/iI61J9XpH8L9CeWX5r+Q5Zdn8j8+lxlxba/wDdTn39JVv4i64x4u2fFWff0lW/iI9or+2Kfyy/QLll+a/kOWX5r+R+fv8AdhxZ/wBaM9f/APka38RouL+LF/6UZ7/SNb+Ij2sK/tqn8r7+5Zfmv5Dll2fyPgZcX8WK3/GnPf6RrfxGq4w4tX/pTnv9I1v4iPbQftun8svvXlfZ/Ijll2fyPg7+6/izrxRnn9I1v4iVxdxX/wBaM9/pGt/EV9vCP25T+SX3hyy/NfyHLL81/I+FY8XcVWTfE+d/0hV/iNo8XcVJv/jNnf8ASFX+Ij5zHwV/b2P+SX3Lyy7P5Ecsuz+R8QLi3in/AKy51/r9X+IuuK+KN/7pc5/1+r/ER86j4I/b+P8Akn8325yy7P5Dll2fyPidcVcT9OI85/1+r/EWjxXxPq/7o85t/wB/q/xEfO4+Cv8AiDH/ACT+b7W5Zdn8hyy/NfyPi6PFXE2390Wcf69V/iNI8VcSr/0jzj/Xqv8AER88j4I/xDj/AJJ/N9m8suz+Q5Zdn8j43XFXEv8A1izf/Xqn8RaHFHErv/xhzf8A12p/EV+e1+Cv+I8f8k/m+xuWXZ/Icsuz+R8fx4o4j0/4wZv/AK7U/iNY8TcR2v8A3QZt/rtT+Ij5/X4In5S4v5J/N9d8r7P5E8suz+R8jLibiL/+ezX/AFyp/EaR4m4iX/69mv8ArlT95H7Qr8Ff8TYv9OfzfWvK+z+Q5X2fyPk1cTcQ/wD87ml/++VP3mi4k4ht/wAvZp/rlT95H7Rr8D/E2L/Tn831byvs/kOV9n8j5XjxJxBy3/lzM/ji6n7y64jz+1/5czP/AFup+8j9pV/lP8TYv9OfzfUvK+z+RPK+z+R8uLiPPt/5bzP/AFuf7yXxHnyWud5n/rc/3kftOv8AKn/EuP8A05/N9Q8r7P5DlfZ/I+X3xDnv/wDN5l/rc/3llxDnyTf8tZl/rc/3lf2pX+U/xNj/ANOfzfT1pfmv5C0vzX8j5jfEWer/APWcy/1qf7y0eIs9t/y1mP8ArU/3j9q1/lT/AIlx/wAk/m+muV9n8hyvs/kfNi4iz1K6znMV64qf7y0eJ+Io3tnmYJdvwiX7yv7Wp/LKY+UmL+SX0jYaHzn/AHX8TQ2z3Hv1qtm1Ljvi6m7xzzEPylGMvvQ/bGP31lePlHg99Z/o+hrEWPRNDxL4spW58fRreU8PH9ljs8J4sZ1B3xWAwFZL81Sg/vZpX1bBPncN6evcS3ncfg9xg9bYLxbwEl/huUYik+9Kop/fY77LvELhXGNRePlhpv8AJr03G3x2OinP49/FodmL1Pi5fq3j+393lYMcHi8JjKf1mExVHEQfWnNS+42Z1RMT4dsTExuAAEpAAAAAAAAAABFiQAAAAAAAAAAAAAAAAAAAAAAAAAAYAFSxFtSQAsAAAAEEogkCHuLEgCoJsLAESAAAAAAAAyLkAAAALELckAQySGBABKAkAAAAAAAAAAAGVIFgEAIZB1fFPEeRcL5TPNeIc1wuW4KG9WvPlu+0VvJ+Suz5p8TPpVzlOrgPD/K1CN3H+UsfC7fnCl09ZP4FojbLJmpjj6Uvp/Os2yvJMvnmGcZjhcvwkFeVbE1VTivi9z0lx19KDgzKHUw3DWDxXEGJimlVX4nDp/rS9qS9EfI/FfFXEHFmYPMOIs4xeZYh7Sr1Lxh5RjtFeiR1F/Mnpefl51p7U7PbHGv0g/EviR1KdLNoZJhJN2o5bD6t27ObvJ/NHq7G4nEYzEyxOMxFXFVpO8qlabnJv1Zg9EWWwcN8lr/WlaLaszdS8zCO2q28zRNehWWMtoyV3qaQeu5x76b2NYPXQrKkuRF7rc0jszGLbfc0irS7FGUtIu2tzTnbl2ZgtFtr5svBu5WVJbxb27miXmZw1Wj1NbK17lZUlZJ3TvY0i9SltLomGj13KSylvG3c0jr1sZwkrXtoaR7vRFJZy1jvpqXTRkm0aLu9iirWDaujaEr6XOPFpu9/gaRb2KypLkRevc1TfN5HHp325jSMm3vYpLOXJepNm0ZU723ZyqaurrYpKkpg0mrPUlXbba1Ii7Pz6MunZdyikrxk0ldm8W97nHVuiNY+7Za2KyrLeMnfaxvHSXl6nFjJ2038zWLut7FJhnLfnV3pqXbvK92Yxn8+ppF6FJhSW8ZNq7a9TRvqmcZNXVnozVNLQiYQ3hK6d90bczasjjQdvM2hPzsiswmGqe6bLr3tTG6V9C8JK2u5SYS0vd+ZMm7GfN2epDlqyuktVLVJ/O5pB+35nH2bNaba0fYrMaTDkqatZu7EpXRipXemgUnzXTKTCYbt3dmLN3tsZxlo231LJ7vZFJhaE3vbuizfsuxRy8wpJPXqVmFlr+dyya5m9jJStpbvrcvey3uV0vVrh8TXws/rcNXq0J30dObi/sPLsk8RuJcvcYVsTDH0l+TiI3f+ktTwpPUun7XmbY8uTFO6Tp1YeRkxTvHaYe7Mi8T8kxjjTzGlVy6q/wAp+3T+a1XyPNsHisNjMPHEYTEUsRRltOlNSi/ij5g5rb7nOyjO8yybEfX5bjauGl1UX7MvVbM9LB6vevbJG3tcb1zJXtljcfH3vpcHq/hfxXw9SUcPxBh1Qlt+E0FeP+dHdfC57JwGMwmPwsMVgsRSxNCfu1KcuZM9rBycWeN0l9Bx+Zh5Mbxz+HvbgA3dIAAAAAAAAAAAAAAACBqSAICJsAAAAAAAAAAAAAAAAAAAAAACOg6ggCwICYEgAAAAAAABgMCoAAAAAWKkgSAAIJAAAAAAQwJBFyQAAAEWJOBxDnOV8P5Nic4zrHUcDgMLDnrV6srRiv2t7JLVvYHhzkejvGj6RfDnB31+UcNKjn2eQvGTjP8AwXDS/Tkvea/Nj8Wj0p47/SGznjGVfIuFJYjKOH3eFSony4nGL9Jr3IP81avq+h6IZeK/F5+fl+6n5u8454w4k41zmWbcTZpWx+J1VNSdqdFfmwgtIr0+J0Sb0Idwr2uXefMzady3jJ9i3TQzhqtTSNyrOV0WjYRJRSVF4+exorbFIetmXS7lZVXt3NIrVoz30RpFvuQpLemrK2xqlfUwp7WRutOpSWNkyt6kqK/tK3s/IundFZhWWtOy62NItW3KRs1e/wAC3SzKypMrp9DRdv2mKd3YmG9+hWWUuTFro7G0HeOj1RhB6PoawbV7lJVltFJq7L7XRSMo2XT4k3TV73KSpK6Vutmarq77mCSb3OQ9vMpLOUp3W9jaCujC6fQ2pO+i0IlSXIhbS2jRvGej8jixlurGivs9UZTDKW3NfS9vM0jszjy0eprCVndqxEomG8bptX36GsFpa9jjwfVGzel76lJhVe6v27mkWtjC9+ptB3e+nmVlSYbbM1jK909LeZxlJxdnrc2Tu/s3KzCumytpyp+ZtB/BM412lqzaE3FebK6Q2i3y7aM15rxdranH5mu3zJjJfApJpu5+1Z6ss5Kxgp332Lc3VaWIG3O7vv2J5nzPoYPST7+pdS7FZhLkc6vdbmilquxxFJp2TN4y2exSVm9/n6i+t9kjC6bsnYnmvoyhENuZWLOTS0MVLyLx0eu5WV4ho2+Z6D2r2KRbvq/U2itLvYqnSE9VdbE3vfuVbdrp2RDk0r7DS8Lxb22sSurXQpFtt9dBdLrr0K6Who5JtrqZza77Gbk76sNq5Gl4ROV2357Hb8NcQZrw/iViMtxUqV37dN6wn6x6nStpO0S/NZJftLVmaTus916XtS3VWdS9/cFeIeV59KGExfLgMweihOXsVH+i+/k/tPNT5KlLrfW57H8P/E7EZb9XlvEEqmJwa9mGI3q0l5/nR+31Pb4nqm/o5vz/AFfR8H1neqZ/z/V7uBjgsVh8bhKWLwlenXoVY80KkHdSRsezExPeH0ETExuAAEpAAAAAAAMACoAsCLi4C5JUAWIuLkATckqSgJAAAAAAAAAAAAAAABUEiwEEomwAAAAAAAAABgAVBYAVBYgALEgAAAAAAAAAAAKlgAAB1vE2eZXw3kOMzzOsZTweX4Om6larN7Lol3bdkktW3YEzplxhxLkvCPD2Jz7P8dTweAw6vKctXJ9IRW8pPokfB3jv4vZx4nZyoyU8DkWFm3g8CpX12+sqW96bXwitF1b4fjv4rZv4n8SvEVefCZNhZOOX4Hm0gvz596j6vpsvP12maRXTy+RnnJ9Gvhe611sQu+pVPX1+wulYttyHUstLBrzLLsQqmK6Gi06aoorF09NyFJXTLu1rX1Muu5pFu2pWVJXg18TRPXUzXVW1NI81rFZVla/lYunpoUv5F09EiqktoWV3ezNYyOOml0NKbkl5lZZy2um7mkXrYyjJmkW7FZZy0UvaL3Mo6Pexon9pVnK8XpruaxXS+hls7NmkdnZ6FZVlqm9rl3K2v2GN0urZdO1ne5WVJhspLfW/Y0jaWl9WYpvrp2NabUuuxSYVltDyNOayfmYxava3xNo8yjbr3KzDKV4vS/U1TSeu/cwu72vqXi2rpvTqVmES5HNL4Gik919phGae7aRopN9UykwpMNn1dtSVdtK5SLXMlL7zWFndxKSzlpB8rdn8DXmtGz6mCsrWd2a6W1VymldLx030NXLs9UYpaIvJ31KzCsw0jJxe+5tBq2mqTOMmr22aNoy9nmtb9pWVZhyOdKV11NFL2lfUxU0rO+heElulZFUaa3auyyna6a+BnFptrdlm7aX17lJRprGWnn5mkXvdnHTXVu5rGWmrINLN9+pKatqyqaelvtEmtbaNFZTppzNPmexdT9m1zBaLfcvGVku5WYTENVLW+3S1y6lfRPRGEHaXZlubpIpMLRDdy6p6l1K+m/xME9bW+0vF7p7lZheG6d27/A0ckktTKDjbV6lntpZvzZSUwtKS0erZLl1M3NNpNl+a19NCqYhN1d3Ibu9V6FHJczvv6kqVtLheIJWu7vUiTTt8iG1drt5lU9yFkO92g2+5Vu/Unpf7CNA2lsVau7367lZNr2bkNpb6IjRp5f4fcc47hXF/VyUsRltSV62Hvqv0odn9/wBp9CZPmeBzfLaOY5diI4jDVleE4/amujXVHyTKV93qzyrw241xfCWaPm562W15L8JoJ/7cf0l9u3Y9Tg86cM9F/q/2e36b6lOCfZ5J+j/Z9MA4+XYzC5hgaONwVeFfD14KdOpF6STOQfRRMTG4fVRMTG4AASkAAAhkhgVAAAAAACwECxIAqAAJRJBKAAAAAAAAAAAAGAAAAAAAAAAAAAAAAAAADAggEoCQAAAAAAAAAAAAAAAVnJRi5Saikrtt2SR8MfSt8X3x3n/9zmRYhvhvLartOL0xldaOp+qtVH4vqre2fpn+KkuH8lXAWR4nkzTM6XNmFSnL2qGGf5HlKev+bfuj4yT0NKV97h5WX+CEpllo73KPyLRZdwNEyybKdCyuVVXi+jLplF5F42JVESn1sQ7/ADEd7ESq0VtzWOq1MovojWKS0bKSpLS3ndl1s02UVnrexaL11ZWWa61RaKdt9QvX7C6WlmyJVlK00voX12TuZv3i0bp+Vyss5bK9vQ130uZLSV97F01r0uVlSWsdVa5rqlZMwi7PfQ2vbW5EqTCy1bVrluaz0ehle8rX+ZdPv8CswrMNIyTNovWy26mEGk3pqaQdnqyswpLWD7q5rTXtdzBNJbO5qpKy3TKSzltGSvda9DWMm+px4a3tobRlZtFZhSYara7YjK7ehXm12smWSasmtSswpLRXSbTNISST1dzj39rd6F4yabu7XKzCrkRkm9W2+htGb5WpHEpyV+U3i9LP/wC5nMKTDkQlazvb1N4yvtucWMrS1X9htB6tN6FJhDWN7NXZpe0Xbb12MlJN3u79GSrOTV9Sso00h7z09DSMr6X1Rinr7z0NIu0X0ZWVZhte6u18Eaxemj07GEGk/U1jd212KSrptFvleliym7+RmnLdu6WjClZ+9p2ZCGnMnJu+peMrXv1MbvW9lcOSWj1t5lJTpyObV6k8yad9X3uYt3uujLN92tERoa3VtHexLfKtJfMyUo20Za7StYrpMQ1jK+pbms7d92Yp6vXUtd8zV7orK0Q2Ut9TZS0aOKpXdr37I0jLpu/UpMLQ5MJaOzu2Xcno1t1OPCWjjsy8JPXsjOYWiGkt/eS7F+ZpO2rONKSUttzVOSirPUqmIS3zPRaPcKa11t6lb3l7zv2HV66ELxBJtNu5HM7NtlJvXtZ6ESlrv8AlpzReglJWae5i5LvaxKerdydCZvVopKV726EtrXpcynJ+XzGglJK/co3fW5Sct1cpKSve9iYhaI29oeCnHLybMVkWZ1rZbip/ipyelCo//DLr2evc+gD4tc1e59FeB3GSz7JXk+Oq82Y4CCScnrVpbKXm1s/ge36dydfurfg+j9J5n/ovP3fo9kAA9d74AAAAAqCWQAJsCQKk3BAEggAAAAJRAAsAAAKkpgSAAAAAAAACOhAFgQmSwAIJAAAAARcA2CAAAJAIkAAAAAAAAAACLEgAAAPHvEji3LuBuCc04ozRp0MDRco072dao9IU15yk0jyE+L/pz+IEs34rwvAOX128FlFq+O5XpPFSj7MX+pB/Ob7E1jcs8t+iu3z/AMU57mfE/EmYcQ5xXdfH4+tKtWnfRN7RXaKVkl0SR16v3K20JRu8qe/dpF36FltqViupZbWIZrrexZeRTtbQur3evqQqsm0+6NF5szv2LeQlWV+4Wu5Cva9yV5FZVldX0NY9rmS6euprf5FZUlZaGkWu2pkvM0j1aREqNIt3NE13MoaNl76aFVJXs0+jZdNpuxn0snqXW129CqjT2e7Zp01MW1fRm0Pa2+0hnK2yWpqpX+G5lbd7Fo3112IlWWqte97lou0XfvoYx0erL3u7RIlWWqb5nqmaRlvG2hhGVn6mkG1KzKypLkK+xePZIyu3Le5ok2tNSjNpGSvvYupO29l0Mv0umxKavbqRKkuTFycbbtF1ps7mMH7dtmaJ2u76FJRpdNa66svF7ozUl6I0Tiu9ykqrpq10aJK+m9rmV25Lrc1jdtW311KSrMNlrrfVmsW0r29WYQdmbpu/YpKmllLVq+jNIJ69GZpa2srdzZW1tqUlWR6Npsvza6syUlZ3dy8bX5rdCiumy6OLa73N4aLSTXqcZS6N6mikla76FZNORzrW+xLkrW7mKmnbTQvKzSK6V0lt2S3XVkvd207lGt2nqSn3ei7ETC0QvezTvdFud3dtEZPvfchSe/w3KyiIchN6bXRo2ktOr1uzjRb1SsmzRPq3sispiG/M07dPUu5bu9jBS5nZPQ0Tbjo/UrK8LS0i3eyZKvyu33lXyvRb9y0L9XotiswnTVaJ6aepopNRaRhHeXLuXTtFK+vmZyvDSLbV21v0NrLlu3t1MaaaTXRnIjFc27tbYzmV4Ra8tvIShFJ6s0UHf1Lzhpbaxn1JcKSfNu7+YlfXrbc3lTuUcHrZX+I6ldMZJbbIjZWvcvOOl7aroUna3mXiUqOSenUpUkrPyEu19TOWjZdbW2VWTu9dDKct9dS9RvW+5hK17t7FoTHZbm1ftXO04Vz7G8PZ7hc3wUkquHnflb0nH8qL8mtDp76779BfS7/+xeJmJ3DStprMTHmH2hkOaYTOsnwma4GfPh8VTVSD6q+6fmndP0OcehPo18WSo5hiOE8ZU/FYi9fB3fuzS9uC9Vr6p9z32fS8fNGbHFn2fE5EcjFF/f7wAG7pAAAIJAFSyIIAliwAEAsQBAAAAAAAAAAAsgQSgAAAAACOgJAEWDJAFSwAAAAVAAAE2FgCRJCJAAAAAAAAAAAAAAAAQHj3iRxTheCuBc34oxfLKGAw0qkIN2+sqPSnD4yaR+Zuc5hjM3zbGZrmFZ1sZjK869eo95Tm25P5s+q/p78XunhMj4Hw1SzrSeY4xJ/kxvClF+r538EfJF7m1I1G3ncq/Vbp+CNbkxtuQ2npYleZZyrK3cukZxbNVsQrKV5kuwWr0JaV99gqm9/X7y8dvQqknfoWWuzImFZWi+5ayv3ZnFvuSmrlZVlqpdnqXu7WSuZxV9uhrFW6lZUlKeu5eL6XM1a9kX23IUaJ+qNYtX10MYtvQ05Ve6fqVVldSd2TF3uUS3TZeOxDOV4NnIp63d9TCKV2tbm8NLe1YiVJTrd73ZKi1p17loXW+upq12W25VVn1tfUvbtfzdyt9GrJFklfWRCkp6prQ0i1ul6mWreprTjeNr2IlWW8HHXUvdcu5mnZWXXQ0ilbfYpKi6XS5eK30V+5VJrqXa6rRFVExu3vqaXWqWyMoxXLq7M1V7J2v+0pKJXhqr/Yayty3e6MYyd2mjZWcVdlJZydU72Rom7buxTRN6faWjZ6J7FZQ1Tla9rF41Fd73Mklrq02a9E3Z9CkoaKTTu3a5tGbcddPNHG9TWLV3rp2KSo0i7t+T+Zq5LZu5x+be7JUnZt7IpMKt+j10LKTWn29zJPRWenZmsXZaa3KjaF7auyNed2u0tepx09Oa97Fm7J2lo+gTpo5NO1n5lo7uxjdybXNuXUnbsZyRGmidnvZojeTVyq10X/ANyej6JdSqIhdet35M0jKTT2MLq7toWjKzt1S7kTC8Q1bXVK5opJK922YKSfN0fqaqTUbK29mRK2m19dJWNY8rWrOKp3vrZm0JRTdr3XQzmYTENIv2no/nsbRit7Xt1ZWjGUpXVrvzOZRp3ja2zML30aZ0otu/3nNo0noxRotu60Z2lDD3glY4cmbTWtJlwo0bvYSpdrJna/gj00KvC67HNPIjbT2cupdF32KVKFotpHmnDvBub57UX4NQ+qoflV6t1Benf4HD4wyCWRZ1Wy6VX65U4xaqctuZNX2+Z0fvIp7SY7fFtPEyRT2kx2eG1IOOttfU41Zaux2uKp8qasddiEkmtjfHfbmtGnDm/atszOo2tGzSs9W0tzCq3zO+p0wiGVRtX069zGo9dEaVHeTTIk0td2XhZi9HvuG77siTXM/wBpWUra3sy6Y7OXleYYnKs0w2ZYKpyYnC1Y1ab7NO/ye3xPsfhvNsPnuQ4LN8L/ADOLoxqpX91vePwd18D4qk9Op7/+jBxD+E5Tj+G607zwk/wjDpv/ABctJJektf8AOPR9Py9N+ife9n0jP0ZJxz4n+73OAD2n0gCGSAAAAgkAQiSpYCHuQAAAAAAAAAABNgBBKIJW4EgAAAAAAAAACGxcgAWBBIFSwAAAAQwQAJTJKkpgSAAAAAAAAAAA9XZdweFeOvEr4S8I+JM9hU5K9LBSpUH1+tqfi4W+Mr/AImdRt8HePfFf92fi5xBnkKnPhniXh8Jrp9TS9iNvWzl8TwVkLRb7Dc6IeRadzsdr36kqxBKZCsrr5F42KLRl00FJWT7Fru5XqT01Ci9rottq9iumjv8AAlar+0hCfjoXik+hCS2LpqzVysyrMmqZdN21Kq1y8Y6ddSsqStHW6eheMURGO3c0tbXoRKmxJXv9hql7PqUTffQsk0ne9uhWVF7a6u1jRLmu92jKMddXY1grO66FVJXVkluy/M9LoqnZLsyzb5bWKqStC7vrbtqaRm7aO/cy667roXaXNo9QhaTer7Foq9iq3u90axafRkM7JjFWd9S612W3mReK236k6bt2KyovrbmvbyNk77PQ473TTNIyVm73KyiYcmPXS3xJTW7eu1jFS1i73RdNq+u/2kaUlqprq0i/NpbozKM/Z6O5pB3WurKSrK0dbtvU2ha/XzTMlo7bGyd1e9rMzlWVp73ctxzN2d/KxN9H9hCtzW6orKGsd076GikrNWt8Tjpu7v0NYN35m7eRWVWt1fmvoXhqn3Mru2rLqSSTXmVmFdL73bVn6l48rSbWqM7vTW7NIJflX+BnKF+ZRvrqXhK/vOySuZtpWXctzWho/JIpI2hNPW9vIupXvfcwpu7skr/eaxftPXW2hTaF7+yrasnWzjcqm+krF1Kzd90RKYFr1vYlPRuzfkVjJJNS9nsXm3HS65l5lURCE7rm0t6Fly7tu721OPzNu3NZpm100+4aRC0XKLTb19Lm8fyrP4s49NaaO1trnLpQvH2m1cztaIW0hRk53kk362OZQpylK+mm+pNGk7ptXR2GHw2i7nHkyxCYjalDD3ujn4eg3bQ3o4bVXR22V5biMViFRw9CpWqS2jCLbPNy8id6hviwzadOLhcJzNNo7bCYXpZtnm3D/h3jaqVTMakcLD8xe1P9yPOco4byfKUp0cNGVRf42r7T+HY2w+lcrkfSt9Gvxn9Ht8b029u9uz15knBWaZioznTWFov8uro2vJbs80yngzIspiq2Ip/hdZflVVpfyj+87+tjIxTVPV92dfiasm7t8027Rua5L8HgR+7j2l/jPiPw/wC/e9nDwMWPvpyI4n6yvClSX1dKMkrL7j1p41YVQz6hidlVw6Xxi3+9HsDDPlrU7PaSPFvGuhzYLAYi3uznB/FX/YMXIvyeFlvkncxMSr6nSJ48/Y9NYqO92zqcUrXstTusZu0mdVitG01cww2fHXh1da6k+VJHGnu1bX1OVX0vfY4VSVr2+Z6NGUM5PXTR9ysm2rBvz2Kt7u+hsspU0bv02MZu/maSl8GYTk+Z66FohaFXJXetzzPwYz1ZF4i5Xiak+ShXm8NW105Z6J/OzPCG7eQjUlTkpxbU4u8Wns1saY7dNot8GuO847xaPc+8XuQdNwPm6z7g/Kc4UuZ4rCwnN/pWtL7UzuT6WJ3G32lbRaImPeh7kE2FiVkgAAAAABFwJsRYkAVJJsAKkkgCEiQAAAAqCSALIAAAAAAAAhhkAAAALFQBYBAAAAKglkACSAAJTIAFrghACQVJQEgMqBY+cfp8528H4b5LkdOpyyzLM/rJxvrKnRg38uacD6NW58V/T7zZ4rxJyPJlK8cBlTqyV9FOtUf7KcS1I3LHPOqS+clsLsrdpks2eakstSi30NIkKytGzLxsVXqIvUKS0RaO76lL38i3W6IUW6smCEYsvFNPRkI2lbMsk7+z1I7a7ltVr0IVlKNY73TMm9dGzWnJpdiJUltC1tHZk289CkNJas1V7NlWcoenUurXK27v5l9fiuhWVZWt1v8ADuaK9tX8DO3W5tF6FVJS+Za2t6k3vtqTaN+tyb3bdtyFC7ve1i0Lt3XQq7WV3qtiZWUr2IVXSd2le5ondX6LqZNXtq79i6VnchWWsbJe8aRcWrPXsY6ptNempdPVPZdiqul9E78132L3u9Fouhir8zvoawvvbUrpWeyYtN33NE+nUiKtHZF2vaslt1KyhMU+i1NoNr4bmLi7b6ovFtNtKyKypLkXu/JF1K6slZ9iiaa3foXi9dSrPytd73d+xN21zaW6ERTS1+8J6W2V9CkkNN/avZ9DSDV0mr6dzJb8vNqaJ/EpKVk5Ldal3e19jNvXTp5ktpdNysqNab9ppO5yYSVlpex115bOTRvGUuX2ikocio/ab5b66ahT5r3STM1LS+2tiZSaltePSxnKNNafvPmbOUnFK2zb0b6HE5mmrxbXY1i3KdnKySKSNm3zXUkkuolZJ63fe4h7UWmXdL2G2t9isjHm173Nknq1orasiKa6JWNeX2FKTs09UZ9Q4yjP6y+lpdTeEbeze1jSNJN3W5yqdJyTSS5u5lbJperCjTck31Oyw9BzSv0Nsty3FYzExo4ehUrVZOyjCLb+SPaHC3hRm+KUauYzhgKb/Jl7VS3ov2s5bXvknppG5dODjZc86pG3r3DYW7Ttt0PLOHOD87zhxeEwNRUn/janswXxe/wPcXDvAXD2T8s1hvwuuv8AGV/at6LZHk0qlGjFRbjFLaKN6+mTrr5F+mP++/w9zjeiz5yz+EPX+QeF2DoctXNsXPET/wAlS9mC9Xu/sPOcvy7LsqofVYPDUcNBfmqzfq92Vq47pSjbzZxKlWc3eUm2Ut6lweH249eq3x/5/R7mDiY8UapGnPrYyEdKau+7OHVrTqO8pXMeYq5Hkcv1TPyfrz2+EeHTFYhaU1FOUnZJXb7GMG5/jZJpyXsp9I/vf7jJSWKqtJ3oUn7T/Pl0XobSet2eVa0yRbc9kxlyyT7M6bxli3wtSqr8nEw+2Mkds2db4sLn4CnU/NqUn/tWPb9LtFuPnp9kS5ed3wW+56Lxclrc6rFPQ5+LnfRHV4qWrsRgh8VaXAxMrc19jhTn/wDZHIxcm7ps4FVroepjjsxG7N6WfYpN7pak31texSb0eptpLObd9bozk77aEze6vYpJq3YtCyG7XuZTdldF5y0s3uY1Je13LRC0PqL6L+afhvhzPAynzTy/GTpW7RklOP3s9qs+efoi5hbM+Icq2+spUcSlfrFuD/8AqR9Dnv8AGt1YqvrfT79fHrIgAdDsAAAAAEEAACxUsgAAAAAABci4Eh7AAVJBAFgQiQAAAAAAypYhgQAAAAAFipKAkAACGSyoAAAAABKJYAFSyAAAACD89vpc5j/KHj/xH7V1hXQwsfJQowv9smfoSleSXdn5neNmMeP8X+L8W9efOMSv9Gbj+wvj8uXlT9GIeH9wuxF+lyysauCRIvHa5UIhWWi31J0KJl4q7Cqy7F42vqyuiJiRKktL67llLQrvsWaIVG7br7Szb3KvVbWsWu2rPcrKJWv13NItvqZJNLXqax26oiZUlpFp3LqWj12M77svHbTUqpLWnLmSbNor1dzjxulobK17WVisyzlfltqt+hqne8d2U0tpv3LavST0Kyovrdt79ri1n7O5Ctok9S9pNOXNtoQolatrp3LWT1k7eZVLXfySNGns18CBVp3Wmpq1yq99+jIUVbTRouk0rt3sRKJOvdvYmN7q6v5k3ja6W5N3eyWxCm0OPK7t3uaQk3GyehS11r0Lq0mkyqstIN2lp6MvTkrab+ZjGVrq9kzRXTs9SJVltJfMvbl9m/QpBvRJ7GjWibehSVCD0fQ0jLXVuS+0xdul16loy5W2yEabxlo0xJpeatqVut7ku92kr38ykwjS99mnZvYum+VqLXxZlGP5K3XmaRu0/a6blJNLK6vrZl3KTu0rpLW7Ml7Oqlc0Smql9HprG5WUC9pe1Za6eRtzq8vXQzg7uScUn0VzWEXz62leOq7GVpVlomnbm17W2LQhvprfUtBNxtypJeZvBLkb2v0MZsqpCNn7KSXU1jG2t7roWhCydpcrW3ka0ocseja6dzK1hEbc97K9tdTaK5YtxS1dtWFH272tffXc5mXZXjszxf4PgMJXxNaT0hSg5P7NkY2yxHkiszOocSMFzq8dfXY2hQlOyV/M9pcK+Dub4vlrZ1iKeApv/Fr26lvhoj2hw7wBwxkaU6OAhiK0f8biPbfwWyOe2bfh6/G9H5ObvaOmPt/R6F4a4H4hz1qWBy6oqT/x1T2IfN7/AAuezeGfBnC0XGtnuYyry3dHD+zH4yer+Fj2bUxmHo+zFp2/JgtEYTzCpLSCUF82cOTn8fHP07bn4Q9zj+j8fD3t9Kf++5vk2S5PkeHVPL8Fh8JG2rjH2n6vdnKqY+jDSF5vy2OolUnN3lJt+bIUjnyeu5IjpwVisPVrWtY1EdnPq42tPRPlXkYObb1ZipE8x52Xl5c07yW2vExDXmIcjPmIuYTdbqXv5nDxNedeusHhX7b9+fSCMswxjhL8Hoa1paafk/2nJwmHjgqDp71p61ZdvIjq3H2R/wB0xtfqnpj8W8I06NKFGl7kFZPv3YbMmyblZybncrxOlmzrPFCV/DXESvtKl/WI7ByOq8TJX8McY+1SC/20ez6Pfvlj41n/AGc/LneC/wB0vQ1eejOtxM1q7nIxNRWdmddXne9juw0fD2lxMQ7pu+vY4c27tvU5VeVjiTkknZ6s9GkKbVk43dzOpLS19GVlL4lZSvG5tpZSq79TOcrXYqPXe7Zk5J6a6E6XhacvMyd9dSW1qJPTUtCYez/owYv8G8U6eHjLTF4KtTa9Ep/+E+rD448B8SsL4uZBJac9adLf86nJH2Oezwp3j19r6T0md4Zj7QAHY9QAAAAACpYiwAkAARclgCHcgsQ9wIAAFlsCESAZFiQBCJIYuBIIuAJAAAAARYmwACxFiQBUEsgCbi5AAAAAAABKBIAAAAAAAACHvr1Py241rPEcYZ3iG7urmOIm361ZM/Udu12ul2flZm83UzTGTbu5Yio2/WTNMbj5fiHAe7CLNdiEXlxrp9CUtCqLxIUlK+RdPrcq/MtbTcKSlb72L9CsUzRaPzCspV10ZL3tci7LdbEKyR62ZqtIvXcyTSv5msU7Wtf4lZVlKS2NURFau2hdLrfUpLKZSo2fmWjF6paFox9rb1N1DVqK+0rMqTLBRVvM1jHTsXVJ7PSxpyK17FepXqZxk3foaNJK/TqKcHZ3Vmacmi5Sk2U6mcW+ZrozWDSi7aleVtaL1LNapRsRtG0q13e+uxpolyvfuitm9F0JlZt/kjYupK7XdFrq1knbuZ8zdtTR33T06iVZWd1u9OhZyb3skZyd9ncuvebcrx8yFJWdnFNrW5d3texTmXR3ZotY6aS82QiVGnftr3No25tXq/8AexSSadnL4louPLr0epVSW9N732LOW5x1Jt3/AN0apvdbdbkTCulk2tHq+5ZN3a38zJy9q19GXilo7+yVGq5lrG3bUvH3neWndmN1zcvM9NieZpP2W7dU9ysobQleTb07ovZqOl0mYqXt3aaa6M1hKTdlrfcpKF95NWSfdM2pKOttGupWCabtHbzNlyxg7X8kZWlWZU5eWerNYNxblFWVxo4uyvcKTd3FuK/NMLSptyqdnZqVnucynFJatXZxKDbcb7nnvBvhzxDn7hXjh/wPBy/x+IvFNeS3kcuXLWkd5WxYr5rdNI3Lw7lu7NaLZnkXDPB3EPEFX/g3Lqjo9a1T2Ka/znv8LnvLhXwy4byRRq4ij/KWKWv1ldezF+UdvmeT18wweFiqULNx0UKa0X7EeTyPUq0j4Pd43oc/Wz219kPXXC3g3gKDhXz/AB08ZNauhQ9in6OW7+Fj2Zl+CynI8KsPgsNhsFSS9ynFJv16v4nV1s1xFW6p2pR/R3+Zx1Nt3bbfmeJl9YiZ+hG5+17eDDg48axV/F3lXNYrSjC/nL9xxauKrVX7c2126HAjLzNFI4cnNzZe1rdm03mXIUtTSMjiqZdTS6mMSRZyVLoTzHHU7l+YnqaRZspE8xhzEqQi63U1ucXMMcqK+qpWdZ/7JxcyzKNB/UUWpVnv+j6+Zy8jy+Mabx+Nu43vFPebNcdbZbdNf/kfFlbJNp6atMrwf4HT/Da7viKn82pdF+czWVS7v1KYivKtVc5Pf7DPm8yMuWs/Qp9WP6/atXVY1DXm1J5jJSJbMostFl2zp/E6VvC7HP8A9vTX+3E7S503ijPl8L8b1viaa/2kez6NP72//wCZ/wBmHLt+4v8AdL0BiJp3TOvxMrM5mIel0jrMVNpu32nv44fEz3YVZ7pWRxasl8vMtVneVk/icerJu93Y7aQrpLmr6tlJzXK+xlOTsVk9G2axCy02ns9Cje9yrle7uTtHctpeEPuzOcuVGk3ZaGFTVsRCXkvhTXdHxP4aqJ//AKlRXzlb9p9vvc+FPDyf1XHvD9S9uXM6H9Yj7rl7z9T1eD9WX0PpE/u7fegAHc9cAAAAAAAABDFwJAAAhi5AAAASiSFuSAAAEMgkgASSgAAAAAAAAAAZABkAAAAAAAAkEoCEiQAAAAAAAAAKVbfVz/Vf3H5UYuSliq0k9JVJNP4s/VmavCS/Rf3H5Qt317mmNx8vxCj9SbEbvUku4RL/AHuWTRHTvYlBC6vZvoWViCy2IUT13Lxbta5CS3sJLTcKrJ6eZeKbuk/Uzjfe5pDrqRKstIQ69DaMEviUpK+pyIR1SvcztLOZQqZ7C8HfC3MfEmecQy/MsNl8suo058+Ig3CpKcmlFtax0Td7M8HpwVrSPqT6JOAWF8MuJ8zlGzxeLVFPvGnT/fNnHys/scVr/CDBEXyxFvD1NxH4E+JeRSlKWQPMaMf8bgKqrJr9XSX2HhWOynMMtqujmOBxWDqLRxr0pU39qPt7hvOsY6H1X18lWo2jNN3Ul0l8V9tzv6uNwGY0fqM3y3DYqD0fPTjNfJny/H+VeHJ9HLHTP9Pz/wCHd8wxZa9WO2n5+fUyfTQmVJptLc+3828KPDLPlKTyLDYerL8rCzlRl8k7fYeEZ39GjKKkpzybiHF4e/u08VSVRf6Ssz26c/Hkjde8fZ3c1/S89e9dS+WFSbdmr9jSVNxjb5nuXiPwA42ytSqYKGEzWnHX/Bqtp2/Vlb7D1pnOQ5plGJlh8ywGJwdRP3a1Nwf2m0Z6z4l5uXFlxT9Osw8flTtK7WhZU1a5ypUWm7R1I+rWq20NIuz24zjaV7lGpN2vocrkdtdCv1TvqtiYumLMEuazjoWSWvM2bOm0r9OgVNaKN3+8nqT1M482mi8tS10k03YvyWvGyKO1rJJW+0naNnM3a3f4mnMnKy1sZS5lU36F4N2bbS7Eo01u7tv4Etppt7lYvW7epPN7y3aIRMLxbtq7X+0vst9HoZa81r7LQu3dat3WliJhQT00StfYs/Z0ulbqR7ulrfEh+1dPRLX4lEL80rXWi6F1Jt8qZim03rrfc1gm4v2ldbeZEmmsXZ8zbk29fI5ELcvvO5xo+zdORrTklBvmu09FYzlWfDm30spOTJk7aJ2736HHdSPMvTe5zuHsnzPPsyjgMqwdXE1pPaK0S7t9F5s5sl4pG57MoibTqI7qN8yXLoux5TwZwLn/ABPWTweF+pwt7SxNb2YL07+iPanAnhFl2Vxp4viCUMfi9/qI/wA1B+f533HneLzPB5fBYehCLcFaNOnpGPy2Pm+b65TH2x/m9ri+kT2vyJ1HwdJwT4Y8PcPqGIxMFmWNhq6tdexB/ox2Xq7s8uxedYTDpwov66a0tF2ivj+48UxeZ4rFu1Spyw6QjojOEtE31Pmc/qmTJO4/N7dLY8NenDXUO5xOZYrEu06nLF/kR0RlCRw4PW5upqPU861rXndp2dcz3lyYy0NFI4kZtu5vGZWIT1OQpdy6nY4ymXiy21olyOa5ZN7sxi0XUtCYsvEtk7FlPzMOYSmopybslq2yOppEt1I6vNc35G8NhGpVXo5rVR9PM4GZ5vKvN4bBN2ekprd+nl5nY8M5E67/AAiv7NJbv87yXkbY6XvaK0jcyynJOSein5teG8o+tk8Zi21SWrbfvHb43F/XSUYLlpx0ivIyzHGRk1h6FlRhpp1/sOIpG2XJGOvssc/fPx/4aRFaR01bqRN2YqWponoce07XTJuZqRa5pEpiVr+Z454vVeTw0cU7Opj4L1sm/wBh37ep4j411/quBsvpW1q4+TXwgz2/Rv8ANt/+Z/vDDmW1x7z9j0niXfm12R1eKb10/sOxxMl00OvxLV5W1Ppsb4ze3Aqt330MZzfI0zWo1d9fIznLSyevc7KwQwk7PbX1M5O3mWnq7X01KSbt7WxrENIRN9E7IhtWd3sRLrdFKjT12GllnLre5Sbu209SE2tL62Ik2leTsTEJdhwnVVPi3J6km0o5hh3/APMiffE/efqz4ByB/wDGLK/+/UP6yJ9/T95+p6XB8We96R9WyAAd72AAAAAAAABkEhgVBLRAAAAACUgCJAAqWWwsRYCCUCQAAAAAAAAAIbFwBAJAgE2IAAAATYIkAAAAAAAAAAAAAAPZvyZ+TsX7K9D9YKn83O35r+4/J6m/Yj6I0xuPl+5OnUnoNG+xJdwpXcmO9yFbUtF9ArK3oW80UT1sXja5Cq0e5dK73Kp7l4u6CklrPfQvCOuq09SVHqXin10sUlSZaU97XscmmndMwine6ZyIaNa30M7SymW1Plva59jeBmE/k7wCy++ksXGriJf59R2+xI+OedxjJu2ibPuPh7C/yd4T5FgbWcMvw8WvNwUn954nrOTo4t/ulfj/AFpn7HBpVJ4WvHF0k5cmlSK/Kh1Xqt0eUUqkKlONSnJShJXTXVHjGH0lqcvLcR+AYtYOo7Yes26Mm/dl1ifluuuNe+Hfx8ns+0+JeQwk+5zcPjsRSVo1ZW7PVHWpmkJDHlvjndZ09KLO+o5rdWq00/OJfG0cozjDPDY/DYbFUpaOniKakvtOkhM1hKx6uD1rkY+1vpR9rSLbju8R4r8BeCc3562XU8Rk1eWt8NPmp3/UldfJo9O8Z+BPFuRc9bAU4ZzhY3fNhtKiXnB6/K59NUMZXpe7Uduz1R2OHzKErKtDlfdH0XF9dwZe0z0z9vj8/wD45M3p/Hze7U/Y+BsVluIwuIlSr0KlKrB2lCpFxcfVMzeF1u0fePEnCXDPFWHcc2yzDYp2sqyVqkfSS1PS/GvgHisO6mK4bxf4XS1aw1ZqNReSe0vsPYtlvWOqI3Hxh4+f0nLj70+lH9Xzo8PaTSijKdKSem6PLs2yHGZbiZ4bGYarQrwdpQqRcWvgzqMRhrN8xbHyq38PJndZ1Lo6kNXZ/EznHS7tbqmcytSak01oZTpez7Sd10OyL7IlwlFRbsrF4xXK0m1Lz2Lyi7uOmpM2nHQ0iV9q35W2pavcsrXbTsu5m9lKKdluTKSS0lu9ixKym9esizqezaTMptbJ3fcrKXXmt5EoiHITXM2tV67kSb3i7Xdnd7EU6lKNKpzxbk1aDT913Ke87czS3KaQ2pvlk4t3ubKSavfmfyscSM5aNyemxsppQt+Wn8GVmETDfmd25pv82zNou6VpL5nDhz1KqhShKUptJRjq230SPfHhZ4UU6MKOccVUlOrpOlgZaqPZ1O7/AEfmefz+bi4dOrJP4fFpg4+TkW6aPG/DfwvzLihQzDMZTy7K94zcfxlZfoJ7L9J/ae+Mpy/h/g7K1hcvw9LCU3vy+1Uqvu3vJ/YcLOuJqGBvhcGo1K0VbT3Ifv8AQ8WrYytiqzq16jnOW7bPg+f6pm5U9+0fB7eKuDhxqne3xeS5hn+IxTcKN6NJ9n7T9Wdep3Ovp1DkU6mup4l9zO5JyzedzLmwdtWcik9bvc4NOTkzV1lfli792Viq0Wc9VEtFuXjLucKnNHIjUVtydaWi23JjI1jOxxIzLqZSZaVlzIzNYzOFGZpGZDSLOZGRpGRxYS8zDMszoZfTvUfNUa9mC3f9hesb7Qt1xWNy7DEYilh6MqtaahCO7Z4tmub1cwm6NC9Ognt1l6/uOvxmOxOZV+etK0F7sVsjyrhLhv65QxuOg40N4U3vU835fedGLBa1tR5YxkvyJ6KeF+EsglXSxeJThQ6L8qp/Z5nkOaY+Cj+CYW0acVytx29EZ5tmKinhcM0rK0pR2XkjqFI2y5q4azjxeZ8y7IiuKvRVupal1I46bNEzz9qbaqRbnMUy12NpiWyfUunoceMi6Zas91ole+u54D4/Yj6vJOHsMpWcpV6rXySPOubU9X/SHxH/AA1lGCv/ADOXxk12c5N/sPovRI3N5+zX9Y/Rzeo21xrfa9YVqid3e5w600a15W2Rwqr31PpMUPlGdST12TuZTno76Ezbu29EZVNNU7HbSCIUlo79DOTXncmcm/Zb2M5S9nU10umV+rKyktU7FXLVu90UurvmJ0mF9LuzuyJvTQrdsrOXVOw0tDlZJL/jBlrvtjaH9bE/QKfvP1Z+fGRy/wCH8t/77Q/rIn6ET95+p6PB8We76T4t+CoAO57AAAAAAAC4Ahi5AAlAkAAAAAAAggCwKkpgCQAAAAAAAGRcXAgAkCCxUm4EkMgAAABKJKlkwAAuBDFw9RYCUAAAAAAACJe7L0f3H5OU/cj6H6xVP5uX6r+4/J+n/Nx9EaY3Hy/cdSbi/VhNl3El9yVuVvdFtwqtqrXNEzL7C8dFqyFJarTW9y0ZdCkS0er+whWWl+zuaRbte+pin06s0i3otraFZUlyacnY5EZLl03OJTdn7WrOTF6OxlZhZpTj9bONKO82or4ux9959BYbJsDhF+RThG36sEj4R4cp/hHEOW0X+XjKMPnUifeHGLtXow7RZ818o7dPG02w9q2l49FWmcmrRp4rCyoVHa+sZfmvozju3Mmb0pWPze1prbcOnHqY1LbI8fOrz4PF+ziqDtK/5a7nbJnjuZYapVisdhG1isMubT8qC3+X3XOyynMqWPw/PG0akffh2/sJvEXj2lfxdWHJMT0W/D7XZwlY2jM4fN1RrCem5lEumLOZCWptGRwYT8zaFQ0rZrW7sKNepSlzQk0/I7HDZnGXs142/SX7jolU8y7qJI9Li+pZ+L3x27fD3NIs53FPC2QcVYH6rM8JTr6WhXhpUh6S/Y9D578S/CHN8gVTG5dzZnlyu3OEfxlNfpRX3rT0PfFHF1sO1OlO1910Z22DzWhiLU6tqc332Z9FxfWeNyp6b/Qv/Sf+/a5OTw8PJ+tGp+L4UxeFcJyvF32OBVotNpaJ7n1x4n+EmW8QRqZhkkKWBzHVyglalWfn+a/PY+ZeJ8ix+TY+vgcww9TD16balGSs1/Ye3jyzE9NnzXL4WTiz9Lx8XiU4vnfK7sxakm3e9jl1oS55ORhUja6aud9LOOJYSld3ZZyi3ZaPzM5u3lYq7p+qvqbRLRpzXXLdNt7kStHd2Vwn1tsUlfV3eu5bQm61vqTGTTe3LbuRCtCEaqlShUc4OMXJv2Hfdf79TJTezViqdORFq60vbq2b4elXxWJp0MPTnVrVZKEIQV5Sb2SRx8PTq4ivToUacp1aklGnTgruTeyXdn0Z4W8C4Tg/Afy1nX1cs0lC8pS1WGi/yY/pd38EeV6p6nj4GPqnvM+I+LXBgnNbXu98tvCrw6wfDGHhnOdqlVzXl5lzNOnhF2XeX6XTodxxBxTPEOWFy5yhR2lV/Kl6dkdJxFxFWzSs6VK9PCRfswv73mzrI1D8/wCRmy8m85M07mf6O2/Irjr7PD2hzYT1ORTmdfCeu5yKc9dzntVzVu7OlM5NOTbsjrqEruyNPr+dOFN/i09ZfnP9xhNG1buxVZv2YP2esu/9hrCpbQ6+FS+i0Nqcys100i7sKdQ5Eah11OepyIzM5hpWzmxqGsahwozNoyM9NYs5cZmsJHAq16dCi6taahCO7bPHc1z+rim6GDvTo7OX5Uv3Itjw2yT2WtmrSNy77NM+p4a9HCtVK2zlvGP72dHKdXE1XUqSlOcnq29WcTBU3VqRjGLnOTtFJXbZ7N4S4YhgIxxuYRjLE7wpvVU/Xu/uO7Hx9dqs8VcnLtqPDj8I8LcqhjczhrvToP75fuO7zjNUubDYaWu0prp5I4udZvzOWGwsvZ2nNdfJHUKRXNyYpE48f4y9LdMNejH+bZPUspHHcrllKx5+2PU5KkWUrnHUzRSI2mLNubUvzKxx07mkSdrRLVMspGKZPMTC8S1V5TUVq5OyPTvjvi44nxGx1OLvDDU6WHXlywTf2tnubJkq2b4en0U1KXotT5w40x/8p8U5pj73VfF1Jr0cnb7LH1XoVJ9he3xmP6R/y8/1TJrDFfjLpK1rO+5wq19VdJM5VaSd1ovicStJbdWfRY40+fcebadr6eRjUndNt3sWrO+ilsceUtW27nZSEwSmt46dyrfRX9XsRN31S1ZF7K5osrLs3sHa7aK32VvTUhyutXZDS0LPutLFJuyDer1KyfYlMN8k/wCX8t1v/htD+sifoXP3n6n555FpxBln/fqH9bE/QyfvP1PQ4XiXu+k+LfgqADteuAENgSCCAAAAAACSSESAAAAMBgVAAAAAWQC2AAAAAABUEvcgAWKk3AMgkgAAAAAAEkACxUACUSQiQAAAAAAAAIl7svR/cfk7TXsR9D9YamlOf6r+4/KKmvxUf1UaY/e4uZ7lWQi7T7kNGjiCVcjdluoVTbRMte70I+ItruQhdaeTLJr87TqZposrq66EKtE031saRb1djKLumjWLSexWVLN6b+ZvDZ+1sY027q+5sldX2MrMJh3vAMfreOeH6cnpLM8Mrf8A9sT7l4yf+H01+h+1nw74bW/vjcN365thv62J9wcZP/hGH6n7WfKfKif/ABobY/qW/B0cuhaErFJPQrzWPzi3lpjnTm4evKlVjUg7Si7o4Gf4SpllenneVq2Gqu04LanLrB+XY0jPrc7HLMXTg54fFQVTCV1y1YPt39UaYMkY7at4l1REXjpn8Fsrx9HH4aNak/KUesX2OYpWPD84weM4SzpVKEnWwdZc1N9KkOz80eSZfjqGOw0a+HnzRe66p9mWz4Zx27eGmPJMzNLdrQ56kaRqHE5i0Z6GG23U5iqFvrL9ThqoT9Y0ydrRdy1O65eu6M5zunYwdS/UTqXTknr+V+8rf4p63b5ZnNSgo0sRepT2v1Rw/ELgvJeOcm5K/LTxKi/wfF017UH2fePkzrnNWNsBmVfA1uaEuaD96DejPY4HrOTDrHl71/rBN63iaZI3EvlXjzhPNeE86qZdmtLknZypVI6wqx/Oi+q+48ZqQ5U3rdo+2eMeHsj474clg8ZFNq7o1kl9Zh523X7V1PkXxB4YzXhbPKuWZpG04a06kV7FSHSUfL7j7rhcymeO0vnOdwJ41uqvesvEaqu3JL1MKm7aerORUk9bu5T8U6fLK8anN735KR6tZ04onTBtq65mubfXcq2nHXbvcYhRhUkoVFVim0pJNKS766ownNrbZbK5trbWIWm7vZuz7lZS9pkNu+9vRntLwI4GjnuY/wB0GaU08uwc/wAVCS0r1V98Y9fPQ5eby8fDwzlyeIXx45vaKw8q8F+CqeRYGPFWfRUMXOnz0IVP+jwf5T/Tf2LzO04m4hqZrX5KbcMLB+xHq/NmHHPEf8oY14DBz/wSjL2mnpUkuvouh4/Gpc/PM18vLyTny+Z8R8IaZ+RWseyx+I8/a58alzkUp+Z1lOfmcqlPoYzRxxd2NORvCRwqUzb638lS5Xu3+au5larStnLU3JuCk4wXvyXX9FHKpzurWslskdbCd0klyxWyv9/mcmFTQxtVtFnYU5nIhK519OZyaczntC0Wc2EtTkQl5nDpS2OTTdzOYb0s5UHqZZjmeGy6jz15Xm17MF70v7Dx/O+J8PgnLD4NxrYhaN/kw/ezxmpjKuIrSrV6kpzlu2zrwcG1/pX7QjJyIp2jy7fMM0xOZV+etLlpx9ymnpH/AH7nIyvDYjH4qnhcHRlVqzdlGP8Avt5nG4XyfH59mEcJgKTfWpUfu013bPdvDWQZfw3gJRo2lVavWrz3l+5eR13pFO0L8TiX5U9U9q/FxuEeGMPkdNYnEyjWxrjrN+7SXVR/eTnec/Xc2Gwsn9XtKf53p5HCzvOZYubw+HbjQT1fWf8AYdYpHnZ+Tv6FPD1bZaUr7PF2hvGWpopHHUiykcTn6mykXTMFIvGRBFm8WaJmEZeZrGRVeJXRfm8zO5NyV4lrcrWqOELrd6Ipzd3a25nzupLm6dPQsvvUNVjP5MyXOc1bs8JgKkot/ntWX2nzZVd27u76nvTxRx0ct8M8TByUamZYunQiu8Y+1L7j0POons7XPt/R8U04tY+O5/P/AI08b1O+7Vp8I/u4uIlaXNay2tc4lZ36m2IkuZxdm0cSpNpys7tHt0q8pnUkkm2lfy6mE2t5LXoi1WTb+8wqNX0ludFYTA5aON2UnJ35Vf8AeS229raFJNtNPqaaaF7bu7Jb72+ZTfyt0Jdt29OoWhZtLW+6M5tq719BJ2tqVnK6tfYaS3yST/l/Lv8AvtD+tifohP3n6n525E0+Ictv/wCu0F/82J+iU/efqd/D8S9z0rxb8FQAdr10MglkASSVAAAACUgSAAAEBMglIBcAgAAAAAAlEkIkAAAAAAMqWFgKgmwsBAAAAAATYIkCoLWIsBBKBAFgQmSBHUkAAAAAAAip/Ny/Vf3H5RUrfVw1/JX3H6uy92Xo/uPyip/zcf1UaY/e4uZ7iyvvqLfYSm3q+hCvexo4ELe2xK9CboaNOwNl2tbXJb6kP9a4IDVO/UvG7bSW2+pSy2vbzZLj7V1p6BVpT9TaL+L2uYxWrS1ZvHVWeyKWZy3g3o7NmqaT639TCPV+RyFFOjKp9Ylytey93fsZWZS7rw/qfV8f8O1G7cua4V//ADYn3NxppjaUu8WvtPgjh7ELDcR5Zir6UsbRm9drVIs++eNVd0Kn6UkfK/KiP/GhrT6kvHJSuZuRE3qZSlZn5zMd0VlvGepvCehwFOztc1hUs9ytqtq3eQYP8HzjLpZLj3o9cPU6wl5f7+R4TiI5lwtnM6NRaL3l+TUj0a/30O8p1nGSlF8rTumuh5FXo4LivJZYXEcscbSi3Cp1i+/o+qOvj5IvXos6Jr84jtOrx4+37HW5dj6GPw8a9CV4vddYvszkqfmet6WIx/Duc1aU4OMqc+SrSez/AN+jPO8tzDD5hhVXw8rp7p7xfZmGbDOPvHhXFn6+09phz+cOZx3OxHOYba9Tk84lUcXdP4dzi/Wa7kSqaEb2jrazmlLR6br0MatRdzKVW8Gr6xf2P+37zCpVXcrruTdz8BmlbL8SqtN3i9JRe0kaeJfCWWeIfCXLTnCnjaacsLXa1pztrGX6L6/M6KrUOTkec1MsxnM25UJ6VYd13XmenwOdfi2jv2/siuWsxOO/esvk3PsvxmU5ricuxtGdDE4eo6dSEt01/v8AcdVKW+p9L/Sb4Jo5pkkeNcpjz4jD00sWoL+do9J+sfu9D5lqS6bH6b6fy68vFF4/F4nI484Mk0nx7lZNJtmcpQ1evbcV3yyabT9HdHGqSV7bfsPThEQ7zg3I8TxNxJhcnwr5XWnepU6U4L3pfBfafQnGGZYbhrIMNwzkyVG1FQtF6wp+f6UtftPG/B/J8PwjwZV4mzKFsXjaanFS3jS/IivOT1+R0WYY+tmOOq4zES5qlWV35eR8J6ryvn/K6I+pj/rP/Cc2T2GLUfWt/SFqUrHJhPTc4EZm0KnY5Zq8yJc+Ezk0qnmdZCocinU8zC1V4l2cKj0S1b0S7mrmnJQTvGO7/Off0OBSq2jzJ2lLSPkur/YbwlZaGNqt6T2dhTmb05I6+lM5VKRhaGkS51KTucqlPQ4FORXMMywuW4WWIxVRRgtl1k+yMfZzadRDSsu3lXp0aUqtWpGEIq8pSdkjxLiLi6WJjLC5dKVOjtKptKfp2R4tn/EeJzatyt/VYeL9ikn9r7s66FZfE9niek9H08vn4F8uo1DuKVb2r3PM+AeE8y4oxPNC+HwFOVquIktP1Y92b+Fnh1iM/dPNc4jUw+VrWEdp1/TtHz+R7zUcDlGXRpUadPC4WhG0YRVlFGfM5VMc9NO8u/g+nTl/eZe1f7qZTl+WcPZUsNg4RoUKavOcvek+8n1Z47nmdzx0nSo3hh09usvN/uOuz3O6uZVuWN4YeL9mPfzZwFUPAzZ5v2h6GflRMezx9ohzIz1NIyODCepvGZy9Liizk8xZSOMpllPzJ1pbqclSuaRkcWMzWMykrxLkxZopHGjI0UvMiIaRLdSLJ3MospiK3JL6uD9t7/o/2kzC0S0qVOaX1a1S979xeLONSskdhlFH8JzGjSfuuV5ei1ZNKTe0Vj3tK95esfpHZmqeOyPIIP8A8kwrxFZJ7TqPT7I/aeqfrUk3fVHa+JmePP8Aj7OMzU26U8Q6dLypw9mP3X+J0d7p2Z+lcfFFMdax7ofO8vJ7TNa0KV5XldOxx6sl2ZrOS6fG5x6rurt2aOykOaIYVZWbla3xMZyu3r6Fqjd2ZT5WvLub1haITeS1b023Ik3bTp3Ib0a+XkRJu1vPqXWhMpKz11Dk1a7sZuVm7iUtXqTpeIJSvHXb1Mqk7Le2pM2nfuzCo/K5Ol3LyOf/ABgy13/6bQ/rIn6NT95+rPzhyB/8YMs/77Q/rYn6PT3fqdvFjtL2vSvFvwVAB1vWLEWJAFQAABIsBBYAAAAKliCQDQsAAsRYkARYmwAAAAAAAAAAAAAABAJAFQTYlIAAAAAAqCWiABYqWQAAAAAAAAET9yX6r+4/KGmvxUP1Ufq7U/m5/qv7j8o6f83H9VGlHFzPchk38g9/QO1jRwluly1t7bIhbaFl1uQrKqT8kTe9ybdSX8lYIQ1rfcvFX0ehVdWi6WlwiVrKyZeN9kvUor2Tbu/uNI973RWYVaU2lfdlpSsrX3KxaastLFHK7sY2hnraZTdN/WKXuvmXw1P0Gz2usbwxgcfB3VWnSqp/rQT/AGn56PVNProfePA+Mjm/gnkGOi+bmyqhf9aEVF/bFnz/AMocfXxJaRHaYcWpK6Uls0YVJdSsKmrpt+aM6kj8ztHdh1LOdmXjUOLKYVQdO0xfTmxqHIweMrYTERr0Zcs4v5+p10antWuafWK25lNdS2rkmO8PIOJsnocV5ZHMMCowzClGzjf3/wBB/sZ66o43F5JjOePNTlGTjUpz016po8xyXN6mWY1VVeVKWlSF91+85/iFwzS4hy9Z1k9p4tU7zhH/AB8V/wCJfbsd2C8ZI1Zvlx/OK+1x/Xjz9riZTm2GzTDfXUJe0vfg3rFnLlPzPUWX5jisrxqr0JOMou0ovr3TR7GybOMNmuEVai+WaXtwe8X+45uTxJxfSr4Y4eR1xqfLs3UKyq6bnGnU13M5VDlhpNm/1qVRcz9l6P0MKs3GTjLdOzMZ1LlMVU5owq395Wl6rT9xbSJt2KlU4taqrMrVqO25w6tXfU0rTbG13l/BWb066qZDj1GpQrxapRnqndawfk0fLvjHwnLgvjTF5XBSeDqfj8HJ9aUr6esXeL9Ee5pYqdKrGrTm4zhLmi09U0a+OOUU+OvDCnn2EpKWZ5YnNqK1dv5yHo17S9EfTegc75rmilvq27fovM/OMU1n61fH3PlypPol9p3vhvkEuKOMsFltm8OpfW4l9qcdX89F8TxWrVbej0Pf/gJllDh3gTH8X46KVXFRlKnfpSg2kl+tK/yR9j63zJ4fEtev1p7R98uWtO/fw5Xitm8Z5jRyXDNKjhUnUjHbmtovgjw+FQ4eIxdXF4uriq8nKrVm5yb7t3LwmfJ4eP7LHFHl58k5bzaXOjPzNozOBCZvGfmXmrGHNhM3pzu7Xsu/Y6+nPzOTGfstfD5/2fsMrUXhz6FS8uZ6dEuy6I5UJ+Z1tOetkcqnKxheresuwpy1OXRnc62nK5ws/wCIMPk2HXNapiJr8XTv9r8jCMNslorSNzK0TMz2dxnGc4XKMN9diJXm/wCbpp6yf7vM9d5xnGJzXEuviamm0IraK7I6jH5jicwxcsTi6jnOXyS7LyKU588lTppym3ZJatn0fC9Mrx46rd7NojTmqtaVl7x7o8IPC+pi/qs94nouGG0nh8JLR1O0prpHy6nM8HPCqODjR4g4ow6litJ4bBzV1S7Smu/ZdD27jsZRwOGniK81CnBa/uPG9T9Xjc4sE/fP6PW4Xp8f5uaPw/Vy8RiMPgcI6lSUaVGnG3ZJdEl+w9f8Q55VzSvZXhh4v2IX+1+ZweIM/r5tXW9PDwfsU7/a/M66Ez520zLXlc32n0aeHLUjSMmcaE0aKZj0vPi7kwkbRlocOE0XVS/UnpXizlKbZpGZxYzNFIpMLxLkxlqaRmcSMjaMisw0iXLjI1jLQ4tNtuy1ZWvi1Tk6VD26uzl0j+9kaaRLlVsT9S+SGtV9PzfNlKastW23q2zj0IcrbbvJ7tnIiyrSvdrFleI82XD3Aud525qNWNB4bDedWporem5MWevvpE5v9RleS8NU5e008diEn1ldQT+F38T1fSOP7bk1+Ed1suT2eO13p+lJ8y1v5s5KdrPdepwYzSatubKbScm2ffxD5m3YrSlzST6nHqyvez9TSpNtXvovsONWmr6PXsdFITVSTv1bsZtJpy0XZXE5Pq9+pk3blj3ubRC+l25a66shyb9m2vWxW7a0disrXlry31LaSrJ+001sVdRMhy1aaM3dPR6X1ROl4Wcu7KTe/RBybv2KSlZOzukTpaHJyVpZ7lzTX/llD+sifo/P3n6s/NzJZL+Xcu/75R/rIn6Rz95+p2cbxL2vS/FvwQADpeqAACGgSAAAAAAAAABDDAAkhIkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENEgCpYi2pIAAAAAAAAES91+j+4/KOnpTjr+Sfq5P3Jej+4/KWH81G35qNMfvcXM9yjvcjqTK3R79CNtG/iaOFZvQlO6ZCaL/FBCHbvYmy63Id+pa23QhVDVnuWXvWVl8SEutyWtdEELXa3e5ePyM9fiTH1IQ3hKzevQpLl5ba3EJWV2RKVvMylXSknb1Ps36LeYfyt4GUsFKfNPA1sRhGuyvzx+yZ8ZVJaq1l3PpT6EWcNS4lyGpNcslRxlON+usJ/+E831LFGTj2hpXy8/qylGV07STLuopxU1s+nZ9ic7p/g2aYmh+bUdvQ4EK/1M3zfzc/e8vM/KujfZwzPTOnIlPqU+s8ylVuMrXTW6a2aMZztfUiKqzZyVVs9WX+uudf9aTGr5kTRNbubOrc7zhHiF5biPqMRN/gtR/8Aw33X7TxZ1ddDOdS2qZFa6ncNsee2O3VV5H4qcIfhUZ5/ktHmqNc2Jo0/y1/lI/tXxPVzzapks8Pi6GIgqkm+aF+nmux7c4E4ktUhlWMq2TdsPNvZ/mv9h4V488BVKEavFOSUPxL1xtCC/m3/AJRLt3R6XCvXJkjFl97fk4YzV+cYfxj4O14d4hwmeYT62hJRqx/nKTesX+47CpPTc+dMnz/GZPmMMXhanLKD1V9JLsz3XwzxFhM/y5YnDyUZpfjKd9Yv9xl6n6Tbhz1070n+jDHl647+XdSqlPr4uLpyaSbOLWqa7nErVbJnmRXcJm+nIq1b7vXZnEr1Ur2Mp125tt6tXZx8RVVnqb46bYzZjiq1r6nd+H+dwo43EZTXknRxsHypvTnS0XxV18jxHG19zpK2Pq4fEQrUpuNSnJSi+zTuehj4/VGkUzTjvFoes+OeHKuA8RcVw/gYSkq+KisGu8aj9j5Xt8D3b4nVqWR8LZXwvhJJQhTjGVn+RTSX2vUypZfhM68Rslz90ruhhZ4iMvPZJ+kpNo8Y8Ssy/lDi3Fcs+anh7UIa/m7/AGtnt8nlTz74KW/grufv8f8AJyskRjmI97oIvU3jM4KlqaxmbTR5Mw5sJ6m0ZnAhM5NOV9Sk1HMjPlTlLojlRbjGMXutZer/AN7HX05KdaEOl7v0Ry6c21d731MrVXiXNhKyOTRlc6+MruxwuIM9o5RhL6TrTVqcO77+hhGG2S0VrHeVq7tOodhxDn+HybDdJ4ia/F07/a/I9c4vG18bip4nE1HOpN3b7f2HX4rG4jG4uWIxNRzqTerfTyXkaYZTrVYUKMZVKk5KMYxV3JvZJdWfR8L0+nGrufPvl30xdEOZRdSrVjSpRlUqzkowjFXbb2SXU+l/BTwrhkNKjn/EdGFTNpLmoYeWscKu77z+71M/A/wrp8N0qWf8QUYVM5mr0aMtVhE+/wCn9x7YxeKpYWhOvXqKnTguaUm9Ej5X1r1uMszg489vfPx+yPsezwuFFf3uWPuhpjcVRwmGniMRVVOnBXlJs9ZcTZ/VzfE2jeGGg/Yhf7X5nD4s4lq51iuSneng6b/Fw6y/SZ0310UtZHg48MxG5Yc3ne0nop4/u50Zm0JM6v8AC4p+yrsvHEVJdbLyLTR53XDtVUUfekkW+vj01OshJ3u2bwkVmiYs7CNZs1hM4MJm0Z67lJheJc2M9dzWMzhwkbQd2Zy1rZy4S1N4tKLk2oxW7eyOBWxFLDL8Y+ab2gt/7DGU62KknWfLTXuwWyI6N95axaHPq4udZ/VYVuMPyqnV+nY3w9ONKNo/FnEotKySscymzKzWvdyII0RlB9jRPQz22hrh0qmIp05SUYyklKTey6v5Hzh4icQS4k40zPNVL8TUrOFBX92lH2YL5JfM9veKee/yFwniZ058uJxaeGoWeqcl7T+Eb/NHz5Fp6n2Pyb48xS2Wff2hycvJuIo5MZ3069zT6x6q+5xoN3tbfzNOa6tt5n1MVeVaO61WetzCrJqTa2t1JlOyfSxjOTV5JvXqb1qQrKSt59isndNtaoq5bK+u4UtLNamkQlDlr2XqVfLdrm1Jna6bRElZt9ehbS0KS95rmKy1Wj22RLd3a+pSbezZK8IlLR9DGpLfoXk9bNmc2lqWiFolplEv+Hcvd/8AplH+sifpXP3n6s/NLJv+Xcuv/wCuUf6yJ+l0/efqdWDxL2vTfFlQAdD00dSQABDJAEIkjqSAAAAAgCCUgiQAI6kgAAAAAAAAAAAAAAAAAAAAIYE3BUATcEACwIRIAAAAAAAAAAAAABEvdfo/uPylhf6uKXZH6tT9yX6r+4/KWFnTivJGmNw83+FSX2lddS87FXp1LuEi7M0XfcorIutlbYShLvfyJv3Kvbcl3tfZBCb6eZa11e5VLXbRbmlt0uoVlF73uyUr+hF2n5llZO1whKdtdGr9S+MrKviZ1lShS53fkgrRXoZatXuiJPR6mVo96YZzaT0Z7F+jXxDHh7xgympVq8mHx3Pga13paovZ/wBtRPXNVpWutzCOIq4fEU8Rh5uFWlNTpyT1Uk7p/NGWTH11ms+9rWNvvLj7DujnEa1rKtTv8Vo/2HjNR6M8m/lOlxf4a5NxPh7SdbD0607fktq018JJ/I8XqtH5VzMU4eRarz81dWUpYlUpKhXlak/cm/yH2fkTiG4SaZxsQozi01oYUsU6C+oxN5UfyKi3h+9GHTvvDCZ90uRKp5kfWeZlXjKDWzT1Uls0Zuegiu1OrTkOr5kOqcNza3Kyqabk+zOttOryy5ouzT3ue0uAOJaWeYGeW4/kni6cOWUZK6r09r2+89QVKl0MBmOIy/H0sZhajp1qUuaLX++wnFuO3l08XmTx7790+Xjfj/4fVODs2Wa5VCc8jxk3yW1/Bqj/AMW/L81/Doev+GeKsZkOZQxOHqeytJwe0l1TPsjCYnJ+O+Ea2ExuHjWoYmDo4qg3rCVunZ9Uz468XOCsfwFxRVyyvzVsLUvUweJtpVp/xLZr959T6Lz8fPpPF5EfSj+sfq7uRxqxrLj+rL3tw/nODz/KqeOwc780byjfWLLYmTV0z558PuMcTw5m0Oao3hKkvxkekfP07n0LQr0M3y+OMwclK8btJng+qelW9PzfGk+J/wBnHkiYcGrW5Zxbel7P4nGr1903qtGUxs7KSejRwMbWf1z7SipfYY4qRLDbHH11rqeM5livadmc7M8RukzxfNMRvZnucTj7WrG3sfw5x1ZZLj8xxEl9VgqbpUn5azf3o9d1K861adao7zqScpPzbueaYGay/wAGXUvaeNlJ+vNUt/8ATE8CUrojiUicuW/26/Jz8qe8Q25lzF4y1ONfU1gzv05XJpyORCaXU4cWW530M5qhz6M7Kc+r9mP7TnUHpY6xNOpClF35V/8Ac5WKxdHBYWVarNRUVdtmF6zM6g771Cc5zWhlWDlXqu72jFbyfY9dZhj62YYuWIxE7zlsukV2XkZZ5m9XNcc6srqmtKcb7L97OJCeiV9Ue/weDGCvVb60vWwcb2Ubny5VPmnUjTpRlOpJ8sVFXbb2SR9S+BPhVDhnD0uIeIaMKmdVI81GhLVYNPv/AO0+71On+j34WLK6WH4u4kw6/D5xU8DhKi/mIvapJP8AKfRdN9z3i6nVs+O+Ufr/ALSZ4vGntH1p+P2R/u9ficaI+nf8GtSrClTlUqTUYRV227JLueqeOeLHm2IeDwcmsDTe/wDlX39OxXxH4w/Dqssoy2r/AINCVq1SL/nGui/R+88LhUPF4nEmteu/ly8/nxb93Se3vc/6xvZ2LRd92cONQ0VQ65o8jqcyEkjaEzgwnqbxl5mU1NubCZvCZwIS8zkU5abmc1aRZzYzNoSucSN1HnnJU4fnSdijzOnF8mEpupL8+ei+CM5pM+GtZ+LtVJU4/WVZKEO7KSzCdS8MHFwXWpLf4djrUp1p/WYio5y+xHLpyUVZJJETjirWL/BvhaUYScpNzm92znwehwKcvM5dKRjfa1JcmD1OXTkcGDOTSkctodNJcymzZPQ40JI6PxC4jhw3wxiMapJYma+qw0X1qPZ/Df4FsWG2a8Ur5ltNoiNvU/jVxBHNuLvwGhU5sNl0XRVno6j1m/uXwPDoPS1zhxqTnOU5ycpzbbk923ucmnfXqz9Q4nGrx8VcVfdDycl5tabS3T9rVl+f2GlYxbeojrUUeZR5na7ei82dUQwkqTaurp+TMZu87LVftJm2pySknZtXWzM29E7NLq2bVhELdXzRulsiLt69URf8q9+hEuzerLxC0Ik2l7Mk0/sIbd0lfXqyJPol8hLR2b0tr5FtLobumttfmZzk0n2RabbV+b0Mqjsmnr5CITCJtN7mVV6O71JlJt6avsUm/ZuW0tDXJ/8AlzLtf+mUf6yJ+l8/efqfmZk3/LmXK++Mof1kT9M5e8/VnTh8S9r03xZUAG70wAAACNQILLYixIAAAQwSAIRIAEW1JAAAAAAAAAAAAAAAAAAAAAQyQBUFrEWAWDJIYEErYglAAQAJJIRIAEC4EgAAAAIl7svR/cflHTX4uPofq5L3Jfqv7j8paf8ANxX6KNMbh5vuQ7X32Kss7bLchOzsy7ghPs9NWS9NSN+i9QrW3BKW9r7E6FXLsSmmtwheO+5Z3t5FUk29bEpLXpqFR2369S6ae60RWyuTotdSBCIltvqS016ETffTsVkhx67XdnGqu7ujkVtVc48kRpvR9U/Q24op5pwpmvBGMmvrMG3iMOm9XRqO0kv1Z6/5x5RmlCeDxtbDVffpzcX5nyt4Q8XVOCfELK8/Tl+DU6v1WLgvy6E9Jr4LX1SPsjxBw1Ot+D51g5xq0MRBJzhqpaXjL0aPhflLw+jLGaPEuXl07beIzkY1WnFp2ZM2Y1JaHzVYeZMsIYipg5OLX12Hb1g3rHzTOQnTrU/rsNP6yn17x8mji1ZdDgz+soVfrsNN059bbP17m3TFvvU38XY1JGE56GNHH0cRP6urahWen6Mv3FsRGdOTU00yYrqdSTPvZzmcerLzJnLrcwnLzNIopNnkHAvEtTh7OY1ZylLCVrQxEF26SXmj2J4s8HYHxD4MlglUpxxcV9fl2J6RnbRP9GS0fwfQ9J1H2PZHhJxRJr+QcZVvZOWFbfzh+1HLyqZMFo5OGdWq9X0zlRv2GTxPh8hZvgsXleZYjL8dQnQxWHqSp1aclZxknqj2H4PcbTyzEwyrGVH9VLSi2/8AZ/ceyfpTcBRzHAvjXKaKeLw0FHMIQWtSktqnrHZ+XofMX1koT5lJxad009j7vi5sHr3B3Pn3/ZLrzYPNZfVedxp16McbhmnCau7HjePq+xTd/wAm3yOo8JuMaeaYJZdj5r61exO/VvaXx+87HPKcsLiamHb9yTt5p7HyMca/GzTgyeY/s8nJWa21Lo8zq6s8XzSsle7tY77M5t3Z4lm9Rcs23bRn0fCx+GuLu9l8XVHhfDvhvAp256VOcv8AQv8AfI8Li/ZPLfFOap4XIsNHRQwu3+bFfsPDYy9k5eBXeHq+MzP9XHl72bKWppCSZxebzLxkdnSx05cZ2NKdRRvUf5O3r0OGp+ZpOVpKC2jv6mdqomHKoVXBym92eH8XZ1LF13g6U70YP23f3n29Ec/ijNvwTC/UUn+Oqqyt+Su54WnbV6npcHixv2to+56XB43/ALLfg3jO2iZ9A/Rt8LljlR424jw6eCpy5suwtRfz80/5yS/MT2XV+SPCPo++GtXjviN4zMIShkGXyUsXU2+tluqUX3fXsvVH15anSpwoYenGlQpRUKVOCtGEUrJJdEeD8qPXPm9Z4uCfpz5n4R8Pvl7OLFEz1W8OQ6l223qz194m8XOhGeSZbU/GzjbEVYv3F+avM5viFxXDIsCsNh5KWOrxfIr+4usn+w9QSqyqTlUqScpyd5NvVs+P9N4PX+9vHb3Obn83pj2dPLaDsrG0ZnFjI0i9dz25q8HblwkaxkcWDNIysrt2M5qRLlwlqbwkcelTfJ9bUlGjT/Pm7L4dyHmNGD5cHRdaa/xlTZeiMZruezaPtdjShLl+sm1TpreUnZE/yjRg+TCwdaf58tF8EdTOVbET58TVcn26L4HIoyjDSKK+x13lbcR4c2X1leXPXqOT7di9O0dlYwhPrc15kVmCLuXTqO+5yYT0OsjPU5NOehjarSLOfCepy6UzrKU9TmUpnPerWtnY05HIpy8zgU5+ZysOnOVlt1Oa9dOmlnOhKyvc+ffFzilcRcSOhhajeAwV6dJp6Tl+VP8AYvJHn3jRxdHI8m/kjBVUsfjYNNp606Wzfq9l8T0TSd1qz6r5O+na/wDJvH3fqtlt205VJvv8TmQ166nDp232SOSpb6bn1sQ86/lyLLmbWnlcpJ2TaT3svMi/KrbS7Ccmk7Nyt3LxVRlUkk7voVlK7ST1XQib5mrK5W6aZrEGl299PtKxvez37i+i1sRJXvfRFloRfR2diHa1+axV6O1nfoG2k0pLzJ0sVJWvZbmM3p1v6lpt9Hv9hnO6ST3LaTCJW22KzlppYN69iktn2JXhpk3/AC7l2v8A02h/WRP00n7z9T8zMlX/AA9l1/8A12h/WRP0yn7z9WdGH3vZ9N+rZAANnpgAAAAAAAAAAAAAAAAIZIAAAAAAAAAAAAEAAIIAsCpYAAAAAABgAQSABDJsABUm5AAAACUSQSAAADo/Rn5SR9xeh+rb2foz8o07wj6GmNxczxCHpqV72ZL3aC21LuAvoG+gfpZE7PuBKa2J3dkQnpYstXuFZW1sW0a7FUtL32LJ2uwqluztdIndPWyKJ26llovIJ2Ss+ruR01Wgb311DldcrZWRx61tTjy2OXUj2+Jx6i3t0Ia0lxp2TufV/wBFzjPD8VcDYjgTNK18fltK+FcnrUw99LecG7ejR8n1L3O04J4kzHhLirA8QZZNxxGEqqXLeyqRekoPykro4efw68vBOOfwa2r1V0+scxw1XB4uphq0eWdOVmcKrseW5hiss4z4RwPGWQzVSlWpJ1Ir3o9HGX6UXdM8QrSPzK+K2K80tHeHgZsfRbTjVJNXOLWZrVlq2carLRmtHPLjYiMZpqSTIo4/EYWP1c/8IofmTesfRlastdNzjVZaHTFYmNSjenYxqUcUnLCz5mt6b0lH4dTCpK109zqaq9vnhJwmtVKLs0b08zcl9Xj4+1sq8V/9SJjDMeFZ1LkTkjOhi6mExVPEUJuFWnJShJPZoriLws201JXjJO6a8jhVpWReKRaNK7mJe/OG87w3EORxr8sJc8XTxFKWqTtaSa7P7mfJPjdwRU4J4vqUMPGTyvGXrYGb1tG+tN+cXp6WZ7X8OeIXk+fRo1qjWExTVOpd6Rf5Mv2fE888WeE6PGvB+IyxqMcZD8dgqj/IqpaL0ez9fI4vTOVb0X1DU/5d/P6/h/Z9JxuT84xxM+Y8vjzI8zq5XmNPFUpSstJpdYnu7+VKedZHh8dGalWglCo1+UujPQuLpVcNiauHr05Uq1KbhUhJWcZJ2afxPM/DbPHQqvLq8r05J2u+n9j+9n3HrHCjNSM1PNf7MeZh3Xrj3PJ8ymrPU8VzRqV0+55Nm3sTmmeKZrKylJ6JanJwo3py4J29g+K9R/ynlsL6Rwi+88Tpz0PJPFOop5nl009Hg4tfM8UhLQw4Nf8Ax6/997kmNuUpallLzOMpF1JLd6HV0qTDkKfKr9ehli8XTwmGniKsrRivi32Kwlf2n16HivE+PeJxX4PTl+KpPp1kXw4Pa317m/Gwe1vr3ODjcXWxmKnXrSvKWy7Lsd3wBwrmnGfE+FyLKoL62tK86kvdowXvTl5JHQYejVr16dCjTlUq1JKMIRV3JvRJLuz7M8EuAqfh7wovwqEXn2Pgp4yf+SW6pL06+Y9d9Wr6Vxt1+vPasf7/AHQ96tI8e55lwzk2WcJ8M4ThrJafLhMLG0pv3qtR+9OXdt/76GfEudYXI8oq4/FS0irQhfWcukUa18RChRlVqzUIQTcpN6JHovxA4nq8RZw3TlJYGg3GhHv3k/N/cfmHC4uTnZ5vknfvmWfL5UYadvPuddmuZ4nNcyrZhjJuVWrK/lFdEvJFaUzgQepyKT13PrfZxEah83Npmdy58Jm8X1ucOi5SmoQi5yfRHJqVMPhXavL66t0pQekfVmNo90Jju5mHpzq3lG0YLectIotUx+Fw75cLD8JrL/GTXsx9F1OsrYjEYt2qy5YLaEdEjSkoxVkjOcXvstGo8NLV8TW+txdWVR9m9Ec6m4wjaKscWEjTn8yswRZvzFlN3OLzmkZFJqt1ObCp5msZnChI2hKxnNVduZCepyKczgwkbQmYzVetnPp1NdzmUqmh1UJu5y8PzTmowV2zC9Ib1tt2uG5qlRQirtluJ87wXC+QV8yxctKatGN9ak3tFepdVcPlmCqYjEVYU404uVSpJ2UUv2Hz54n8YVuLM4/Fc0Muw7ccPB/ld5vzf2I29N9OnnZu/wBSPP6PQxxFa7ny6DPM3xue5ziM0zCpz168rvtFdIryS0IovSxxIKz2OVSv0P0KlIrWK1jtDG9nNhbe1zaKla6duxhQ3tb11OSnpKz2RaIclu8rc3tJta9dRUd1f4MjmXI+j6sS2vzP2e/UvEIZycdrfaV5b3SlqJS5utmG9W+ZaaF9JiE3Vr3uVk7x31uRKWr0SXZFJP2eVO6JiFlW7N2e+5HP7Px1KN6u7t0CfQstpMpWe7dyk30SIbffUmUu/QaW0rNvZvUzbSu2vtJlK70ehlOSJTDk5O7Z5l7v/wBMo/1kT9NJe8/Vn5k5G759ly/99of1kT9Np+8/U6MXvez6d4sgAGj0kEkWJJAAAAAAAAAAAAAAAAAAAAAAAAAAAQSyGAIAAAlEACwAAAhskCOpIAAAAAwQwIAAAAACUQWQAAAOj9GflDDSC9D9Xns/Rn5RR9xehpjcXM9yL3vYjbS5LW76kNuxo4S+tiz+Zm27lk2ELJ9y0St7LUcyuQjTXW5N0UTequWutdegVS3v1Dvyp3v5FbrbV+hLlYJTfQlNK5Xo00JWtoVRod31MatrM1b6bmNTq/kQvVw6i1ZhJas5VRO+hx5p3sHTSXtf6OXiW+Ds+lkubV/+Acymo1Of3cPVeiqfqvaXwfQ958YZU8uxf11C8sHW1pyTvyv82/3eR8YPQ+i/o8eJeFzXA0+AOLK95SiqWXYmpL3l0pN/nL8l/DsfM+vel+0j5xjjvHn9XJzON1x1Q8gqSOLUla53PFGTYrJMc6Fdc1OWtKolpNfv7o6CrI+UpG3h2iYnUsqknc41Ro0qS3ZxKktWzorDJE5WZlUaadyJyuYynY6KwhaliamFvGyq0JP2qbf2rszas6dWn9dQnz0+qe8X2Zwas7nG+tqUKn1lKVm910a8zX2fV3jya25FWWuh7i8PuIv5XyGFKvUvi8KlTqXesl+TL4r7j0u6iqxc6aat70fzf7DteDc5eTZ5Sryk1Rqfi6y/RfX4M4efw/nGGY19KO8OniZpw3+yXj30meF/5O4mp8SYSlbC5l7NflWka6Wv+ktfVM9UYPEzwuKp14N3hK9u/kfXvHGTYfinhXG5PVcf8Ip3ozf5FRawl8/sbPkDHYavgsXWwmJpulXozdOpB7xknZr5n0XyY5/zviexyfWp2++Pd+j6DFaMldS9nxxax+V068XzO1m+66Hj2ba0qi/RZx+Csx/weeDnL3dvR7fJ/eb5pZSkr3OjHi9jmmjy64/ZZZo8u47q/XYfIq6d+fAQ1+CPG4y03O0zet+EcK8O1b3ccPKk/wDNlY6hMx41enH0/CZ/vLlrHb8Z/u5EGUqTbnyL4kRlZNtmcZauT3ZrMIiGed478EwLUHarU9mPl3Z4mu5yM3xn4XjZST9iPsxO28PeGcZxfxXgsjwd06071anSlTWspP0X22PRxRTi4Zveda7y9ni4fZY+/mXt/wCilwLCvj58d5vSTwuDk4ZfTkv5yt1n6R2Xn6H0NXxLrVZVZPVs6fB4fB5RlmFyfLaapYPB01SpRXZdX5vdnU8X8QU8kyepiZNOq/ZpR/Ok9j8m9S5mX1Xlzk+PasfCP+95a5MsUq8d8XOJ3b+QsHO3MubEyT2XSP7WetUymIxNXE4ipiK83OrUk5Tk+rZEZH03E4deNiikfj9753PmnLebS5EDk0oez9ZOSp01vJ/sOK506KTrLmm/dpp/eUnVqV5c1V7bLojaabYxHxc542bi6WFTpU3vL8qRNGCjvucanJLY2UzOaxHhO3KjI1hLzOHGfmaxmZTU25cJl+c40JXNFIzmDbZS11NYz8zipmkZFJqnblwmaxkcOEmciDRlMG3KhK/U3hJnEg9Tm4WnOtNQpq7ML6hpXu3w0Z1ZqEE22d/hqNLBUJVak4rli3OcnZJLf4GGFpUcFQlOcoqyvOcnZJfuPTXir4gzzic8myepKGXRdqtVaPEPsv0PvKcbiZefl6Kdqx5l6PHxa7yp4q8dzz/EvKstnKOV0pe1JaOvJdf1V0XxPCKe1rnFpXuc6irqx95xuJj42OMeOO0N7dlo7m1OOu7Kwhq1ubxXsnTpzXs3pN32+JvB3X5xhTbWmxtHmSbQiGEjld+y3YrKV73drBve+xFRrlvs2XiEKSn7yvYzclr07CdrvqyunLfqy2l4hKldNJ6+pDdla9jOTaer1J5ldN6InSxO1tCsk1HsTJp9Ss73/tJ0mFZW76EPrqH1dyHfqEqzfQym9XYvJ6PqUm7O5MQvENslb/lzLnfX8Mo/1kT9Op+8/Vn5i5Lf+XMvv/65R/rIn6dT95+rNsXvev6d4sgAGr0ghkkMCQVJAkAAQr3JAAAAAAAAAAAAAAAAAAAACGQSwgIJsSAKgEoCQABAQCAkAAAAAIe5JDAgAACSCwAAAAABEvdfo/uPyip+5H0P1dn7kvR/cflHT9yPoaY/e4uZ7lZXuRK19yZJorJmjiQt9Sy2vfYoXSvchEpTV7krXyC9bEK3M9QhpqloTfXfQqmhur9ghZNau9g7tauxVXvorDXpqEJlo9GW1abb22RV3tfsRdp7jQlt/ErNa6ku+r7ET93QqmGM13Zx6yTWiORLb9hjU22Gm1HDnuUhKUJqcZOMou6admn3NqsbamD31IdNZ2+ofBzxPwPHGT0uD+Lq6jm8I8uFxUnb8JstLPpU7r8r1OTxHlWLyjGuhiI3i9adRL2Zry/cfLFKcqc41ITlGUWnFxdmmtmmfQfhX4tYLPsFT4V47qRdaVoYbMJO3O+im+kv0uvU+U9U9HnHac/Hjt74/wB4/R5nN4XVHVRyqkkcaozvOKMixWUVnLWrhZP2KqWno+zPHpy1PGx6tG4eFasxOpZzephUd7l6kjj1JHTWEM5zfUxnItUerMJPc3rAlVJUpqpFq/VdGia04O06b9iXfdd0zjylujJVeVtP3Zb+XmbRTa8Q9tcB53+H5JGjUnevhrU5Xe6/Jfy+49RfSHyCOD4ho5/hoWoZiuWtbZVorV/50bP1TO64LzR5dn1NVJONKt+KqfHZ/M8x8QMnjxFwpjct5VKs4fWYd9qsdY/PVfE8rjz+zPUYv/Dbz90/pPd6fE5GrRt82ZPiXhcxpVb2i3yy9GeT498ybPDZJxk4yTTTs0+h5RhK/wCE5bTqN+1bll6o+z5lPpVvDt5eP6Vbu/pT+t4Pwab/AJnE1IfB6nBb1Rpls78P16TfuYmMvnH+wwqOzRw9OptH2vLmNXtH2y0lK+h1+d4p4fBuMX7dT2V+1nMueN55X+uxrin7NNcq9eptx8fXfv4b8XF15O/iHBufUn0buFVwzwjPiLGxSzHN4L6qL3p0N4/6T19LHonwi4V/uu43wWW1oSeCpv6/GSXSlHVq/m7L4n1liKkVJU6UVClTShCMVZRitEkeB8rvUNUjh0nz3t93uj8XoZ8vT2htVxCSc5SslrdnpzjrPpZ1nMvq5P8ABaF4Ul37y+J5Z4kZ5+A5YsDRnaviU02nrGHV/HY9Xc19Fq+h43o3C1Ht7R9zx+Vm6vow5ClqktW9Ei0631EuWHtV/mof2nDnX+qbp03eptKX5vki0fYhb8p/YfQdHxcetN4uzbk7ye7N4S0OHCWptCVzO0Ky5kJF4zd7HGjLQ0jIwtVWXKjI2gzhwlqciDMbVHKgzaLVjixkaxkZzA3T8y8WYRZrAymEw2g9TkQZhTi27JXbO1wWAek6+i/N/ec+S8V8tK1m3gwGGqYiV17MFvJnczrYPKsFUxFarCjRpx5qlSbsl6nUcRcQ5Xw5gPr8dWULq1OlHWU32S/aek+NOMcx4mxNqsnQwUHelh4vRecu7J4fpufn23Panx/R6PH4/vd74jeIGIz+U8uy5zoZan7T2lW9e0fI8Gu7GaZeKufa8biY+PSMeONQ7fENKe+5zaBxKcVfscyjHs7HT0sby5kFdK70NFG63t3RnD2et2jRNu9+hGnJZrBq7Vk/U0i2/h0MotW00Zbm5Yt9hpRec1d82plUk3eOnl1sRN32erM379kXiExCNL2er7kTdk0noRzJ6LQiffpsy2loVk9Vcc93Z6/EiXvJtaepDSu3fcnS6z890Q203puU5lbzJvZ9yBL3139CJtNWbJbvrczk1qNLQzm1e6ZnJ6u+5pJ306swmtdCYhaHMyV/8NZfr/0uj/WRP06l70vVn5g5I3/LeXp/+t0f6yJ+n0/efqzbG9f0/wAWR1ABo9EDAAqAABYqWAAAAAGwAIuLgSQ2CALAACOpI6gAAAAAAgkAB1AAFSyAAAi5IAAAQAQAJIAAAlIALEgCCQAAAAAACJe7L0f3H5RRdoR/VP1dl7svR/cflErfVr0NMfvcXM/hUe9rshP2rBu7JW5dxoSXUtHfQIRfmSiVn2HwFyenmEC2t1JI876h25r31CEv3hqlbYXf9oUryvYCbr4lnbRXt5kXtdaakt3i9NQhV2VyH5otr62IezvuV0MZ2bdkZVF0N3HVmc0rhesuLON1uYSja9zlyWvmZzhd2W5Et6204jVmEaSjuupRq2+xDaJ29oeGvivjMmpQybiF1MwyhrkjOXtVKC7a+9Hy3XTseyMflWEzDBRzbh3E08Zg6i5lGErten7nqj5m8zu+EeK854XxjrZZiGqc/wCdoT1p1F5rv5rU8Pn+kVyz7XB2t8PdLg5fArljdO0va9VtSad01o0YzlocvIOKOHeNLUpP+Tc2a/m5PSb8n+V9jGcZZi8vm1Wp3h0nHWLPC1bHfoyRqXg5MV8U6tDrZyMZstJ6mVR7nRWFNM6jMKjL1GYzaOisLRA5Nx50/ajv+xns/hrNfw/KKFdy/GxXJU/WR6rjK1TX3Xo/Q8k4Ixzw2NrYKcvZqq8f1l+9HH6lx/aYd++O7SJ6ZevfFjKY5Txpi1SjahirYmlbZKW6+ErnV5BX9irQb/SX3M9j+NWAWNyLD5nTjepgqnLNr/Jz/dK3zPU2Bquli4SvZN2fxPd9OzfOuDWZ8x2n74e9it7fj/b+jzDLJ/4Niqd9HyS+Ta/aRVl7RjgJWdVN7w/ai0pXlcpPnbzbR9OZUxdf6nDzqP8AJWnqeMyfM3fd9Ttc9rWhCiur5n+wngzJp8Q8UYDKIXUa9VKpJfk01rN/JM7cM1w4pyW8efwh38WsUxzaXvn6PeQvIuDJ5rWjy4vN5KaT3hQjdRX+c7v0sewa+Ip0qM6tSSjCEXKTfRI4kZUqVOFKjFU6VOKhTgtoxSsl8keIeJudPDZUsvoytVxWkrdILf5n5nfr9R5k3nzafyj/AIh5ubP1WmXhvEebzzjOK2Mk3yyfLTj2itkcGdR0k4Qf4xr2n+b5epxlJ0YrT8ZLb9FFrOKUVrJn11MdaVisR2hw+e8popKfM/djqzVVG3dsxqO1oLZb+bEWWmE6cmMjaEjiwZtGRjaGblRkaRZxoSNosxmppyaUtTkwZw6bOXT1RjaEeG0WaRZijlYfD1Kr9mOnd7HPaYjymO6abuzn4TDVKmtrR7s2wmDp01zS9qX2HC4i4nyjIKb/AA3Ep1rXjQp+1N/DovU593y26ccbltjxTedRDvcLRp0Vdb92eJcZ+ImByiM8JlbhjMds5J3p035vq/JHrvirj7OM758PQk8Dgnp9XTl7Ul+lL9iPFYtdz2OF6D39pye/2fq9bBw4r3u7HNs0x2bY2eMzDEzr1pflSey7JdF5HHi2ZR3NYJvQ+krSIiIiNQ6Z1DWGr3ORSXWxlTj3OVSS2LRXTC9l4Jb2OTRS1bRilyya6m9OV/Z7ETDC0t+Zp3WhspeW61OPCb26Gyuklv8AEjTGW0db7J999CrknJptkc1rq9ikn7V7q3WwiFYhZyd97MrU0esrLuVb1um0+rvuG7rXWxbS0QrN2SfMtSsneO2vQVGuZq32mTdmrvQnSYXutdNSLtRstyOZarowmr6aWJWQ/l3IUtXrsLqxSV+6IF5TTT+wrJtrciT/APsVbvF66E6TA78u5jPr0NZW17GNSVk117heHIyP/wA4Mt1/6ZQ/rIn6gz95+p+X+Q/+cGW3/wDXaH9ZE/T+fvP1ZrR6/p/iyAAXegAAAVLACESAAAAAggAAAAJQJQAAAAwAIRJDAEgIAAAAIZJD3AgAACxBIAhkkNAQAAABKQBEgAAAAAAAAAAABEvcl+q/uPyhh/Nx/VR+r0/cl+q/uPygi19XH0Rpj97i5nuHq/MhoPe2xLt2LuI26h+pDVviNNdSRbpuOu406jpqwhK30JXkV5ktOjCer1ughdXuxq1bsQ7PYh776AXje/n5ktu9kR/nMO/Ndu4EtkrfXYrp31LN6b3IQrLrcymtbtG19LXKy0eqIIlxprXzKSRtPVsznuGtZcacdbmUkcmS3Mpx3ZDatmEkUZq1crKJEtolSEpQkpRk4yTumnZo9h8I+JuNwlGOX58p4/Ce6q29WC87+8vXXzPXbTIMM/GxcivTkjamXBTNXpvD3v8AV5ZmuHWMynFU5057OL9m/ZreLOsxlCpQnyVIuL+89S5XmePyrEfhGAxM6M+tnpLya6nn2R8dYXH044XOKcaNR6Kp+Q3/AOE8TN6bkwd6fSj+rweR6ZlxT1Y/pR/Vzqj1ZjI7DEYRSX1mHlzwaulfX+06+aadmrGNJiXHXuylucjD4h0MTQxMLqVNrm87f2GEiKercd7muotGpWecZnRp5plGJwUn7GKouCfm1o/nY+f60Z0qsoTXLOEnGS7NbnuzJMY54GMHL2qfs/uPV3iFhFhOKcS4K1PEWrx/zt/tuT6H+6yXwz971fTMveafi5WW1eejGon71P8Acchs6jIK16Tot6pO3odjVqKnTlNvSKbO3JTptMK5cfTeYdJmdb6zG1GndRfKvge1/o95SqcMfxDWj7TX4Lh7/Bzf3L5np9c1SpZK8pPRd2z6W4Ty6OScOYHK4+9RpL6x95vWX2u3wOL5QZ/ZcSMUebdvwjy25uT2WKKw8hqYjli5N2S1bPV3EOYfyhm1bHTd4J8lGPkjyfjPMnhcqdGErVMQ+RW6R6ngEpurUSSstkjxPSeN0xOWfuh40z1NaerlWnq194jKyc7+09hWkrxpx92G78+pm5XkexpSViUyEy3UpKF4svCWpki8WZzCkuRBm8GcWnds7PB4GtUs5Lkj3Zz5LRXyIpHY4XD1Z6pWXdnKwuDoUY35eaS6s6nPOMcjyjmpzxKxFdf4mh7TXq9kcu8ma3TirtfHjtknVY27/DYSnHWXtPzMs4z7Ksko8+OxUKcrezTWs5eiPVmeeIeb47mpYFRwFF9YPmqP/O6fA8Tq1qlaq6lapKpOTu5Sd2/id+D0O956s86+yHqYfTZ83nTz3iTxIzHGqWHymDwNF6fWb1X8dl8DwetUqVakqlWcpzk7ylJ3bfmzJMuux7uDi4uPXpxxp6FMdMcarCpaLJSLxgb6JsvSV2cynDQyoU9TmQhZebJ058llYI5MF5FYw631RrBN3REw55lZe9tc1hzK+zZC1VtizbWnQiWe14u73S7l+ZrV6R+4xTjs00zRSTVua1u5GkStKSuQpXbtroUvb1IcknZuxBENFLS1yHKzadmlujOcrX1sUcle7ZMQnS191dorq010RN3dso21LXqW0aXvp3SDklre5TmvvoHdK2gTpLe76kd7kdeV6E77ahKrT6lXdPQvdNMiTSV92EqSd92YzbV7mk5PcifW2xK0Ncjus9y53v8A4ZQ/rIn6hS95+rPy+yJf8O5cv/fKP9ZE/UGXvP1Zej1uB4sgAF3oAAAAAAAADIBAAAACUQSgJAAABsi4EgAARYkAAAAAAAhkhgVAAAsVAFkCESBFhYkAAAAAAAAAAAAAAAAARL3X6P7j8n4e5HX8lH6wP3X6M/KCHuR9DTH73HzPcjrqObfoQ29+xF9TRxLX6jvcpzaPe9y19AhZNpkyfYzv56FtAhD8guqvqTLyIaCVk2yyt3+BTVO/Quu4RK17X1sQtXr8yl3fXUlSswhe6a8ybey+hWO+i36l1dpdkEKu+9iL9yzSa1ZVp8uwkUmZSNpdykk76lVoljJa7mco6XN3rpYpJdCGsS40o6lJL5m0076FJINa2YNFWjZx7lWiGsSwt3ZBtJFGrErRLt+H+I8flMlTU3Ww3WlJ6L0fQ86wGZ5fnWHdShUtVS9qMtJR9V1XmerLGmHrVcNWjWoVJU6kdpRdmji5HDpl+lHaXDyuBjzfSr2t/wB8vZVeEqcrNejMHJxfMnsdVkvEdPFpYbHNU6r0UnpGf7mdrXjy6rVHmWxWpPTZ4l8V8Vum8d3MynEcmLav7NWOnqjo/E6h9ZTwWLW8HKlL0eq/acyjVcJKUfyWpHI4tpRxfD+Itq4RVWPw/suVxfu+RW63Hv7LPWfweBZNLlx8Y/nJo7HNqnJhJq+svZOqy6VswotfnHNzuXs04+bZ6+Su80Pay13mq7Hwzy5ZnxrgKc481KjP8Iq9uWGqv8bI+gZVL3bep6q8EcC6WHzDNpK31klh6b8l7Uv/AAnnWc5gsFl1avf2lG0fV7HynrVp5HL6I93b8XleoZevN0x7njPF2YfhmbzjGV6dFfVx9ev2nV004U3U6vSJx6ClUq6u7bu2c2tKMmox92Ksj0KY4x1ike5wz50wvZWCZEtytyZWbReppF6HHi7ystzsMNhJyV6j5V26mV7RXyztMV8skm3pqzk0MHUk7z9lfaRjsxyzKKPNia8KT6R3m/hueKZtx1Wm5U8sw6pR/wApV1fwWyKY8ObkfUjt8WmHjZs/1I7fF57F4TA0vra04U4rec5JHSZtx/l2EUqeApyxlVac3uwXx3Z6zx+YYzHVfrMZialaXTmei9F0MItHfi9Hxx3yzuXr4fSqV75J3Lv854pzvNW418XKnRf+Ko+zH7NX8TpbFU9Sx6lMdccapGoehWlccarGjqXWpCXxNYx0LaRNiJqk7FYwb6G8I62tsNMpsrCN/JG9KKe5Madk3Y3hGy0Iljay0IpLqcqCtptoZQVnZ6m8OV6u5DntO0x09TSCfchq7ul8LmkZKy1SsRLOVo2vrpYJx16FU1Z6a3DnZ3vvuV0qs5O12Obm06lG2rtMiU7O99QnTu8w4ZzzL+H8Hn2MwU6WX4yTjQqSkryfpuk+nc6i61TO2zzi3Ps8ynAZZmWOdbC4CPLQgopW0sm7btLS50rdk9bdzLDGXp/e63ufHw9xpZydtehRttWuOZ7202aJu+ba7ZunQ29uve5STj3enUicm2+pW7V09QldyVvQlvS9tTPqTeTf7QaWlJp6282RzRTsrkK2zZEnotrdxpK/No9fgVm3ZvZGbs9FuPZS0Y0lLtcpKSTfUSl1uUk/MaWhy8gf/GHLF/77Q/rYn6hS95+rPy84e04iyz/v1D+tifqHL3n6s0q9XgeLIABZ3gAAAi4uABAAAAAAABJBKAkAAQQS0LAQWIsSAAAAAAAAAIJIYEAAAAAJRJUm4EgAAAAAIuAFySpIEgAAAAAAAiXuv0f3H5PQ/m4+iP1hl7svR/cfk8n7Ct2NMbj5fuQyNbOyKt6slM0cad1cnXoQr2fW5PSwQJLzRe/Qrq0y35NtiEIvu+ou/VkX3SLJuzJBap23LXslfYrol1RaN7efmQgbXvWuHtcNt6XZLu0ttCRVb3NFo7LQzSNFdva4VlEtG9bsK7QlbvYdd7gR02Kzttcu3bYzbRCUMpJaeRe1+oaut9iJW2wklsl8Skom/L0DitSNLxZxJLUo4o5Eo76FJRDSLMJRM2mbyVkUlHuQ0izBoqbONyso2uGkWZPc8gyXPZUYLDYyTnSWkZ7uPr3R0NrE27GeTHW8alnlxUy16bQ85jUjdVINSi+z0aOxozVfASoy1Ti4P0a0PBcmzKeFmqNV3oSf+i+55Vhq3K7xl7Ml/wDY8zPgmkvD5PHtis8Hp81LFR1alCdvkzm5vO9eKb2iZ5zD6rNsQlt9ZzL46l8JCWaZzh6EY8v11WELX2TaPRt5jJ7oh7M/S6cnu090cE4SOXcKZfhr+06X1s/1p+1+1L4HXcZYt1K9PCRekVzy9eh3rqwpw0tGEVp5JHh1er+E42riZvRyuvTofJcWs5c1ss/f+b5nq67zeferH8VSS2nLfyRVMrObnJyYTbPT0RGoWbCi3u7HHxmMw+DouriKsYR6X3foup4zmfE2Irt08EnQp7c799/uLY+PfL48OjBxsmf6kdvi8mxmZ4PLlevWUZ9IrWT+B0OY8YY+qpUsGlh6b05nrP8AsPGpzlOblOTlJ7tu7Ysd+Pg4697d5erh9NxY+9/pStVqVKtSVSrOU5y1cpO7ZHQhbltzs07+0ILRTJjE1pxGlZtoii0UaRirF4w1b6FZhjN1YR1Nox1JUdC8INN9gymy0Im0FbWxMI6K5ooty06kMZstCKt1uaqD2ViIrWzNFH2dWrMpMsZkjfVOyNY6pvsUS636mqUuuhG1dpV7MuuXltYp9yLaa7kbVlVt7XuG7p8xM+XRRk3pr6lNNU3awiSFdrq+rK6621NJK1+VaFWly2ZKSMrNLfuizl06Gd5XvbQlxsr3J0lMpW05tS0px5V+8xb06sjmXUaNNZPVNaIrJ7tO9it3rqFfXXUnRpdWtpv1uyU20zN+7ZMapa7EaFm7P4EOSelivNrZslPrsEjfZkdHZpFnqt9Skr23uEwi9kyr7h6PRhtdQtEOTkbtn2XO+v4bQ/rIn6iy95+rPy5yDXiDLF3x1D+tifqNL3n6svV6vB8SgAFncEMMgAAAABKAgFiGBAAAFiFuSAAAAAAAABFySpYAAAAAABgAVBLIAAAAAAJRJCJAEAgAAAAAAlMkqALAhEgAABE/cl+q/uPycj7kfRH6xVP5qf6r+4/J2D/Fx/VNMfvcfL9yrsQ+5ZpXK9dTRyJW9i13tYr+0tfTRbEIW2e2vcXTvuLeW5N5KOyCEPTWyuWi9Cr731LXa1kSg/SJTuL3u0gnduyuELeZD2uiVzNPSwhCc5qEFzSk7JdyNoOujJ9nu2ROMqdSUJpxlF2afRkxtyvUbENrmJ28/PsR/vcl25WkyUDsrlZLS5a1/LzJku25GzbOUVvsiLWNNNSjWpEybVa13E42uG7PUmKc3+LTk+yV/uE6WiWTWrRSUex2tDJM6xLX4Pk2ZVr7cmEqSv8AJHOp8EcZVVenwnn0k+v4BU/cY2z4q/WtEfjC8S8ZtfUiUOx5YvDrjyUVJcH53Z98JJfeVq+HnHULuXCOdL//AJmZ/PeN/qV/OE9TxFxIlFHkGJ4P4qofz/DWcU/XB1P3HXYrKs0w7f4RluNpW/Pw84/ejWufFb6ton8V4yR8XVyjYo1Y5M4tO0lZ9noZSXkX8+GsWYyR2+Q5hyNYWtL2X7jb28jrJRMpaO6epS9IvGpRkpXLXpl2XEi/w6M1+VBfZoc/w5w/13FNCb2oQlV+KVl9rOqx2I/CcLRm17cLqTPKvCuivr8bimtVGNNP1d39yOTlWmnEtvzrX+zlz2nFxJifMRr/AGeaZ5iPqsE6aftVHyr06nj85JRUI7HJz7Ec+O+rT0pq3x6nXVKsKcJTnJRildt9DyOLj6aRHxeFSuohq5WOozfPqWEUqVC1Wtt+jH1OpzjPKmIcqOEbp0tnPrL9yOl9dT1cXE993r8b0/f0sv5NMXia+LrOtiKjqTffp6djNE2Ra2h3RHwerGqxqFUWSFiyVt9PUnSJkSuy8Ym2EwmKxM1HDYavXl2p05S+5HfYDgni7GJPDcM5vUT6/gskvtsZXzY8f17RH3yytkiPMughHU3ilbQ8wwvhX4g1mlHhfGQv/lJ04ffI7bDeCviLWWmR0o/rY2iv/Ect/VOFT62Wv5wym2/D17FX3RrCOvkeyqfgT4lzty5Nhf6QpfvOTDwE8Tt1kmGl6Y+l+8xn1jgf61fzhSa3nxD1jGOuiLrRWS30dz2d/eF8UenDikv0cZRf/iMcR4JeJ+Hu5cIY2p//AKp05/dImvqnDv2rlrP4wznHk/ll67SbepvGG1tDy3EeGHiFhU3iOCs9glu1g5SX2XOrxfD2d4CTWMyjMMM+v1uGnH70bfOKT4tDG0WjzDqlH2tTR027WRsqLhK0tGu+hyadFvVEWyQymXDhSaehylSbjY5MMPbob0qF3ojG2aIZzbbrpUXzXRDoys29zu6eCbd2i1XB21sUjkxs28elTe25i1ZOyO2xNBxbsjhTh5HRS/UbcdptX6kO7dm7WNJQa+C0KtK9ldW3NolbasVo22/Ilcq63aKzurq5SUumz7ltrR3TK/tN6Gbdm1bcs78t76FZN32+JaFoNNk7vuS9FrsV2dr6ktW3CS6vd7EtlNU9dhz30uQmBtWvazCla+pRyRa+lk7hOlpOy3IvffQq3puUctW7giF31RScuiehDn0ZnJ9eoWiHP4fl/wAYsr/79Q/rYn6kT95+rPyz4fl/xhyx/wDv1D+tifqZP3n6stV6fC8SgAFnchkEsAQASBABIE3KgAAABKJIJAMi4YAXFyAAAAAkgAWBCAEgAAAABUsyoAAAAAALdCBYCAAAAAAAlIASAAAAAAAVqaU5v9F/cfk84yg3Bqzi2mvRn6wVtaNRd4S+5n5S5hHkx2Jhe/LWnH5SZpjcnL8Q472IdvQm+tgzRxqr1LlfMtbr0CErR3TLb663KXd9SU7N2CB79yW3YqnZku1tAJTutdCyaSMW7JFnNWsCYaqavuW57O+hg3qOa2rdkQr0tbpt6F4NWt3O14b4S4m4iqKOS5FmGNT/AC6dF8i9ZOy+09n8MfR34zx/LUzbEYHKKT3Up/XVP9GOn2nJn53H48fvLxCNTPh6bvq7smzlK3VvRH1JlPgT4e5JFVOJM9q42a3jVxMMNT+V7/aeS5dm3gjwg7YLG8JYKrD8qDjXqfP2meRm+UWKO2HHa/3R2Wrjmfe+WuHeBOMc/lH+SOGs0xUZf4xYeUYf6UrI9iZN9HLjnFxU8zxWT5RB7qviXUmv82Cf3nubNfHjw2w1NpcSVcW1tHD4Wo19qSPDcy+khwjTnJYPKM5xNnpJxp00/nJs4MnqvrGb/I4+vvj9dNIx0jzLjZX9GrKKUovOeNMRVX5UMFgeX/am/wBh5Xl/gr4U5a/xuU5pmsl1xeOcU/hCx4Bj/pK0mn+BcJ1X2dbGpfYonj2N+kZxDNv8H4fyukunPUqT/ajzsuD5S8ifPTH3xH9l46Y+rD39hOFPDzLv/IfD/IotbSq0frX85XOdSxeHwN45fk+U4JdPqcJCP3I+X8R9IHjSfuYPJqfpQm/vkdfifHPjqrflrZdT/Vwi/azlt8mvV83+bff32lWZvPh9XVs/zNqyqwj6QR1mJzrNW3/hKX+ZH9x8p1fGLj2o7/yvSj5RwtP9xlPxY46mtc6X+rU/4Sa/Izle+a/nP6MrUyz/ABPqDEZvmuv+FL/4cf3HWYrOc21X4VD40onzZLxO42k9c7l/8Cn/AAlH4kcYy97NU/WhD9x01+SGev8AL/38HNbj5p/ifQOKznNle9ei/WkjrMTnmZu6l+DTXnGS/aekP74nFT1ljqUvXDw/cXXiNxB+XDBVPWk19zOmvyZzU91XNbh8ife9nZtiKGLi1jcmwGI/WSf3xPE81yThnE3c8jqYaX52GqW+y9vsPH14g4+S/HZfhpfqykv3krjehP8AnsBVg/0Zp/uO3D6byuP9WJj7p/5UjBy6fV/u4eZ8KYFyby/Mpwf+TxULfav3HjeZZPj8Fd1qDcP8pB80fmjy6fE+V11aX1sPKdO/3XMpY7L6v8xiqcW+nNb7Geniz8nH9eN/e6cXJ5NPr1eC81qU4/E9geHtsNklStLTmlzfYdLmGX4XEXk6cVJ/lw0O3wM44fJvqoy/KS38kaczJGbF0x75W52eM2GKxHmVcZioxdSvVmoq7k2zxbOMyqY2fJG8KK2j382WzbG1Mbifq6cZfVRdopL3n3N8Fw/jsQlOpy4eHepv8ka48dMMdV5b4cWPjx15J7uke5anCU5KEIynJ7KKuzzPL+F8DCSeIdbEvtfkj+88tynCxwkVDB4fC4Zd4xu/mY5/U6Y/qxtXL6rjr2pG3r7KuDeI8wadLLalKD/LrtU19up5bl3hdJQU80zmjS7woQ5mv86Vl9h5phKEqjvWr1JeSdkdrhsLhoaqlGT7vVnhcn1vkT2rOvuj9XDk9Sy38dniuWcB8H4eS+upYnHyX+UrOz+ELHl+T5NkGDs8Fw1hISW0vwaLfzldmzxOFw8b1a1Gil+dNR+8xlxbwzg2/wAIzzAxa3UanM/sueNm5HL5H80/n/syrkzZZ8zLyvB1MVGKjToKlHspKK+SOxw7xj3+qXrJs8BqeKXBmGWmY1qzXSlh5v77HFqeNXDdK/1OX5pW7PkhFP5yOOfSebl7xin8v1dVMV/g9tYf8K/ytJekH+87HDyxi/6SvhBHo5+PGAh/M8PYuX6+IivuTKPx/rRv9TwzT8ufFv8AZEpb5Oeo3/8AV/WP1ddKTHl9E4WriklfEy/0Uc+liMWl/wCU1D5m/wDzC50nalw7l0V+lWm/3F//AMw3ElvZyPKY/wCdUf7TL/CfqE/wR+cOmuSI976ioY3Gr/pNT5nPoZjjVtiJfGx8oR+kPxStsoyhfCf7zen9IripP/kjKH8Kn7yf8Keox4rH5ta8ise99b0c2xi3qJ+sUcqGbVmuWdKhNdnA+SKX0jeJl72SZS/jUX7TnYf6SWdxf4zhvLpfq15o1r6F6zi+rP8A/TWvLp75fUmJoZJj01j+H8rxKe/1mGhK/wA0dFmHhz4Y5nf8K4MwFOTessPF0n/sNHomh9JbF6fWcK4f/Nxcv4TssL9JfDJ/j+Fan/8AXjF+2JtTi+v4e+t/jWT5zx7ef7PYGafR/wDDrG80sBic3y2b2Ua/1kV8Jpv7TxbM/o3V6b58l4nw2IXSGKoOm/nFv7i2B+kpw3Nr8I4fzSl+rUpy/ajyHLfpB8CV5fjqWbYfzlh4y+6R015Hqsf5uP8AL/7KkxwMnnX9nr7G+CXGuATksvo4yK/Kw1eMr/B2Z4jnvCua5XeOPyzGYVr/ACtCUV82rH0ngfGrw6xK1z50H2rYecf2HdYXxF4CzCHJDizJakZfkVcTGN/hKx0Rmyb3O4ZzweNb6l/6w+IcywnLJ6aHS4qlyt9D7xzHhXw64ppOU8syTHc3+Mw0oKXzgz1/xP8AR04Tx3PUyrMcxyybvaMmq1NfOzt8T0sPqdKdrubJ6ZljvSYl8g1OVPVXKzcVbXSx7k4r+jzxvl05TyqeBziir2+qq/VVP9GWn2nq/iPhjiPh+bhnWSZhgP0q1FqL/wA5afaexh5eHL9S0S4r4b0+tGnSzd23bX1M5P5kyd7a3XkQ9G+p1wiFZbXsV11d7Im/K3p9pWTtqi8LwjmurN6FpSXLyp/Ezd1K7Jbvr0JW0lvRr7ysvMhyTe4fmxoQ3fUN6ENrZhvoNLJb6ESluuhD+ZEt9xoVb6hvTsG76WKy+4aWhzeHYyqcR5XTgryljaCSv/7SJ+psvefqz8u+Bqaq8b5FTbsp5lh1/wDNifqJL3n6loelw/EoABLtAAAAAAAARYgsAKgAASQABYqAAAAAAASESAAAAAAAABDILEMCACUgFibELckAAAIJsABFgSAIRJBIAAAACLgSBcALXaXc/KviSCpcQZnT25MZWjb0qSP1Uj78fVH5ceI2GlgvELiTCSVpUc2xUGvStNF6OXleIdB9426kPewNHGX1fmWTaT1KNvoT36BC977k3epVPQnUIQ9NQ5a3Javon8zXDPBwTliI1qr6Qg1FfGWr+SImTbjyd2d3lHCPEOZ01Xo5dOhhuuIxUlQpJfrTav8AAzoZ9Xwd/wCS8LhMBL/KQp89T/Tldr4WOBjsfjcdUdXG4yvip96tRz+8pPtLeNR/VX6U+HmOE4Z4Ny/2uIuM6daa3w2UUHWl6fWStH7zvMBxv4c8NtPh/wAP/wCUcTD3cVnGI53fvypNI9Vcz2uV5tDC3DjJ/mWmfx1H9NEY/jL25mfj9x5iIfVYCpl2V0krRjhsKnyrycm/uPDs68QeNs25lj+Ks2qxe8I4lwj8o2R4nzE3LY+DxsX1KR+S3SviK1SvUc61SdWT3c5OT+bKXtsQ5eZTm3udPjwtELuQvoZ871I5vgJlbpaOVijloyrfQo73KrRCzZVsh7kNBaIQmS5eZPwK8oW7LKRopaGMVqXG1ZiF+bclNWM2+wvYbRpp5kSKXsOYI0loozmYTB4jFv8AFU211k9EdnQyehRXPiaim102ijO+atPLO/Ipj8z3dJhqWKqz5cMqjf6L0R5HhsFjJUOTE1oxTVmoK7+ZWWY4LDR5abTS6QRxq+fz1VGjFecnc5bzky+K6cuS2bP9WuvvdzhMJRw9uSFn3erOasRh6Eb1qtOCX50rHhNfM8dWbUsRKK7R0OPzN6ttvuzP5jNu97M/2fa87yWec1eIssoaKpOs10pxv9rONU4z5E/wfBO/R1J/uPEdyVYtHp2GPMbaV9Pw18xt5LV42zyWlGrRoL9Gndr5nX4viLPcTdVs2xbXaNRxX2HU6XLJ6WN68TBTxSPydFcGOvisLzqVKs3KpOU33lK7+0i29tCvXQlPuba+DXwJGnQrcXI0rMyt5F1sZ3ZN9BpVonYvzmKZa7K6Rpup6l41GcZN7l0yJhWYcyFTU1VXzOCpeYU3fcpNWc1djGtoXjWaOBGehZVH6FJopNXZU613uc7D4i1tToY1Gt2cmlWtuzG+GJZzR5HTxOlrkVK91rY6aGJ6tl3iVbWRhPGZzV2CxFSlLmpTlTl0cHyv7Dt8r434vytp5fxPnGGS6Rxk3H5NtHjDrdU/mHVVty8YY98Ebjw9nZZ46eJGBl7ed08bBfk4vDQn9qSZ5Rg/pJ5tOh9RnfC+V42D0l9TUlTv8HzI9Czn2drmUppNu7K29O42T61I/t/ZvXNlj+J7ozLizwU4oqynnPB+YZJipv2q+BsrPu+RpP8A0TqMZwBwRm/t8IeI2XSm/dwuaL6mfpzWX3Hqqb1ujKbaWv2ivp84/wDKyWj7PMf1X6ur60PLuI/D/i7I4yq4vJq9bCrVYnC2r0mu/NC/2nismuZqV7rddTl5TnucZTPnyzNcbg3/AOxryivlex2mI4yxWYRcc9y7LM1f+VqUFSrf/Ep2fzudFY5FO1tW+7t/Sf1VmIjw8dnJyvcKf4tJ9DnYh5NiFKWFnicHN/4uu1Uj8JpJ/NHDUbJqMlJd0zoi2/ce5nJ+05WEmQ73YbWtkWRCL6sPS6uVZKd3uF06vcrK2xLkVl3AX0epDta9w2yjelkyVoh5J4XwVXxM4XpNc3PnGFjbv+NifpzL3n6n5o+B1CWK8ZeDqMVq85w0n6RmpP7j9LpbtkvS4n1ZQAA6wAAQSAAQAAAACCCwAqC1gBUmxIAWIsSAKkoMgCUSAAAAAAAAAAAACwIYuBIAAAAAAAAuQxYCCwAAAACpLZAAlCxNgG2p+av0hsJ+AeOHGOG2/wCFatW3lUtP/wAR+lR+fH0zMBLA/SCzury2WNoYbEx806UYP7YMvTy5+TH0Xp6+uoZW/Qt1NIcUmxKa9StwENN1qSyqYb6BCJPqVbvcnVoiQTCLtbPQi+oa0IswlLt3FwHsEobsQ31DTK9SBLdwxbQm1wspbUll+XTccuo0jbOzbI5dTblJ5dBo2w5ewt5G3L8Ao9b2B1M+XqV5Ua26BxVwdTKMLuxPJ22LuLVhYaOpnbUhrqczDYOtXu4xUYdZS0SOTCGCwru/8IqL/RRSbRHaFJzRHaO8uFhMvxOJ1hBxh+fLRf2nYU8Jl2D1rz+vqrp0XwKYnGV6qtzcsPzY6HEdrNlJpa31p0znrv5nUfY51bM6vu0YqnHp5HAxFWrVlepUlN+bIfcrLqi1aVr4hemOtfEMZ77FHuaSRHLoyzeFEWi9RbUlR1CZSr3LWYii6QUmVWiUvMm3Qmz6jSu0E/Anlt5lrK1gjai1ZdLQrY1jF23Csypyk8rsaKN1uTGG+pCOpmk2iyVloaKPQty20IlE2ZpEpamqjpcqoq+hGkbVbIeho03sRKLv5FZhXaE1e5fR9yIrTsXjG/QaJFbZ6l07SsQ4q77ostb2vsRMKJU2uu5KqO9rlLbu9gr3tb7SOlGobRqO+7NPrGo2ucdaPViUlfcdKvS3dR9Q5677GHM/j5slSdtGNHSvKersVet3f1KSd/Uo2TCYhZ776lb9OpEbsv7O5ZbwqtHqWTeutrEPshdWd2Ercz66hO+5RN99SyfREI0P3rkX6vch9kLsJhNyrlb0IbKSYTpN9d7kX03Kol+RK0PZv0VcL+GfSA4UpWvyYirWt+pRqS/YfokfCf0HcseN8b/w6145dleIrX7OfLTX/wBbPuwPS4sfQAAHShgkWAIAAAAAAAAAAAAAAAAAAQCQAAAAAAAAAAAAhkgCoJZAAAASTcqSBIAAAAAAABAZAAlEACwAAHxb/wDiC5Q8Px7w5niVo43LJ4Z6flUajf3VV8j7R1Pnf6emRPMPCrL87p03KplOZRc3b3aVWLg/hzKBas92eaN0l8Ok37joRv1NHnJXqSR1JJC6RN/MqxbQIWVh1IuyegESRPmA1YCrVybIbk2ViEqNIiy33LW1JtuBFluSu9iL2ZbZ6fEQHW1ha70J6uyJ6Eo2jS3n2CTXUl6OxNmtCEbUs1qLN3bL6p6h7Em2bTtoSlfcsTytK7+RCNkKUqkmoq/n2NYww9HWS+uqdF+Sv3lXKThy3sl0RRtWsysxtHeVq1arV0lLRbRWiXwM29Lakvy0IeuhPjwtERHhVtkORZrQra6C0Kth3JS7lkiE7ZqN3qGt9jRJFWuxJtS2l2So+Re1tyeXcJmVVFX20LKPW5K7FlHXcKTJZWuLeRZaNM0stWuoV2y5bMnl1La32GvYhG0KKe5Nl2JaSXctp0CNo21LQ1voL+RNtFZEKrK1+xaKd7lbaFk+hCuzuQldlr3+4nUG1bWT7iytrqJKxaN+9rkaNq9Ni0XYj4FvyWupAh8t7kpvlbWxCfQm9tEQgWsfQnRbMa81vmW01dkSiVHZSYaTe+hLbaZEVuwmFW1ewlotWHa6IslvsNJTe+hDSSbuRJadhJ6XAq9NSyelrlHf4ka6qwSsnpqy3MZprqi900wCfUupeyZ7Fr+yBLsVva+pDb2uVkwmFr6PUq9iEyG+g0lV6MX+AfcjoEvq3/8AD6yvmxnF2eNaQp4fBwfq5Tl90T62PRH0HcleW+C38o1KfLPNsxrYhPvCNqcf/ol8z3uHq4I1jgAAagAAAAAAAI6kgALkXDIAsAtgAAAAAAAAAAAAAAAAAAAAAMCGQAAAAAlEEoCQAAAAAAAVBLIAEkEoCQAAPEfGXhxcWeFvEfD/ACuU8VgKn1SX+UgueH+1FHlwXcImNvyVu9mrS6rs+xD3PYP0i+FHwZ4x8QZRCm4YWpiHi8J2dKr7at6Nyj8D18jZ5sxqZhbTsNbEK+5LZKppe99SVqVdum4W+pAkluzCFwHpqTr3I19CX2JQj4h7C1mH5BKN/Um1lvdkqyJuEKpfBlkQ2yUESldugtuTtsCdIOm9mNtCLtkp9yA6k6Fet+pL73APfQq2Wu9yHa3YgOgvrboQ7rqGQkkV2LdPUi1luBVvW+xPQl27E2SV7/AJ2qES0xf4AVbIb0LehDt2CDWxa2hXS2u5dbWCUJ+RdX7kIlBCzS+JIS1tcsurbCiLW3YXfp6lnFdyLpSCBJ7JNtkpO9kObT2dH6ltXs9O5CEWdu1iyS01sVas7c1/IK63Y0NE9XcRu9tCNX1JTvtuRpVZW/JYsn1v3Ka7LclX1uNGlmvgiySt6GbavvYtryt3IRobW/Ulu+xm3ZvV3JTa3Q0lZaXV7krXqVcrvZBN7aDSF90yVt2Kqz63RN7Xeq/aNIOjs/iRbqLvyDbtZsjQq+tlYrq/OxZy01ZndahaFmyHe9luVvqS2rjSUtq91qyL627kSdvQiT13J0mILq47lb9yL66jSdL36t6i6KX6IakGlm9bFW/MXuG16giENhvQhshu4WTcmMZ1JqnSi5VJtRgl1b0S+ZRs9k/Rl4V/uv8AGjIsDVp/WYTCVfw7Fdvq6XtJP1lyr4hatdzEPvrwyyCHC3h7kHD0I8rwOApUpr9PlTm/jJs8iG+oIetEajQQ2GQEhKIJQEgAAAAAAAqCSAJRJUstgAAAAAAAAAAAAAAAAAAAhgMAQAAAAAEogsAAAAAAAABDCDCAkAAARbUkAAAPlT/8QDg918uyLjrC025YaTy7GtfmSbnSb9Jc6/zkfIB+pXiRwthONeBc34Xxto08ww0qUZv/ABdTeE/82Si/gfmBnWXYzJ83xmU5jRdHG4OvPD16ct4zi2mvmjSs9nHnrq23E8he68iLom+hZzq3ZNg33Fu4FtPQMhMst7X1CEvYXIelyb+ZKEP7Rt6BrUMJNNyXuQrdCfK4Qd+5Kt33KqxboBbpuHsVXcm4QjZ7k97EenUhuwFm1pqNNyOtiVe173IDS+40bHS/dkdfIBfcKwe4S6ALaBkvYeYQjW4d9UOtg2QmEejJSsRoibqxIaEWJtra6DIFba+ZePnuRp8fvLLcEpsm0kWSV3pdlL2dkHv2uENE1Jb2/aPiUW+rLXdr6BWVm76Iq27K7Em2Vb5tEwL3Xmiytdq+hmnfd7FtFZ3+BBK8mr6agort6ErqvtCF+bW26BFm15oNWfl3CF7ol32Kb7dA5a7/AACE+V0/Mte/Uyu76Exk766A0u/e1ZKvr0K6N9ize/tfAIIvS3XuL223K620ZLa18iDSVfUm7troil29ehPNbqSJTV9WG+hSUupHNe5Bpabt10Ive5DdluQ29ddeoWhPSyYk7dSq8g2+tglMmisnoQ2mHJAQyXfZi/W5MmRKVZWvroQ2Gyra3CdLcwbKXIuQnSZPUhvoQyjfQLRCzl2Z9l/QH4PeC4YzjjbFUmquZVVg8JJ/5Gm7za8nPT/MPkDh3KMfxBn+AyTLKLrY3H4iGHoRXWUnZfBbvyR+oXAvDmD4R4PyrhrL9cPl2GhQjK3vtL2pPzcrv4iXTx6btt3RJAIdqSLDUkCLEgAAAAAAAAAAABUsAAAAAAAAAAAAAAAAAAAAAAALAACoAAkkgkAAAAAAAAAQGQBYBAAAAAAAHxd9O7w7nlnE2F8Qcuo/4HmvLh8w5VpTxMY+zN/rxVvWHmfaJ0fH/C+W8acHZnwzm0FLC4+g6bla7py3jNecZWa9CYnUqXp1Rp+V1yb6Hb8ccN5pwfxZmPDWc0XTxuArOlPTSa3jOP6MlZryZ06NnnzGuyzIfkSEQgVyxXoTsBNydLeZRvW5NyULX3QuVT0fYL7yDSVsHqE3cnuBGtyUyo2e9iRddyb9Si0uTfUITfXsCt+5PUGk+gvZEXvuF1YFvUa7EK/Vk31ZAaXJ+JF7aB9gHQddxcaBCL9tholuHsGyEouS/Ur1JAn7Cd0QFfVkoF/uyb6sX8ydLasgRfUm/cotHqyb9rBC11uxeysmVv2J8gnSb6W6k6rYpfoTe+twjS2t97eZPNoZ31t0LO2vmDSyloyybS3Mo72NE7q1yETCybtuLtkJra+pK13sEJ5lfYX3WyK9b+ZO6euhJoW93sFJXdyL7oO1yEaXu1bsTzX2KXXVk3eu2oQte17D0ZRtdRd6thK17aXuTKXcpdMjTq7g0t8SG+hXug32YNJbb0TuJNfEpfsOt3oQnS/NrfYi7e7K36sjm1YTob0JutismG9QnSVLV6lnLuZ63Jd7WBpMmVZD2uNyEnUMPYhhKHsQS92d3wHwvmfGfF+W8M5RT5sXj6ypqVrqnHeU5foxjdv0C0Rt9FfQO8PHis2xviPmNL8Rg+bB5YpL3qsl+NqL9WL5V5yl2PsU6bgnhvLeEOFMt4ayinyYPL6EaMHbWbXvTf6UndvzZ3JEy9HHToroABC4AAAAAAMgBckixIAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAiwsSABDJAFSwsAAAAAACASAAAAAAAAAAAA+cfpr+FM+KOGoccZHhXPOMnpNYynCPtYjCLVvzlDV/quXZHw+mfrdJKUXGSUotWaaumj4G+lp4N1eAOJJ8SZDhX/cvmdVuKgtMFWerpPtF6uL9V010pPuc2fH/FD0XdeZPTcoi3Qu5Ut3tqRdkX+YTewFrj4kX1HkBa4uiOg0uELC/Ur8Q3pqQaTf4C/UrfvqN2BZktruR8CdAF2Te5Vvy0J0TYFulyW9EUvZ+YUtAjSzYWvUi99Rf5gT59g9tSNgBPkxpr2D80Q/dCE+fQdwH3CTz3DbtcjTuT5ALvdEAnoBCepN7kMaBAl1ZN+5Vsl76kJSnvqLruRuLBCSHoHvoSlfUGi+t2TcdR1YE312LXK3JXcICYy1uyt9bi/QIa6t2bEnt0KJ7EvaydwaE/Mm6Zm3ruNLb2INNG2viE7lG9NG/Qnm1syUaWvduxDe7Kp38iX3uQDZL1KuXXQXutAlKa1sQ/kRddSdOoFbO+rsX06kPSzZDepAltFHsG9SL6hKzdiCL39Q97ATdCRV3sGFi+ov5kXIINLXFyqfZk3JBvzPuf6GvhS+EeGHxlnmF5M8zikvqKc17WFwr1S8pT0k/LlXc9N/RD8Gv7tM5jxlxHhr8PZdW/EUZrTG146286cXq+7su59zJW06ES68GP+KVgAVdQAAAAAAAAAAAAAAAAAAAAAAhsgCwIJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgRckqALHXcTZJlfEmQ4zI86wdPGZfjKTpV6M9pJ/c09U1qmkzsLgD83PpBeEuaeFfFbw0vrcVkeMlKWW41r349ac7aKpHr3Wq8vWh+qfHPCmRca8M4rh7iLBRxeBxMdYvSUJLacH+TJdGfn149+DmfeFedfjufH5DiZtYLMYxspdfq6iXuzS+D3XVLWttuPLi6e8eHrC5NyhJZivcLYqAL300DIvqTd3AgDUnUgRqShIdSULdCempUPuEJ+KuNO5D3Je4EPyRF+nQtcqyEwnXe/wJXe+pV6Cz2AvddCU9GVTJb6rYlGk3snYhtohvsybvYgH5k3vcrfUXvuwLfAblXbuTfy1AsyGOtyGwgvpoJdbPUrfsTqEpdrb6hrTci5OmoE26XJRXfYlXv3CE7BMhO5N9WiAvoS/Ui/Qi4Fk7BtFXe+obTCE7Medyr8hfXcGl07dyya9DNPUcyvtchGlrq4uit/IhsJ0u3YXumVbuQ38QjS/ME+5RvUc3UJ0v1Ji3cz6Eq1wjS99bIpJ67fEX8yJS6giFnLSybKtkNoq2yE6Xb8yLlWxcJWuWTMr2ZN1sE6XbK3IctSG3cGkvYi+mpDZATpZvyPaf0ePCDNPFLiT8Z9bhOHsHNPH41LV9fqqfebX+itX0T5X0efBDOfFHMPw7Eupl3DWHqcuIxvL7VVrenST3l3e0fN6H3zwhw3k3CXD+FyHIMDTwWX4WPLTpw6vrKT3lJvVt6siZb4sXV3nw5PD2T5bw/kmDyXJ8JTwmAwdJUqFGG0Yr731b3bbOfYAq7AAAAAAAAAAAAAAAAAAAAAAAAFQSyABYqWAAAAAAAAAIBABcEdSQAAAAAAAAAAAAAAAAAAAAAAAAAAAEMkAVBawsBUsRYkAdfxHkmU8R5LiclzzAUMfl+KhyVqFaN4yX7Gt01qnsdgAPhD6QX0a874KnXz/AIPjiM64dV51KSXNicEv0kvfh+ktV1XU+fV2P1xPQvjl9GvhnjZ1854ZdHh/PpJylyQthsTL9OC91v8AOj8Uy8X+Lnvh99XwV0J1tueRcfcD8UcCZy8p4oymvgK7b+qnJXpVkvyoTWkl6fE8cLuaY15SNLBkddyUJ6htEXDIE3XckpuTfuBYEXBKE9QRcl7AL9CdWOupaysBUMnQiVwI+Ja+mpVh+oE3I22AAO99R6kEgTvqE97EIne4E9A9mQnfcl92whX1De4luVd0QlKevYtGRTW9yU+nUhOlyfQomSShZ7i/cq2TcITey3Q0d0RJroVv8CELhvq9SrdyH5BKb63DeuupCJ6bAL+YegZDZAm+mjJe25W4v8AnSWxcrewbCNJb7aBPzIbTIfdA0uWRimWUtdwaXbeqKt9CL6kNsGk3Iv3IbDITpbQh76FbhslOkti5W4bGk6W5iLsqeV+G/h/xZ4gZv/JvC+U1cZKLX11d+zQoLvOb0j6bvomExG57PGEm3ZK7Z9JfR8+jPmHE34PxHx7Tr5bkrtOjgNYYjFro5dacP9p9LbnurwP+jjwvwHKhnGeuln/EELSjVqQ/wfDS/wDZwe7/AEpa9kj3l1KzPwdFMPvs4mS5Zl2TZVhsqynB0cFgcLTVOhQox5YQiuiRzACroAAAAAAAAAAAAAAAAQyQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARcCbgqALAhEgAABFxcgASSAAAAAAAAAAAAAAAdVxVw3kPFWUVMo4iynCZnganvUcRT5kn3i94vzTTPlnxY+iNOH12Y+HGac8dZfyVmFTX0p1uvkpr/OPrsExMwrakW8vym4r4a4g4UzWeV8R5PjMrxkf8XiabjzLvF7SXmm0dQ97H6u8ScP5HxLls8tz/KcHmeElvSxNJTS81fVPzVj588QvojcKZpOriuD83xORV3drDV19fh79k/fiviy/W57YJjw+Jbk3PavHf0evFLhL6ytV4enm2Dg3/hOWS+vVu7ivbXyPVeIpVcNXnQr0p0a0HaVOpFxkn5p6lmM1mPKt9Rd3Kp6luoVG99R6h7jqBa5N1uyvoWTs2BLtfUMbh/aShD8mH3HXUbbgPQNkXYISBENkvYICWRtqyWSBF2OpD63AlMtcoSBL7lX6k6kESQbAahshInqWbKE30uBYN2uQxvqNhfUNkMfeBJPlcr1sLhCyF2QmSEov3I9QNmQBLIuG+oE6Bu2pVk3Bo6jzIuG+wAEMIJEyGyzKvQkL6k3KlkrkJQL6HJy/BYzMsVHC5dg8RjK83aNLD0nUk36K57a4J+jX4rcSuFWtktPIsLJ/z2Z1Pq5W8qavL7ENrRWZ8PTd9Tu+EOE+JeL8zWW8M5Ljc0xLdnGhTbjDzlL3YrzbR9j+H30R+DconTxXF2Z4riGvHX6iC/B8On5pPml80fQHD+R5Pw9lsMtyLK8JluDh7tHDUlTj9m782RNmtcM+98r+Ev0ReWdLMvEnM4ySfN/JWX1NH5VK37If6R9UcOZHk/DmUUcoyHLMLluAoq1Ohh6ahFeem783qzsUCu29aRXwAAhYAAAAAAABDYuABIAAAAAAAAAAAAAAAAAAAAAAGBDZAAErckhEgAAAAAAAAAABDCZAAsAAAAAhkFgBUFiLAESAAIaJACwAAAAAAAAAAAAAAAAAAAAAAAHW50XE/B3CnE9F0uIeHMqzOL64nCxlL/StdfM70AeiuJvoreFObTqVMDhczySpLb8CxTcE/wBWdz17nv0M46yyHjuS7Qx2Bv8A7UJfsPrcE9UqTjrPufCObfRH8T8K5fgOO4ezFLbkxUqbfwlH9p43jPo1eMmFk0+FIYi3WhjqUv8AxI/RIhonrlT2FX5tYnwK8XMMn9ZwHmrt/k+Sf3SOur+EvidQ/nOAeIfhg5P7j9NR8X8yeuUfN6vzCqeGniLT0lwHxMn2WWVZfcin97jxE/6g8V/0NiP4D9Qk5fnP5k3f5z+Y65R83r8X5dvw48RP+oPFn9DYn+An+9v4i2/8wOLP6FxH8B+od3+c/mLvu/mOs+b1+L8un4b+Ir/9AOLf6FxP8Afht4i2/wCb/iz+hsR/AfqLd92Lvux1yfN6/F+XH97jxFvb+4Diz+hsR/AW/vbeIv8A1A4s/obEfwH6i80vzn8xzS7v5jrk+bx8X5cvw38Rtl4f8W/0Lif4Cf723iP/ANn3Fv8AQuJ/gP1F5n3fzJv5sdcnzevxflz/AHtfEf8A7PuLf6FxH8Afhp4j/wDZ/wAW/wBC4j+A/UXmfd/MXfdjrPm9fi/Lr+9p4kbLw94t/oXE/wABf+9l4k2/5vOLv6FxH8B+oV33Yu/Mjrk+b1+L8un4aeJC/wD294u/oXE/wD+9p4kf9nvF39C4n+A/Ubmfdkcz7v5jrT83r8X5dPw08R/+z7i3+hcT/AQ/DTxH/wCz7i3+hcR/AfqNzPu/mOZ938x1HzePi/Lf+9v4ip2/vf8AFv8AQuJ/gL/3tfEa3/N/xb/QuJ/gP1F5n3fzHM+7+Y6j5vHxflz/AHtvEZu397/i3+hcT/AX/vZ+JFv+b3i3+hcR/AfqJfzfzF/MdR83j4vy5l4a+I6//b7i3+hcT/AV/vbeI3/Z/wAW/wBC4j+A/Ui77v5i77v5jqPYVflyvDXxG6eH/Fr/AP8AC4n+APw08R7f833Fv9C4n+A/Ua77v5i/mx1nzePi/Lf+9t4jXt/e+4t/oXE/wF/72niRb/m+4t/oXE/wH6i8z7v5jmfdjqPm8fF+XL8NfEf/ALPuLf6FxP8AAS/DTxHt/wA33Fv9C4j+A/UTmfd/MXfdjqPm8fF+W78N/EW9v73/ABb/AELif4CV4a+Iz/8A2/4t/oXE/wAB+o/NLu/mOZ938x1Hzevxflw/DXxH/wCz7i3+hcT/AAEvw08R7f8AN/xb/Q2I/gP1G5n3fzF33Y6j5vHxflrLw68Qo+9wHxUvXJ8R/AWpeG/iHVlaHA3ErfZ5bVX3o/Ujml+c/mVbb3k/mOo9hV+YlHwm8Tq3ucA8Q/HByX3nZ4XwJ8XsU0qXAeaRv/lOSH3yP0ou+7+YHUewq/PPAfRk8ZcVZz4bw2GXevmFKNvk2eU5T9EHxCxKTzDPOHcAnulUqVmvlFI+4iR1StGGr5OyH6GeCjaWfcdYmp3hgcFGH+1Nv7j2Xwz9GTwiyZxnWyPE5xVj+VmOKnNP/MjaP2HucEbleKVjxDq+H+Hcg4ewyw2RZLl+WUV+ThcPGn9yO0AIWAAAAAAAAAAAAAAAAAAAAAAAAAAABDYQEgAAAAAAAAAAAAIsQWAEIkAAAAAAAABgLgqAJIAAlElSbgSAAAAAXBUlMCQAAAAAAAAAAAAAAAAAAAAAAAALgAAAFwVJAkEXJAAAALAAAAAAAAAAAAAAAAAAAAAAAAAAALgAAAAAAAAAAAAAAAAAAABBJABogACUSQiQAAAAAABcAAAAAAAAAAAAAAAAAAAAAAAC+oYFQCbAESAAAAAAAAAAAAAAAAAAAAAAMAQyAAAJAgE2DAgAASiSpYAGQLgQAABYqSgJAAAAAAABDJQIYEhEBASAAAAAEEgCCCwAhEgACLEgCoLENAQSiCyAAACpYjqSAAAAAAAAAAAAAAAAAAAAAAVLAAAAAAAAAAAAAAAAAAAAAIZIYFQTYWAIkAAAyLgSQCQIsSAAAAAAAAAAAAAAAAAAAAAAAQSABFiQAAAAAAAAAAAAAAAQSyoEokLYAAAAAAAhkkMASQHcCQQSBUFgBBIAFQSyAAAAFkQiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIJAAEMkAVLIgLcCQAAAAAENi4EgAAAAAAAAAAAAAAAAAAAAAAAhhEkW1AkAAAAAAuRcCQRckAAAAFyLgCAABYqSgJAAAAAAAAAAAAhgTci5AAkIglASAAAAAEXDIAsCCQAAAAXAAAAACLgSCLkASQABJJUsAAAAAAAAAAAAAAAAAAIuBJFtQEBIAIAAEgAAAAAAAAwAAAAAAAAAAAAAAAAAwIuSVJAkAAAAAAAAWAAAAAAAKgmwsAJAAAAAAAAAAAAAAAAAAAAAAAAAABshkATcgAAAAABIBEgAVAAAAAAABKJKkpgSAAAAAAAAQyQBUFrACLEgAAAAAAAgkAVLIiwAkAAVJQIAsAgAIZIAqCbCwEAmxAAlEACwAAIBAAAAADCAAAAAAIZAAAAASiSpYAAAAAAAAAAAAAAAAAAAAAAAAAAABBJAEAACUSQSAAAAAAAABC3JAAAAAAAAAAMi4ZAFgRckAAAAAAAEMCCUQWQAAAQSAAIZIAqCbEgVBIAgkEgRYkAAAAKgAAASkBALACoJsTYCpJIAAAAAAAAAAAAAAAAAMgMgCUySpK3AkAAAAAAAAAAAAAAAAhkkMCAABIuQSBKAQAi5JDJAjqSR1JAAENgAkCQIsCQBUEtCwBEgAAAAAAAAAAAAAAAAAAAAAD2AAqWAAAAQ0SAIsLEgCCQAAAAAAAAAAAAAAAAAAAAh7ixIAglAAAAAAAAhokARYkAAAAAAAAAAAAAAAAAAAAAAAiwsSAIsSAAAAAAAAAAAAAAAAAAAAAAAAAAIaJD2AqStyABYEIkAAAAAAAEXAkAAAAAAAFQSyABboVJAkAAQyCXuQAAAEggsAQAAAAAAAAAAAAAAAAAAAMAAAAAAAAAAABFiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI1uSCGwJuCpZAAAAAAAAAAAAAACxFiQAAuAA1uAAAABlSWACJAAAAAAGBUAACSCQJAAAixIAqCwAhEgAACGwJBBAFgQSAAAAAAAQyALXIuQAJuSQiQAAAAAACLkASSVJQEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgMCpYgICQAAAAFSxCRIAAAAAAAAAAAAAwDKkkACyCAAEC4EggXAkEXJAAAAAAAAAgLckjqBIAAAACLEoAAAAAAYAhggAAABKIJAkAAAAAAAAAACGSAKgtYhgQSQAAAAsCpOoBkEiwAmwAEPcXDABEgAAABUmxNgBFiQAAAAqWRBKAAAAAAAAAAAAAAAAAAAAAAAAAglAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwGBUkWFgJAAAAAAAAAFwBA3FgIJQsLMCSpOosBBNhYkCoLWIsASJAAAAAAAIJAAMqWIAIkqSgJAAAAAACAJuCoAlgIkCLCxIAAAAAAAAAAC4AAAAABDILEAQAAABKQEEoWJAAAAAAI6kpAAAAAAAAAAAAAAAEPcBkAWBCJAAAAAAAAAAAAAAAAABgAQmSQxcCWQBYCUAkAAAAAAAAAIZKIYQEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMWAYAFSUBIAAAAAAAAAAAAAAAAAAAMAAwAKlgAAAAAAAAAFiLEgAAAAAAAAAAAAAAhkEvcWAIkAAAAAAACwAEWJAAAAAAAAAAAAAAAAAAAAAAAKlkQLATYAAAAAAAAAAAAAAAAAAAAAAAAixIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgXDIAsgEAAIaJAAACAiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEgf/Z"
      width={size}
      height={size}
      alt="Flourish"
      style={{ flexShrink: 0, display: "block", borderRadius: size > 30 ? Math.round(size * 0.28) : 0, ...style }}
    />
  );
}
// ─────────────────────────────────────────────────────────────────────────────


function useWindowSize(){
  const [size,setSize]=useState({w:typeof window!=="undefined"?window.innerWidth:480,h:typeof window!=="undefined"?window.innerHeight:800});
  useEffect(()=>{
    const h=()=>setSize({w:window.innerWidth,h:window.innerHeight});
    window.addEventListener("resize",h);
    return()=>window.removeEventListener("resize",h);
  },[]);
  return size;
}

function computeStats(txns) {
  const sp = txns.filter(t=>t.amount>0);
  const byCat={}, byDow={0:0,1:0,2:0,3:0,4:0,5:0,6:0};
  let coffee=0,coffeeCount=0,delivery=0,subs=0;
  sp.forEach(t=>{
    byCat[t.cat]=(byCat[t.cat]||0)+t.amount;
    byDow[t.dow]=(byDow[t.dow]||0)+t.amount;
    if(t.icon==="☕"){coffee+=t.amount;coffeeCount++;}
    if(t.name.toLowerCase().includes("uber eats")||t.name.toLowerCase().includes("doordash"))delivery+=t.amount;
    if(t.cat==="Subscriptions")subs+=t.amount;
  });
  const totalSpent=sp.reduce((a,t)=>a+t.amount,0);
  const topCats=Object.entries(byCat).sort((a,b)=>b[1]-a[1]).slice(0,6);
  const days=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  const busiest=days[Object.entries(byDow).sort((a,b)=>b[1]-a[1])[0][0]];
  return{totalSpent,topCats,busiest,coffee,coffeeCount,delivery,subs,byCat};
}

// ─── ATOMS ────────────────────────────────────────────────────────────────────
function Card({children,style={},glow,onClick}){
  const [h,setH]=useState(false);
  return <div onClick={onClick} onMouseEnter={()=>onClick&&setH(true)} onMouseLeave={()=>onClick&&setH(false)}
    style={{background:C.card,borderRadius:22,padding:"18px 20px",
    border:`1px solid ${h?C.borderHi:C.border}`,
    boxShadow:glow?`0 8px 48px ${glow}22, 0 2px 8px rgba(0,0,0,0.55)`:h?"0 8px 48px rgba(0,0,0,0.6)":"0 4px 28px rgba(0,0,0,0.45)",
    transition:"all .25s cubic-bezier(.4,0,.2,1)",cursor:onClick?"pointer":"default",
    backdropFilter:"blur(12px)",...style}}>{children}</div>;
}
function Bar({v,max,color=C.green,h=7}){
  return <div style={{background:"rgba(255,255,255,0.06)",borderRadius:99,height:h,overflow:"hidden"}}>
    <div style={{width:`${Math.min(v/max*100,100)}%`,height:"100%",borderRadius:99,
    background:v>max?`linear-gradient(90deg,${C.red},${C.redBright})`:
    color===C.green?`linear-gradient(90deg,${C.green},${C.greenBright})`:color,
    transition:"width 1.1s cubic-bezier(.4,0,.2,1)",boxShadow:`0 0 8px ${v>max?C.red:color}44`}}/>
  </div>;
}
function Chip({label,color,size=11,icon}){
  return <span style={{background:color+"18",color,borderRadius:99,padding:"3px 10px",fontSize:size,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"inline-flex",alignItems:"center",gap:3}}>{icon&&<span style={{fontSize:size}}>{icon}</span>}{label}</span>;
}
function Toggle({on,onChange}){
  return <div onClick={()=>onChange(!on)} style={{width:48,height:28,borderRadius:99,cursor:"pointer",
    background:on?C.green:"rgba(255,255,255,0.10)",position:"relative",
    transition:"background .3s",flexShrink:0,
    boxShadow:on?`0 0 12px ${C.green}44`:"none"}}>
    <div style={{position:"absolute",top:4,left:on?24:4,width:20,height:20,borderRadius:"50%",
    background:on?"#fff":C.mutedHi,transition:"left .28s cubic-bezier(.4,0,.2,1)",
    boxShadow:"0 1px 6px rgba(0,0,0,0.6)"}}/>
  </div>;
}
function Btn({label,onClick,color=C.green,outline,small,disabled,full=true,icon}){
  return <button onClick={onClick} disabled={disabled}
    style={{background:outline?"transparent":color,
    border:`1.5px solid ${outline?color+"88":"transparent"}`,
    color:outline?color:"#060A0E",
    borderRadius:14,padding:small?"8px 20px":"13px 26px",
    fontWeight:800,fontSize:small?12:14,
    cursor:disabled?"not-allowed":"pointer",opacity:disabled?.35:1,
    display:"flex",alignItems:"center",gap:7,justifyContent:"center",
    width:full?"100%":"auto",
    fontFamily:"'Plus Jakarta Sans',sans-serif",
    boxShadow:!outline&&!disabled?`0 4px 20px ${color}44`:"none",
    transition:"all .2s cubic-bezier(.4,0,.2,1)"}}
    onMouseEnter={e=>!disabled&&(e.currentTarget.style.transform="translateY(-1px)")}
    onMouseLeave={e=>!disabled&&(e.currentTarget.style.transform="none")}>
    {icon&&<span>{icon}</span>}{label}
  </button>;
}
function Inp({label,value,onChange,type="text",prefix,placeholder,note,sm}){
  return <div style={{marginBottom:sm?10:14}}>
    {label&&<div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,marginBottom:5,fontWeight:700}}>{label}</div>}
    <div style={{display:"flex",alignItems:"center",background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,borderRadius:14,overflow:"hidden",transition:"border .2s"}} onFocus={e=>e.currentTarget.style.borderColor=C.green+"66"} onBlur={e=>e.currentTarget.style.borderColor=C.border}>
      {prefix&&<div style={{padding:"0 12px",color:C.muted,fontSize:14,borderRight:`1px solid ${C.border}`}}>{prefix}</div>}
      <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
        style={{flex:1,background:"none",border:"none",outline:"none",color:C.cream,fontSize:sm?13:15,padding:sm?"9px 12px":"12px 14px",fontFamily:"inherit"}}/>
    </div>
    {note&&<div style={{color:C.muted,fontSize:10,marginTop:4}}>{note}</div>}
  </div>;
}
function Sel({label,value,onChange,options}){
  return <div style={{marginBottom:14}}>
    {label&&<div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,marginBottom:5,fontWeight:700}}>{label}</div>}
    <select value={value} onChange={e=>onChange(e.target.value)} style={{width:"100%",background:C.cardAlt,border:`1px solid ${C.border}`,borderRadius:12,color:C.cream,fontSize:14,padding:"12px 14px",fontFamily:"inherit",outline:"none",cursor:"pointer"}}>
      {options.map(o=><option key={o.value} value={o.value} style={{background:C.bg}}>{o.label}</option>)}
    </select>
  </div>;
}
function CountUp({to,prefix="",decimals=0,dur=900}){
  const [v,setV]=useState(0);
  useEffect(()=>{let s=0;const step=to/(dur/16);const t=setInterval(()=>{s=Math.min(s+step,to);setV(s);if(s>=to)clearInterval(t);},16);return()=>clearInterval(t);},[to]);
  return <span>{prefix}{v.toFixed(decimals)}</span>;
}


// ═══════════════════════════════════════════════════════════════════════════════
// ██ FLOURISH FINANCIAL ENGINES — Modular calculation layer                   ██
// ██ All financial intelligence lives here.                                   ██
// ██ Architecture: Data Layer → Calc Engine → Forecast → Behavior → AI       ██
// ═══════════════════════════════════════════════════════════════════════════════

// ── ENGINE 1: FINANCIAL CALCULATION ENGINE ────────────────────────────────────
// Computes all core financial metrics from raw user data.

const FinancialCalcEngine = {
  /** Net Worth = all assets − all liabilities */
  netWorth(data) {
    const accounts = data.accounts || [];
    const debts    = data.debts    || [];
    const assets      = accounts.reduce((s,a) => s + parseFloat(a.balance||0), 0);
    const liabilities = debts.reduce((s,d) => s + parseFloat(d.balance||0), 0);
    return { assets, liabilities, netWorth: assets - liabilities };
  },

  /** Monthly cash flow = income − (bills + avg transaction spend) */
  cashFlow(data) {
    const incomes = (data.incomes || []).filter(i => parseFloat(i.amount) > 0);
    const bills   = data.bills || [];
    const txns    = (data.transactions || MOCK_TXN).filter(t => t.amount < 0);
    const monthlyIncome   = incomes.reduce((s,i) => s + parseFloat(i.amount||0), 0) || 4200;
    const monthlyBills    = bills.reduce((s,b) => s + parseFloat(b.amount||0), 0);
    const monthlySpend    = txns.reduce((s,t) => s + Math.abs(t.amount), 0) || monthlyIncome * 0.68;
    const totalExpenses   = Math.max(monthlyBills, monthlySpend);
    return { monthlyIncome, monthlyBills, monthlySpend, totalExpenses,
             cashFlow: monthlyIncome - totalExpenses };
  },

  /** Savings rate = (income − expenses) / income */
  savingsRate(data) {
    const { monthlyIncome, totalExpenses } = FinancialCalcEngine.cashFlow(data);
    return monthlyIncome > 0 ? Math.max(0, (monthlyIncome - totalExpenses) / monthlyIncome) : 0;
  },

  /** Debt ratio = total debt / annual income */
  debtRatio(data) {
    const { monthlyIncome } = FinancialCalcEngine.cashFlow(data);
    const totalDebt = (data.debts||[]).reduce((s,d) => s + parseFloat(d.balance||0), 0);
    return monthlyIncome > 0 ? totalDebt / (monthlyIncome * 12) : 0;
  },

  /** Emergency fund months = liquid savings / monthly expenses */
  emergencyFundMonths(data) {
    const accounts = data.accounts || [];
    const { totalExpenses } = FinancialCalcEngine.cashFlow(data);
    const liquidSavings = accounts
      .filter(a => ["savings","checking"].includes(a.type))
      .reduce((s,a) => s + parseFloat(a.balance||0), 0) || 1243;
    return totalExpenses > 0 ? liquidSavings / totalExpenses : 0;
  },

  /** Average daily spend from transaction history */
  avgDailySpend(data) {
    const txns = (data.transactions || MOCK_TXN).filter(t => t.amount < 0);
    const total = txns.reduce((s,t) => s + Math.abs(t.amount), 0);
    return total / 30; // assume 30-day window
  },
};

// ── ENGINE 2: SAFE-SPEND ENGINE ───────────────────────────────────────────────
// Core feature: What is truly safe to spend right now?
// Formula: Balance − UpcomingBills − DebtPayments − SavingsAllocation − SafetyBuffer

const SafeSpendEngine = {
  calculate(data) {
    const accounts = data.accounts || [];
    const bills    = data.bills    || [];
    const debts    = data.debts    || [];
    const today    = new Date().getDate();

    const balance  = accounts
      .filter(a => ["checking","savings"].includes(a.type))
      .reduce((s,a) => s + parseFloat(a.balance||0), 0) ||
      parseFloat((accounts[0]?.balance||1243.88).toString().replace(/,/g,""));

    // Bills due in the next 10 days
    const upcomingBills = bills
      .filter(b => { const d = parseInt(b.date); return d >= today && d <= today + 10; })
      .reduce((s,b) => s + parseFloat(b.amount||0), 0);

    // Minimum debt payments due this month
    const debtPayments = debts
      .reduce((s,d) => s + parseFloat(d.min||0), 0);

    // Safety buffer: 10 days of average daily spend
    const avgDaily   = FinancialCalcEngine.avgDailySpend(data);
    const safetyBuf  = Math.round(avgDaily * 10);

    // Savings allocation: 10% of monthly income
    const { monthlyIncome } = FinancialCalcEngine.cashFlow(data);
    const savingsAlloc = Math.round(monthlyIncome * 0.10 / 30 * 10); // 10 days' worth

    const safeAmount = Math.max(0, balance - upcomingBills - debtPayments - safetyBuf - savingsAlloc);
    const riskLevel  = safeAmount <= 0 ? "critical" :
                       safeAmount < balance * 0.15 ? "high" :
                       safeAmount < balance * 0.30 ? "medium" : "low";

    return {
      balance, upcomingBills, debtPayments, safetyBuf, savingsAlloc,
      safeAmount, riskLevel,
      overdraft: upcomingBills > balance,
      soonBills: bills.filter(b => { const d = parseInt(b.date); return d >= today && d <= today + 10; }),
    };
  }
};

// ── ENGINE 3: 90-DAY CASH FLOW FORECAST ENGINE ────────────────────────────────
// Projects daily balance for 90 days with overdraft risk detection.

const ForecastEngine = {
  generate(data, days = 90) {
    const { balance }       = SafeSpendEngine.calculate(data);
    const { monthlyIncome } = FinancialCalcEngine.cashFlow(data);
    const avgDaily          = FinancialCalcEngine.avgDailySpend(data);
    const bills             = data.bills || [];
    const today             = new Date();
    const todayNum          = today.getDate();

    let running = balance;
    const forecast = [];
    const overdraftRisk = [];
    const lowBalanceWarnings = [];

    for (let i = 0; i <= days; i++) {
      const d = new Date(today); d.setDate(todayNum + i);
      const dayNum  = d.getDate();
      // Payday: assume twice-monthly (1st and 15th)
      const isPayday = (dayNum === 1 || dayNum === 15) && i > 0;
      const dayBills = bills.filter(b => parseInt(b.date) === dayNum);
      const inc  = isPayday ? monthlyIncome / 2 : 0;
      const out  = dayBills.reduce((s,b) => s + parseFloat(b.amount||0), 0) + (isPayday ? 0 : avgDaily * 0.8);
      running = running + inc - out;

      const entry = { day: i, date: d, balance: running, income: inc, expenses: out,
                      isPayday, bills: dayBills };
      forecast.push(entry);

      if (running < 0)  overdraftRisk.push({ day: i, date: d, balance: running });
      if (running < balance * 0.12 && running >= 0 && !isPayday)
        lowBalanceWarnings.push({ day: i, date: d, balance: running });
    }

    return { forecast, overdraftRisk, lowBalanceWarnings,
             willGoNegative: overdraftRisk.length > 0,
             firstNegativeDay: overdraftRisk[0] || null };
  }
};

// ── ENGINE 4: BEHAVIOR ANALYSIS ENGINE ────────────────────────────────────────
// Detects spending patterns: payday spikes, subscription creep, impulse clusters.

const BehaviorEngine = {
  analyze(data) {
    const txns   = (data.transactions || MOCK_TXN).filter(t => t.amount < 0);
    const income = FinancialCalcEngine.cashFlow(data).monthlyIncome;
    const insights = [];

    // ① Payday spending spike: compare spend in days 1-3 vs rest of month
    const earlyMonthSpend = txns.filter(t => {
      const d = new Date(t.date); return d.getDate() <= 5;
    }).reduce((s,t) => s + Math.abs(t.amount), 0);
    const restSpend = txns.filter(t => {
      const d = new Date(t.date); return d.getDate() > 5;
    }).reduce((s,t) => s + Math.abs(t.amount), 0);
    const restDailyAvg = (restSpend / 25) || 1;
    const earlyDailyAvg = (earlyMonthSpend / 5) || 0;
    const spikeRatio = earlyDailyAvg / restDailyAvg;
    if (spikeRatio > 1.35) {
      insights.push({
        type:"pattern", icon:"📈", priority:"high", color: C.orange,
        title:"Payday spending spike detected",
        body:`Your daily spend is ${Math.round((spikeRatio-1)*100)}% higher in the first 5 days of the month. This pattern is responsible for most cash shortfalls later.`,
        saving: `$${Math.round((earlyDailyAvg - restDailyAvg) * 5 * 0.6)}/mo if corrected`
      });
    }

    // ② Subscription creep: count + total subscription transactions
    const subTxns  = txns.filter(t => t.cat === "Subscriptions");
    const subTotal = subTxns.reduce((s,t) => s + Math.abs(t.amount), 0);
    if (subTxns.length >= 3 && subTotal > 35) {
      insights.push({
        type:"warning", icon:"📱", priority:"medium", color: C.teal,
        title:"Subscription creep detected",
        body:`${subTxns.length} recurring subscriptions totalling $${subTotal.toFixed(0)}/mo. That's ${Math.round(subTotal/income*100)}% of your income.`,
        saving: `$${Math.round(subTotal * 0.35)}/mo potential saving`
      });
    }

    // ③ Dining / delivery inflation
    const diningTxns  = txns.filter(t => ["Food","Coffee","Dining"].includes(t.cat));
    const diningTotal = diningTxns.reduce((s,t) => s + Math.abs(t.amount), 0);
    if (diningTotal > income * 0.18) {
      insights.push({
        type:"pattern", icon:"🍔", priority:"medium", color: C.gold,
        title:"Food spending above benchmark",
        body:`Food & dining is $${diningTotal.toFixed(0)}/mo — ${Math.round(diningTotal/income*100)}% of income. Benchmark is under 15%.`,
        saving: `$${Math.round(diningTotal * 0.25)}/mo by cooking 3x more/week`
      });
    }

    // ④ Spending stability (variance) — low variance = better score
    const daily = {};
    txns.forEach(t => {
      const k = t.date?.slice(0,10) || "na";
      daily[k] = (daily[k]||0) + Math.abs(t.amount);
    });
    const vals = Object.values(daily);
    const mean = vals.reduce((s,v)=>s+v,0) / (vals.length||1);
    const variance = vals.reduce((s,v)=>s+Math.pow(v-mean,2),0) / (vals.length||1);
    const cv = Math.sqrt(variance) / (mean||1); // coefficient of variation

    return { insights, spikeRatio, subTotal, diningTotal, spendingStability: Math.max(0, 1 - cv) };
  }
};

// ── ENGINE 5: FINANCIAL HEALTH SCORE ENGINE (spec-compliant weights) ──────────
// Weights from Flourish spec: Savings 25%, Debt 20%, Emergency 20%,
// Spending Stability 15%, Investments 10%, Credit 10%

// ── ENGINE 5: FINANCIAL HEALTH SCORE (spec-compliant: Savings 25%, Debt 20%, Emergency 20%, Stability 15%, Investments 10%, Credit 10%) ──
function calcHealthScore(data) {
  // Pull from engines for consistency
  const { monthlyIncome, totalExpenses, monthlySpend } = FinancialCalcEngine.cashFlow(data);
  const efMonths      = FinancialCalcEngine.emergencyFundMonths(data);
  const debtRatio     = FinancialCalcEngine.debtRatio(data);
  const savingsRate   = FinancialCalcEngine.savingsRate(data);
  const { spendingStability } = BehaviorEngine.analyze(data);
  const accounts      = data.accounts || [];
  const debts         = data.debts    || [];

  // ① Savings Rate — 25 pts
  // 20%+ savings rate = full score; 0% = 0 pts
  const srScore = Math.min(25, Math.round(savingsRate * 125));

  // ② Debt Ratio — 20 pts
  // No debt = 20; debt > 1× annual income = 0
  const drScore = Math.max(0, Math.round(20 * (1 - Math.min(1, debtRatio * 1.25))));

  // ③ Emergency Fund — 20 pts
  // 3 months = 15 pts; 6 months = full 20 pts
  const efScore = efMonths >= 6 ? 20 : efMonths >= 3 ? 15 : efMonths >= 1 ? 9 : Math.round(efMonths * 6);

  // ④ Spending Stability — 15 pts
  // Low variance in daily spend = higher score
  const ssScore = Math.round(spendingStability * 15);

  // ⑤ Investments — 10 pts
  const hasInv = accounts.some(a => a.type === "investment");
  const invBal = accounts.filter(a => a.type === "investment").reduce((s,a) => s + parseFloat(a.balance||0), 0);
  const ivScore = hasInv ? Math.min(10, 5 + Math.round(Math.min(5, invBal / (monthlyIncome * 3)))) : 0;

  // ⑥ Credit Health — 10 pts
  const rawCredit = data.profile?.creditScore ? parseFloat(data.profile.creditScore) : 680;
  const crScore = rawCredit >= 760 ? 10 : rawCredit >= 720 ? 8 : rawCredit >= 670 ? 6 : rawCredit >= 620 ? 4 : 2;

  const score = Math.min(100, Math.max(8, srScore + drScore + efScore + ssScore + ivScore + crScore));

  const pillars = [
    {label:"Savings Rate",    pts:srScore, max:25, detail:`${Math.round(savingsRate*100)}% savings rate`},
    {label:"Debt Ratio",      pts:drScore, max:20, detail:`${Math.round(debtRatio*100)}% of annual income`},
    {label:"Emergency Fund",  pts:efScore, max:20, detail:`${efMonths.toFixed(1)} months covered`},
    {label:"Stability",       pts:ssScore, max:15, detail:`Spending consistency`},
    {label:"Investments",     pts:ivScore, max:10, detail:hasInv?`$${invBal.toFixed(0)} invested`:`Not started`},
    {label:"Credit",          pts:crScore, max:10, detail:`Score ~${rawCredit}`},
  ];
  return { score, pillars, breakdown:{ srScore, drScore, efScore, ssScore, ivScore, crScore } };
}

function HealthScoreRing({score, size=110, strokeW=9, bonus=0}) {
  const [displayed, setDisplayed] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = Math.ceil(score / 40);
    const t = setInterval(() => {
      start = Math.min(start + step, score);
      setDisplayed(start);
      if (start >= score) clearInterval(t);
    }, 22);
    return () => clearInterval(t);
  }, [score]);
  const r = (size - strokeW * 2) / 2;
  const circ = 2 * Math.PI * r;
  const progress = (displayed / 100) * circ;
  const grade = score >= 80 ? "Excellent" : score >= 65 ? "Good" : score >= 50 ? "Fair" : score >= 35 ? "Needs Work" : "Critical";
  const gradeColor = score >= 80 ? C.greenBright : score >= 65 ? C.tealBright : score >= 50 ? C.goldBright : score >= 35 ? C.orangeBright : C.redBright;
  const gId = "hsr" + size + score;
  return (
    <div style={{position:"relative", width:size, height:size, flexShrink:0}}>
      <svg width={size} height={size} style={{transform:"rotate(-90deg)", display:"block"}}>
        <defs>
          <linearGradient id={gId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={score>=65?C.green:C.gold}/>
            <stop offset="100%" stopColor={gradeColor}/>
          </linearGradient>
        </defs>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={strokeW}/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={"url(#"+gId+")"}
          strokeWidth={strokeW} strokeDasharray={`${progress} ${circ}`}
          strokeLinecap="round" style={{transition:"stroke-dasharray 0.05s linear"}}/>
      </svg>
      <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:0}}>
        <div style={{fontSize:Math.round(size*0.27),fontWeight:900,color:gradeColor,fontFamily:"'Playfair Display',serif",lineHeight:1}}>{displayed}</div>
        <div style={{fontSize:Math.round(size*0.094),color:C.muted,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,lineHeight:1.3}}>{grade}</div>
        {bonus>0&&<div style={{fontSize:Math.round(size*0.082),color:C.greenBright,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,marginTop:1}}>+{bonus} ✦</div>}
      </div>
    </div>
  );
}

function WeeklyCheckInModal({data, onClose, onComplete}) {
  const [step, setStep] = useState(0);
  const [mood, setMood] = useState(null);
  const [surprise, setSurprise] = useState("");
  const [win, setWin] = useState("");
  const [insight, setInsight] = useState(null);
  const [loading, setLoading] = useState(false);

  const moods = [
    {emoji:"😰", label:"Stressed", val:1},
    {emoji:"😕", label:"Uneasy",   val:2},
    {emoji:"😐", label:"Neutral",  val:3},
    {emoji:"🙂", label:"Okay",     val:4},
    {emoji:"😄", label:"Great",    val:5},
  ];

  const surpriseOpts = ["Eating out","Subscriptions","Shopping","Fuel / Transit","Impulse buy","Medical","Entertainment","Other"];
  const winOpts = ["Skipped a purchase","Paid a bill early","Saved something","Stuck to budget","Paid extra on debt","Nothing yet"];

  const fetchInsight = async () => {
    setLoading(true);
    const txns = (data.transactions || MOCK_TXN).slice(0, 15).map(t=>`${t.merchant} $${Math.abs(t.amount)}`).join(", ");
    const {score} = calcHealthScore(data);
    const prompt = `You are a warm financial coach. The user just completed their weekly money check-in. Their current Financial Health Score is ${score}/100. Their money mood this week: ${moods.find(m=>m.val===mood)?.label||"Neutral"}. Biggest spending surprise: ${surprise||"none"}. Financial win: ${win||"none"}. Recent transactions: ${txns}. Give ONE specific, encouraging action they can take this week to improve their Financial Health Score by 2-5 points. Keep it to 2 sentences max. Be warm and concrete.`;
    try {
      const r = await fetch("/api/coach", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ type:"checkin", payload:{ prompt } })
      });
      const d = await r.json();
      setInsight(d.content?.[0]?.text || "Great job checking in! Keep tracking your spending this week and look for one subscription you can pause.");
    } catch { setInsight("Great job checking in! Focus on one small win this week — even saving $20 moves your score forward."); }
    setLoading(false);
    setStep(4);
  };

  const steps = [
    // Step 0: Mood
    <div key={0} style={{display:"flex",flexDirection:"column",gap:20}}>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:32,marginBottom:8}}>💚</div>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:900,color:C.cream,lineHeight:1.2}}>How do you feel about money this week?</div>
      </div>
      <div style={{display:"flex",gap:10,justifyContent:"center",flexWrap:"wrap"}}>
        {moods.map(m=>(
          <button key={m.val} onClick={()=>setMood(m.val)} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:6,padding:"14px 12px",borderRadius:18,border:`2px solid ${mood===m.val?C.green+"88":C.border}`,background:mood===m.val?C.greenDim:C.card,cursor:"pointer",minWidth:60,transition:"all .15s"}}>
            <span style={{fontSize:28}}>{m.emoji}</span>
            <span style={{fontSize:10,color:mood===m.val?C.green:C.muted,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>{m.label}</span>
          </button>
        ))}
      </div>
      <button onClick={()=>mood&&setStep(1)} style={{background:mood?`linear-gradient(135deg,${C.green},${C.greenBright})`:"#e0e0e0",color:mood?"#fff":C.muted,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:15,padding:"14px",borderRadius:99,border:"none",cursor:mood?"pointer":"default",transition:"all .2s"}}>Next →</button>
    </div>,

    // Step 1: Surprise
    <div key={1} style={{display:"flex",flexDirection:"column",gap:20}}>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:32,marginBottom:8}}>💸</div>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:900,color:C.cream,lineHeight:1.3}}>What was your biggest spending surprise?</div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
        {surpriseOpts.map(o=>(
          <button key={o} onClick={()=>setSurprise(o)} style={{padding:"12px 10px",borderRadius:14,border:`1.5px solid ${surprise===o?C.orange+"99":C.border}`,background:surprise===o?C.orangeDim:C.card,color:surprise===o?C.orange:C.mutedHi,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,fontSize:12,cursor:"pointer",transition:"all .15s"}}>{o}</button>
        ))}
      </div>
      <div style={{display:"flex",gap:10}}>
        <button onClick={()=>setStep(0)} style={{flex:1,padding:"13px",borderRadius:99,border:`1px solid ${C.border}`,background:"none",color:C.muted,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,cursor:"pointer"}}>← Back</button>
        <button onClick={()=>setStep(2)} style={{flex:2,background:`linear-gradient(135deg,${C.green},${C.greenBright})`,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:15,padding:"13px",borderRadius:99,border:"none",cursor:"pointer"}}>Next →</button>
      </div>
    </div>,

    // Step 2: Win
    <div key={2} style={{display:"flex",flexDirection:"column",gap:20}}>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:32,marginBottom:8}}>🏆</div>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:900,color:C.cream,lineHeight:1.3}}>Share one financial win this week</div>
        <div style={{color:C.muted,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",marginTop:6}}>Every small step counts.</div>
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        {winOpts.map(o=>(
          <button key={o} onClick={()=>setWin(o)} style={{padding:"12px 16px",borderRadius:14,border:`1.5px solid ${win===o?C.green+"99":C.border}`,background:win===o?C.greenDim:C.card,color:win===o?C.green:C.mutedHi,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,fontSize:13,cursor:"pointer",textAlign:"left",transition:"all .15s"}}>
            {win===o?"✓ ":""}{o}
          </button>
        ))}
      </div>
      <div style={{display:"flex",gap:10}}>
        <button onClick={()=>setStep(1)} style={{flex:1,padding:"13px",borderRadius:99,border:`1px solid ${C.border}`,background:"none",color:C.muted,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,cursor:"pointer"}}>← Back</button>
        <button onClick={fetchInsight} style={{flex:2,background:`linear-gradient(135deg,${C.green},${C.greenBright})`,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:15,padding:"13px",borderRadius:99,border:"none",cursor:"pointer"}}>{loading?"Getting your coaching...":"Get My Insight →"}</button>
      </div>
    </div>,

    // Step 4: Result (loading is step 3, handled inline)
    insight && <div key={4} style={{display:"flex",flexDirection:"column",gap:20,textAlign:"center"}}>
      <div style={{fontSize:48,animation:"fadeUp 0.4s ease both"}}>✦</div>
      <div style={{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:900,color:C.green,lineHeight:1.2}}>Check-In Complete!</div>
      <div style={{background:C.greenDim,border:`1.5px solid ${C.green}33`,borderRadius:20,padding:"18px 20px",textAlign:"left"}}>
        <div style={{color:C.green,fontSize:10,textTransform:"uppercase",letterSpacing:1.6,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,marginBottom:8}}>Your AI Coach Says</div>
        <div style={{color:C.cream,fontSize:14,lineHeight:1.7,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{insight}</div>
      </div>
      <div style={{background:`linear-gradient(135deg,${C.green}18,${C.greenDim})`,border:`1px solid ${C.green}33`,borderRadius:18,padding:"16px"}}>
        <div style={{fontSize:28,marginBottom:4}}>🎯</div>
        <div style={{color:C.green,fontWeight:800,fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:16}}>Financial Health Score</div>
        <div style={{color:C.greenBright,fontWeight:900,fontFamily:"'Playfair Display',serif",fontSize:32,marginTop:4}}>+3 points this week ✦</div>
        <div style={{color:C.muted,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",marginTop:4}}>Check in every week to keep growing</div>
      </div>
      <button onClick={()=>onComplete(3)} style={{background:`linear-gradient(135deg,${C.green},${C.greenBright})`,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:15,padding:"16px",borderRadius:99,border:"none",cursor:"pointer",boxShadow:`0 6px 20px ${C.green}40`}}>Done — See My Score ✦</button>
    </div>,
  ];

  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.55)",backdropFilter:"blur(6px)",zIndex:999,display:"flex",alignItems:"flex-end",justifyContent:"center",padding:"0 0 0 0"}} onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{background:C.bg,borderRadius:"28px 28px 0 0",padding:"28px 24px 40px",width:"100%",maxWidth:520,maxHeight:"88vh",overflowY:"auto",boxShadow:"0 -20px 60px rgba(0,0,0,0.2)"}}>
        {/* Step indicator */}
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:24}}>
          <div style={{display:"flex",gap:6}}>
            {[0,1,2,3].map(i=>(
              <div key={i} style={{width:i<=(step===4?3:step)?28:8,height:8,borderRadius:99,background:i<=(step===4?3:step)?C.green:C.border,transition:"all .3s"}}/>
            ))}
          </div>
          <button onClick={onClose} style={{background:"none",border:"none",color:C.muted,fontSize:22,cursor:"pointer",padding:"4px 8px",lineHeight:1}}>×</button>
        </div>
        {loading
          ? <div style={{textAlign:"center",padding:"40px 20px"}}>
              <div style={{fontSize:40,marginBottom:16,animation:"spin 1s linear infinite"}}>💚</div>
              <div style={{color:C.cream,fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:16,fontWeight:600}}>Analyzing your week...</div>
              <div style={{color:C.muted,fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:13,marginTop:8}}>Building your personalized insight</div>
            </div>
          : steps[step===4?3:step]
        }
      </div>
    </div>
  );
}




// ─── ONBOARDING ───────────────────────────────────────────────────────────────
function Onboarding({onComplete}){
  const [step,setStep]=useState(0);
  const [p,setP]=useState({name:"",country:"CA",province:"ON",status:"single",hasKids:false,partnerName:"",creditScore:680,creditKnown:false});
  const [incomes,setIncomes]=useState([{id:1,label:"Primary Income",amount:"",freq:"biweekly",type:"employment"}]);
  const [bills,setBills]=useState([{name:"Rent/Mortgage",amount:"",date:"1"},{name:"Hydro/Electric",amount:"",date:"11"},{name:"Phone",amount:"",date:"15"}]);
  const [debts,setDebts]=useState([{name:"Credit Card",balance:"3420",rate:"19.99",min:"68"}]);
  const [bankStage,setBankStage]=useState("select");
  const [selBank,setSelBank]=useState(null);
  const [bankCreds,setBankCreds]=useState({user:"",pass:""});
  const [mfa,setMfa]=useState("");
  const [bankProg,setBankProg]=useState(0);
  const [connAccts,setConnAccts]=useState([]);



  const doAuth=()=>setBankStage("mfa");
  const doMfa=()=>{
    setBankStage("loading");let prog=0;
    const t=setInterval(()=>{prog+=Math.random()*15;if(prog>=100){prog=100;clearInterval(t);setTimeout(()=>{setConnAccts(MOCK_ACCOUNTS);setBankStage("done");},300);}setBankProg(Math.min(prog,100));},160);
  };
  const skipBank=()=>{setConnAccts([{id:"m1",name:"Chequing",type:"checking",balance:DEMO.balance,institution:"Manual"}]);setBankStage("done");};
  const addBill=()=>setBills([...bills,{name:"",amount:"",date:"1"}]);
  const rmBill=i=>setBills(bills.filter((_,x)=>x!==i));
  const upBill=(i,f,v)=>setBills(bills.map((b,x)=>x===i?{...b,[f]:v}:b));
  const addDebt=()=>setDebts([...debts,{name:"",balance:"",rate:"",min:""}]);
  const rmDebt=i=>setDebts(debts.filter((_,x)=>x!==i));
  const upDebt=(i,f,v)=>setDebts(debts.map((d,x)=>x===i?{...d,[f]:v}:d));
  const finish=()=>onComplete({profile:p,incomes:incomes.filter(i=>i.amount),bills:bills.filter(b=>b.name&&b.amount),debts:debts.filter(d=>d.name&&d.balance),accounts:connAccts,transactions:MOCK_TXN,bankConnected:connAccts.some(a=>a.institution!=="Manual")});

  const banks=(CC[p.country]?.banks||CC.CA.banks);

  const screens=[
    // 0: Welcome
    <div style={{minHeight:"70vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",textAlign:"center",padding:"20px 0",position:"relative"}}>
      {/* Background decorative rings */}
      <div style={{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",width:320,height:320,borderRadius:"50%",border:`1px solid ${C.green}10`,pointerEvents:"none"}}/>
      <div style={{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",width:240,height:240,borderRadius:"50%",border:`1px solid ${C.green}18`,pointerEvents:"none"}}/>
      <div style={{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",width:160,height:160,borderRadius:"50%",border:`1px solid ${C.green}25`,pointerEvents:"none"}}/>
      {/* Ambient glow */}
      <div style={{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-60%)",width:280,height:280,borderRadius:"50%",background:`radial-gradient(circle,${C.green}10 0%,transparent 70%)`,pointerEvents:"none"}}/>

      {/* Logo mark */}
      <div style={{position:"relative",marginBottom:28}}>
        <div style={{width:88,height:88,borderRadius:28,background:"rgba(0,214,143,0.12)",border:"1.5px solid rgba(0,214,143,0.3)",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto",boxShadow:"0 8px 32px #3CB54A22, 0 2px 8px rgba(0,0,0,0.10)"}}><FlourishMark size={52}/></div>
        <div style={{position:"absolute",bottom:-6,right:-6,width:26,height:26,borderRadius:99,background:C.greenBright,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13}}>✦</div>
      </div>

      {/* Wordmark */}
      <div style={{fontFamily:"'Playfair Display',Georgia,serif",fontWeight:900,fontSize:46,color:C.cream,lineHeight:1,letterSpacing:-1.5,marginBottom:8}}>
        Flourish
      </div>
      <div style={{fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:13,color:C.green,letterSpacing:3,textTransform:"uppercase",fontWeight:600,marginBottom:20}}>
        Money coaching that grows with you
      </div>

      {/* Tagline */}
      <div style={{fontFamily:"'Plus Jakarta Sans',sans-serif",color:C.mutedHi,fontSize:15,lineHeight:1.8,maxWidth:300,marginBottom:32}}>
        Know exactly where you stand.<br/>
        <span style={{color:C.cream}}>Before you spend. Not after.</span>
      </div>

      {/* Feature pills */}
      <div style={{display:"flex",flexWrap:"wrap",gap:8,justifyContent:"center",marginBottom:36,maxWidth:340}}>
        {[["","Overdraft warnings"],["","Cash flow forecast"],["","AI coaching"],["","Credit score"],["","Tax credits"],["","Family tools"]].map(([icon,text],i)=>(
          <div key={i} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:99,padding:"7px 14px",color:C.mutedHi,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"flex",alignItems:"center",gap:6,animation:`fadeUp 0.4s ease ${100+i*60}ms both`}}>
            <span style={{fontSize:14}}>{icon}</span>{text}
          </div>
        ))}
      </div>

      {/* CTA */}
      <button onClick={()=>setStep(1)} style={{background:`linear-gradient(135deg,${C.green} 0%,${C.greenBright} 100%)`,color:"#FFFFFF",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:16,padding:"16px 40px",borderRadius:99,border:"none",cursor:"pointer",boxShadow:`0 8px 32px ${C.green}40`,letterSpacing:0.5,transition:"all .2s"}}
        onMouseEnter={e=>{e.currentTarget.style.transform="translateY(-2px)";e.currentTarget.style.boxShadow=`0 12px 40px ${C.green}55`;}}
        onMouseLeave={e=>{e.currentTarget.style.transform="translateY(0)";e.currentTarget.style.boxShadow=`0 8px 32px ${C.green}40`;}}>
        Build My Financial Plan →
      </button>

      {/* Demo mode — required for App Store review */}
      <button onClick={()=>onComplete({
        profile:{name:"Alex",country:"CA",province:"ON",status:"couple",hasKids:true,partnerName:"Jordan",creditScore:718,creditKnown:true},
        incomes:[{id:1,label:"Full-time Job",amount:"2840",freq:"biweekly",type:"employment"},{id:2,label:"Canada Child Benefit",amount:"560",freq:"monthly",type:"ccb"}],
        bills:[{name:"Rent",amount:"1650",date:"1"},{name:"Hydro",amount:"95",date:"11"},{name:"Phone",amount:"65",date:"15"},{name:"Netflix",amount:"18.99",date:"22"}],
        debts:[{name:"TD Visa",balance:"3420",rate:"19.99",min:"68"},{name:"Car Loan",balance:"8200",rate:"6.99",min:"280"}],
        accounts:MOCK_ACCOUNTS,transactions:MOCK_TXN,bankConnected:true,
      })} style={{marginTop:12,background:"none",border:`1px solid ${C.border}`,borderRadius:99,padding:"11px 28px",color:C.muted,fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:13,cursor:"pointer",fontWeight:600,transition:"all .2s"}}
        onMouseEnter={e=>{e.currentTarget.style.borderColor=C.borderHi;e.currentTarget.style.color=C.cream;}}
        onMouseLeave={e=>{e.currentTarget.style.borderColor=C.border;e.currentTarget.style.color=C.muted;}}>
        👀 Try Demo (no account needed)
      </button>

      <div style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",marginTop:14}}>Free to start · Available in 🇨🇦 Canada & 🇺🇸 USA</div>

      {/* PIPEDA consent notice */}
      <div style={{marginTop:20,padding:"12px 16px",background:C.card,borderRadius:14,border:`1px solid ${C.border}`,maxWidth:320,textAlign:"left"}}>
        <div style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.7}}>
          By continuing you agree to our{" "}
          <a href="https://flourishmoney.app/terms" target="_blank" rel="noopener noreferrer" style={{color:C.green,textDecoration:"none",fontWeight:600}}>Terms of Service</a>{" "}and{" "}
          <a href="https://flourishmoney.app/privacy" target="_blank" rel="noopener noreferrer" style={{color:C.green,textDecoration:"none",fontWeight:600}}>Privacy Policy</a>
          , and consent to the collection and processing of your financial data in accordance with PIPEDA (Canada) and applicable US privacy laws.
        </div>
      </div>
    </div>,

    // 1: Profile
    <div>
      <div style={{fontFamily:"'Playfair Display',Georgia,serif",fontWeight:900,fontSize:30,color:C.cream,marginBottom:6,letterSpacing:-0.5}}>About you</div>
      <div style={{color:C.muted,fontSize:14,marginBottom:20,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Just the basics. Everything stays on your device.</div>
      <Inp label="First Name" value={p.name} onChange={v=>setP({...p,name:v})} placeholder="e.g. Amanda"/>
      <Sel label="Country" value={p.country} onChange={v=>setP({...p,country:v,province:v==="CA"?"ON":"CA"})} options={[{value:"CA",label:"🇨🇦 Canada"},{value:"US",label:"🇺🇸 United States"}]}/>
      <Sel label={p.country==="CA"?"Province":"State"} value={p.province} onChange={v=>setP({...p,province:v})}
        options={p.country==="CA"?[{value:"ON",label:"Ontario"},{value:"BC",label:"British Columbia"},{value:"AB",label:"Alberta"},{value:"QC",label:"Quebec"},{value:"MB",label:"Manitoba"},{value:"OTHER",label:"Other"}]:[{value:"CA",label:"California"},{value:"TX",label:"Texas"},{value:"NY",label:"New York"},{value:"FL",label:"Florida"},{value:"OTHER",label:"Other"}]}/>
      <Sel label="Relationship Status" value={p.status} onChange={v=>setP({...p,status:v})} options={[{value:"single",label:"Single"},{value:"couple",label:"Married"},{value:"cohabit",label:"Common Law"}]}/>
      {p.status!=="single"&&<Inp label="Partner's Name (optional)" value={p.partnerName} onChange={v=>setP({...p,partnerName:v})} placeholder="e.g. James"/>}
      <div style={{marginBottom:14}}>
        <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,marginBottom:8,fontWeight:700}}>Do you have kids?</div>
        <div style={{display:"flex",gap:10}}>
          {["Yes","No"].map(opt=><button key={opt} onClick={()=>setP({...p,hasKids:opt==="Yes"})} style={{flex:1,background:(opt==="Yes"?p.hasKids:!p.hasKids)?C.green+"33":C.cardAlt,border:`1px solid ${(opt==="Yes"?p.hasKids:!p.hasKids)?C.green:C.border}`,color:(opt==="Yes"?p.hasKids:!p.hasKids)?C.greenBright:C.muted,borderRadius:12,padding:"12px",cursor:"pointer",fontSize:14,fontWeight:700,fontFamily:"inherit"}}>{opt}</button>)}
        </div>
      </div>
      <Btn label="Continue →" onClick={()=>setStep(2)} disabled={!p.name}/>
    </div>,

    // 2: Income
    <div>
      <div style={{fontFamily:"'Playfair Display',Georgia,serif",fontWeight:900,fontSize:30,color:C.cream,marginBottom:6,letterSpacing:-0.5}}>Your income</div>
      <div style={{color:C.muted,fontSize:14,marginBottom:16,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Add every source of income — employment, freelance, benefits, rental, your partner's pay. We map it all.</div>
      {incomes.map((inc,i)=>(
        <div key={inc.id} style={{background:C.card,borderRadius:16,padding:"16px",border:`1px solid ${C.border}`,marginBottom:12}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
            <div style={{color:C.cream,fontWeight:700,fontSize:14}}>{inc.label||`Income Source ${i+1}`}</div>
            {incomes.length>1&&<button onClick={()=>setIncomes(incomes.filter(x=>x.id!==inc.id))} style={{background:"none",border:"none",color:C.muted,cursor:"pointer",fontSize:18,padding:0}}>×</button>}
          </div>
          <div style={{marginBottom:10}}>
            <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.2,marginBottom:6}}>Label</div>
            <input value={inc.label} onChange={e=>setIncomes(incomes.map(x=>x.id===inc.id?{...x,label:e.target.value}:x))}
              placeholder="e.g. Full-time job, Freelance, Child tax benefit"
              style={{width:"100%",background:C.cardAlt,border:`1px solid ${C.border}`,borderRadius:10,padding:"10px 12px",color:C.cream,fontSize:14,fontFamily:"inherit",boxSizing:"border-box"}}/>
          </div>
          <div style={{display:"flex",gap:10,marginBottom:10}}>
            <div style={{flex:1}}>
              <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.2,marginBottom:6}}>Take-Home Amount</div>
              <div style={{display:"flex",alignItems:"center",background:C.cardAlt,border:`1px solid ${C.border}`,borderRadius:10,overflow:"hidden"}}>
                <span style={{color:C.muted,padding:"0 10px",fontSize:14}}>$</span>
                <input value={inc.amount} onChange={e=>setIncomes(incomes.map(x=>x.id===inc.id?{...x,amount:e.target.value}:x))}
                  type="number" placeholder="0.00"
                  style={{flex:1,background:"none",border:"none",padding:"10px 12px 10px 0",color:C.cream,fontSize:14,fontFamily:"inherit",outline:"none"}}/>
              </div>
            </div>
            <div style={{flex:1}}>
              <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.2,marginBottom:6}}>Frequency</div>
              <select value={inc.freq} onChange={e=>setIncomes(incomes.map(x=>x.id===inc.id?{...x,freq:e.target.value}:x))}
                style={{width:"100%",background:C.cardAlt,border:`1px solid ${C.border}`,borderRadius:10,padding:"10px 12px",color:C.cream,fontSize:13,fontFamily:"inherit"}}>
                <option value="weekly">Weekly</option>
                <option value="biweekly">Every 2 weeks</option>
                <option value="semimonthly">Twice a month</option>
                <option value="monthly">Monthly</option>
                <option value="irregular">Variable</option>
              </select>
            </div>
          </div>
          <div>
            <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.2,marginBottom:6}}>Type</div>
            <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
              {(CC[p.country]?.incomeTypes||CC.CA.incomeTypes).map(([val,lbl])=>(
                <button key={val} onClick={()=>setIncomes(incomes.map(x=>x.id===inc.id?{...x,type:val}:x))}
                  style={{background:inc.type===val?C.green+"22":C.cardAlt,border:`1px solid ${inc.type===val?C.green:C.border}`,color:inc.type===val?C.greenBright:C.muted,borderRadius:99,padding:"5px 10px",fontSize:12,cursor:"pointer",fontFamily:"inherit"}}>{lbl}</button>
              ))}
            </div>
          </div>
        </div>
      ))}
      <button onClick={()=>setIncomes([...incomes,{id:Date.now(),label:"",amount:"",freq:"biweekly",type:"employment"}])}
        style={{width:"100%",background:"none",border:`1px dashed ${C.green}`,borderRadius:14,padding:"12px",color:C.green,fontSize:14,cursor:"pointer",fontFamily:"inherit",marginBottom:14,fontWeight:600}}>
        + Add Another Income Source
      </button>
      <div style={{background:C.goldDim,border:`1px solid ${C.gold}44`,borderRadius:16,padding:"14px 16px",marginBottom:14}}>
        <div style={{color:C.goldBright,fontSize:13,lineHeight:1.6}}>💡 Include every source — even irregular ones. Flourish maps all income vs. bills to warn you <strong>before</strong> you hit zero.</div>
      </div>
      <Btn label="Continue →" onClick={()=>setStep(3)} disabled={!incomes.some(i=>i.amount)}/>
    </div>,

    // 3: Bank Connection
    <div>
      <div style={{fontSize:28,fontWeight:900,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif",letterSpacing:-0.5,marginBottom:6}}>Connect your bank</div>
      <div style={{color:C.muted,fontSize:14,marginBottom:16}}>Live transactions unlock AI coaching and real overdraft warnings.</div>
      {bankStage==="select"&&<>
        <div style={{background:C.tealDim,border:`1px solid ${C.teal}44`,borderRadius:16,padding:"14px 16px",marginBottom:14}}>
          <div style={{color:C.tealBright,fontWeight:700,marginBottom:8}}>🔒 Powered by Plaid</div>
          {[["✅","Read-only. We can never move your money"],["✅","256-bit encryption, bank-level security"],["✅","Live balances + 30 days of transactions"],["✅","Disconnect at any time from settings"]].map(([ico,t],i)=><div key={i} style={{display:"flex",gap:8,padding:"3px 0",color:C.cream,fontSize:13}}><span>{ico}</span><span>{t}</span></div>)}
        </div>
        {banks.map(bank=>(
          <button key={bank.name} onClick={()=>{setSelBank(bank);setBankStage("auth");}} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:"13px 18px",color:C.cream,fontSize:14,fontWeight:600,display:"flex",alignItems:"center",gap:12,cursor:"pointer",fontFamily:"inherit",width:"100%",marginBottom:8,textAlign:"left",transition:"all .2s"}}
            onMouseEnter={e=>{e.currentTarget.style.borderColor=bank.color+"88";e.currentTarget.style.background=bank.color+"11";}} onMouseLeave={e=>{e.currentTarget.style.borderColor=C.border;e.currentTarget.style.background=C.card;}}>
            <div style={{width:36,height:36,borderRadius:10,background:bank.color+"18",display:"flex",alignItems:"center",justifyContent:"center"}}><Icon id="bank" size={17} color={bank.color} strokeWidth={1.5}/></div>
            <span style={{flex:1}}>{bank.name}</span><span style={{color:C.muted,fontSize:12}}>Connect →</span>
          </button>
        ))}
        <div style={{marginTop:6}}><Btn label="Skip — enter manually" onClick={skipBank} outline color={C.muted} small/></div>
      </>}
      {bankStage==="auth"&&<>
        <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:14}}>
          <button onClick={()=>setBankStage("select")} style={{background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,color:C.cream,borderRadius:10,padding:"7px 14px",cursor:"pointer",fontSize:13}}>← Back</button>
          <div><div style={{color:C.cream,fontWeight:700}}>{selBank?.name}</div><div style={{color:C.muted,fontSize:12}}>Secured by Plaid · read-only</div></div>
        </div>
        <div style={{background:C.tealDim,border:`1px solid ${C.teal}44`,borderRadius:14,padding:"12px 16px",marginBottom:14}}>
          <div style={{color:C.tealBright,fontSize:13}}>🔒 You'll be redirected to {selBank?.name} to authenticate securely via Plaid.</div>
        </div>
        <Inp label="Continue to your bank" value={bankCreds.user} onChange={v=>setBankCreds({...bankCreds,user:v})} placeholder="Your username"/>
        <Inp label="Password" value={bankCreds.pass} onChange={v=>setBankCreds({...bankCreds,pass:v})} type="password" placeholder="Your password"/>
        <Btn label="Sign In Securely →" onClick={doAuth} disabled={!bankCreds.user||!bankCreds.pass}/>
      </>}
      {bankStage==="mfa"&&<div style={{textAlign:"center"}}>
        <div style={{marginBottom:14,display:"flex",justifyContent:"center"}}><Icon id="user" size={48} color={C.teal} strokeWidth={1.35}/></div>
        <div style={{fontSize:20,fontWeight:800,color:C.cream,fontFamily:"Georgia,serif",marginBottom:8}}>Verify It's You</div>
        <div style={{color:C.mutedHi,fontSize:14,lineHeight:1.6,marginBottom:20}}>{selBank?.name} sent a code to your phone ending in ••7392</div>
        <input value={mfa} onChange={e=>setMfa(e.target.value.slice(0,6))} placeholder="• • • • • •" maxLength={6}
          style={{width:"100%",background:C.cardAlt,border:`1px solid ${mfa.length===6?C.teal:C.border}`,borderRadius:12,outline:"none",color:C.cream,fontSize:24,padding:"14px",fontFamily:"monospace",textAlign:"center",letterSpacing:8,boxSizing:"border-box",marginBottom:14,transition:"border .2s"}}/>
        <Btn label="Verify & Connect" onClick={doMfa} disabled={mfa.length!==6}/>
      </div>}
      {bankStage==="loading"&&<div style={{textAlign:"center",padding:"40px 0"}}>
        <div style={{marginBottom:14,display:"flex",justifyContent:"center",filter:"drop-shadow(0 0 20px #3CB54A55)"}}><FlourishMark size={54}/></div>
        <div style={{color:C.greenBright,fontWeight:700,fontSize:18,marginBottom:8}}>Importing your data…</div>
        <div style={{color:C.muted,fontSize:13,marginBottom:22}}>Fetching accounts and 30 days of transactions</div>
        <div style={{background:"rgba(255,255,255,0.06)",borderRadius:99,height:6,overflow:"hidden",margin:"0 10px"}}>
          <div style={{width:`${bankProg}%`,height:"100%",background:`linear-gradient(90deg,${C.green},${C.teal})`,borderRadius:99,transition:"width .2s"}}/>
        </div>
        <div style={{color:C.muted,fontSize:12,marginTop:8}}>{Math.round(bankProg)}%</div>
      </div>}
      {bankStage==="done"&&<div>
        <div style={{textAlign:"center",marginBottom:16}}>
          <div style={{marginBottom:10,display:"flex",justifyContent:"center",width:80,height:80,borderRadius:"50%",background:C.green+"22",border:`1px solid ${C.green}44`,margin:"0 auto 10px"}}><Icon id="check" size={40} color={C.greenBright} strokeWidth={1.9}/></div>
          <div style={{fontSize:20,fontWeight:800,color:C.greenBright,fontFamily:"Georgia,serif"}}>Connected!</div>
          <div style={{color:C.mutedHi,fontSize:13,marginTop:4}}>{connAccts.length} accounts · {MOCK_TXN.length} transactions imported</div>
        </div>
        {connAccts.map((a,i)=>(
          <div key={i} style={{background:C.cardAlt,border:`1px solid ${C.green}44`,borderRadius:14,padding:"13px 16px",marginBottom:10,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div><div style={{color:C.cream,fontWeight:700}}>{a.name}</div><div style={{color:C.muted,fontSize:12}}>{a.institution} · {a.type}</div></div>
            <div style={{textAlign:"right"}}>
              <div style={{color:a.balance>=0?C.greenBright:C.red,fontWeight:800}}>${Math.abs(a.balance).toLocaleString()}</div>
              <Chip label={a.balance>=0?"Asset":"Credit"} color={a.balance>=0?C.green:C.red}/>
            </div>
          </div>
        ))}
        <Btn label="Continue →" onClick={()=>setStep(4)}/>
      </div>}
    </div>,

    // 4: Bills
    <div>
      <div style={{fontSize:28,fontWeight:900,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif",letterSpacing:-0.5,marginBottom:6}}>Your bills</div>
      <div style={{color:C.muted,fontSize:14,marginBottom:14}}>Everything that comes out monthly.</div>
      {bills.map((b,i)=>(
        <div key={i} style={{background:C.cardAlt,borderRadius:16,padding:"14px 16px",border:`1px solid ${C.border}`,marginBottom:10}}>
          <div style={{display:"flex",gap:8}}>
            <div style={{flex:1}}>
              <Inp label="Bill Name" value={b.name} onChange={v=>upBill(i,"name",v)} placeholder="Netflix, Hydro, Rent…" sm/>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                <Inp label="Amount $" value={b.amount} onChange={v=>upBill(i,"amount",v)} type="number" sm/>
                <Inp label="Day Due" value={b.date} onChange={v=>upBill(i,"date",v)} type="number" placeholder="1–28" sm/>
              </div>
            </div>
            {bills.length>1&&<button onClick={()=>rmBill(i)} style={{background:C.redDim,border:"none",color:C.red,borderRadius:8,padding:"6px 10px",cursor:"pointer",alignSelf:"flex-start",marginTop:18}}>✕</button>}
          </div>
        </div>
      ))}
      <Btn label="+ Add Bill" onClick={addBill} outline color={C.green} small/>
      <div style={{marginTop:10}}><Btn label="Continue →" onClick={()=>setStep(5)}/></div>
    </div>,

    // 5: Debts
    <div>
      <div style={{fontSize:28,fontWeight:900,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif",letterSpacing:-0.5,marginBottom:6}}>Any debt?</div>
      <div style={{color:C.muted,fontSize:14,marginBottom:20}}>No judgment — we'll build a real payoff plan with a simulator.</div>
      {debts.map((d,i)=>(
        <div key={i} style={{background:C.cardAlt,borderRadius:16,padding:"14px 16px",border:`1px solid ${C.border}`,marginBottom:10}}>
          <div style={{display:"flex",gap:8}}>
            <div style={{flex:1}}>
              <Inp label="Name" value={d.name} onChange={v=>upDebt(i,"name",v)} placeholder="Visa, Car Loan…" sm/>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                <Inp label="Balance $" value={d.balance} onChange={v=>upDebt(i,"balance",v)} type="number" sm/>
                <Inp label="Rate %" value={d.rate} onChange={v=>upDebt(i,"rate",v)} type="number" sm/>
              </div>
              <Inp label="Min Payment $" value={d.min} onChange={v=>upDebt(i,"min",v)} type="number" sm/>
            </div>
            {debts.length>1&&<button onClick={()=>rmDebt(i)} style={{background:C.redDim,border:"none",color:C.red,borderRadius:8,padding:"6px 10px",cursor:"pointer",alignSelf:"flex-start",marginTop:18}}>✕</button>}
          </div>
        </div>
      ))}
      <Btn label="+ Add Debt" onClick={addDebt} outline color={C.green} small/>
      <div style={{marginTop:6}}><Btn label="No debt — skip" onClick={()=>setStep(6)} outline color={C.muted} small/></div>
      <div style={{marginTop:8}}><Btn label="Continue →" onClick={()=>setStep(6)}/></div>
    </div>,

    // 6: Credit Score
    <div>
      <div style={{fontSize:28,fontWeight:900,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif",letterSpacing:-0.5,marginBottom:6}}>Your credit score</div>
      <div style={{color:C.muted,fontSize:14,marginBottom:16}}>Optional — but unlocks personalised coaching on how to improve it.</div>
      <div style={{background:C.tealDim,border:`1px solid ${C.teal}44`,borderRadius:16,padding:"14px 16px",marginBottom:20}}>
        <div style={{color:C.tealBright,fontWeight:700,marginBottom:6}}>🔒 How Flourish uses this</div>
        {[["✅","Soft pull only — never affects your score"],["✅","Personalized tips tied to your real balances"],["✅","Tracks improvement over time"],["❌","Never shared with lenders or third parties"]].map(([ico,t],i)=><div key={i} style={{display:"flex",gap:8,padding:"3px 0",color:ico==="✅"?C.cream:C.muted,fontSize:13}}><span>{ico}</span><span>{t}</span></div>)}
      </div>
      <div style={{marginBottom:14}}>
        <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,marginBottom:8,fontWeight:700}}>Do you know your current score?</div>
        <div style={{display:"flex",gap:10}}>
          {["Yes, I know it","Not sure / skip"].map(opt=><button key={opt} onClick={()=>setP({...p,creditKnown:opt.startsWith("Yes")})} style={{flex:1,background:((opt.startsWith("Yes")?p.creditKnown:!p.creditKnown))?C.teal+"33":C.cardAlt,border:`1px solid ${(opt.startsWith("Yes")?p.creditKnown:!p.creditKnown)?C.teal:C.border}`,color:(opt.startsWith("Yes")?p.creditKnown:!p.creditKnown)?C.tealBright:C.muted,borderRadius:12,padding:"12px 8px",cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:"inherit"}}>{opt}</button>)}
        </div>
      </div>
      {p.creditKnown&&<>
        <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,marginBottom:12,fontWeight:700}}>Drag to your score</div>
        <div style={{background:`linear-gradient(135deg,${C.tealDim} 0%,${C.card} 100%)`,borderRadius:20,padding:"20px 22px",border:`1px solid ${C.teal}44`,marginBottom:16}}>
          <div style={{textAlign:"center",marginBottom:16}}>
            <div style={{fontSize:52,fontWeight:900,fontFamily:"Georgia,serif",color:p.creditScore>=750?C.greenBright:p.creditScore>=700?C.teal:p.creditScore>=650?C.goldBright:p.creditScore>=600?C.orange:C.redBright}}>{p.creditScore}</div>
            <Chip label={p.creditScore>=750?"Excellent 🌟":p.creditScore>=700?"Very Good 👍":p.creditScore>=650?"Good ✓":p.creditScore>=600?"Fair ⚠️":"Needs Work 🔧"} color={p.creditScore>=750?C.green:p.creditScore>=700?C.teal:p.creditScore>=650?C.gold:p.creditScore>=600?C.orange:C.red} size={13}/>
          </div>
          <input type="range" min={300} max={900} step={5} value={p.creditScore} onChange={e=>setP({...p,creditScore:Number(e.target.value)})} style={{width:"100%",accentColor:C.teal,height:6,cursor:"pointer",marginBottom:8}}/>
          <div style={{display:"flex",justifyContent:"space-between"}}><span style={{color:C.red,fontSize:10}}>300 Poor</span><span style={{color:C.gold,fontSize:10}}>650 Good</span><span style={{color:C.greenBright,fontSize:10}}>900 Excellent</span></div>
        </div>
        <div style={{color:C.muted,fontSize:12,textAlign:"center",marginBottom:16}}>Check your score free at Borrowell (CA) or Credit Karma (US/CA) — soft pull only.</div>
      </>}
      {!p.creditKnown&&<div style={{background:C.cardAlt,borderRadius:16,padding:"14px 16px",border:`1px solid ${C.border}`,marginBottom:16}}>
        <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.6}}>No problem. Flourish will estimate your score range from your debt utilization and payment patterns once you're connected. You can add it later in Settings.</div>
      </div>}
      <Btn label="Continue →" onClick={()=>setStep(7)}/>
    </div>,
    <div style={{textAlign:"center"}}>
      <div style={{fontSize:68,marginBottom:16,filter:"drop-shadow(0 0 20px #3CB54A44)"}}>🎉</div>
      <div style={{fontSize:30,fontWeight:900,color:C.greenBright,fontFamily:"Georgia,serif",marginBottom:10}}>You're all set{p.name?`, ${p.name}`:""}!</div>
      <div style={{color:C.mutedHi,fontSize:15,lineHeight:1.7,marginBottom:22}}>Here's what Flourish has ready:</div>
      {[
        ["check",`${connAccts.length} account${connAccts.length!==1?"s":""} connected`],
        ["📅",`${bills.filter(b=>b.name&&b.amount).length} bills in your 2-week forecast`],
        ["📉",debts.filter(d=>d.name&&d.balance).length>0?"Debt payoff simulator built — drag to see your date":"No debt tracked — incredible!"],
        ["💳",p.creditKnown?`Credit score ${p.creditScore} tracked — coaching personalised`:"Credit score estimated from your data"],
        ["🧠",`AI coach ready to analyze your ${MOCK_TXN.length} transactions`],
        ["🔔","Overdraft alerts and coach notifications on"],
        [p.status==="single"?"🧘":"💑",p.status==="single"?"Weekly solo check-in ready":"Couples money meeting ready"],
        [p.hasKids?"👧":"🎓",p.hasKids?"Kids Zone unlocked":"Money School unlocked"],
      ].map(([icon,text],i)=>(
        <div key={i} style={{background:C.cardAlt,borderRadius:12,padding:"12px 16px",display:"flex",gap:10,alignItems:"center",border:`1px solid ${C.borderHi}`,marginBottom:8,textAlign:"left"}}>
          <Icon id="check" size={16} color={C.green} strokeWidth={2.5}/><span style={{color:C.cream,fontSize:14,flex:1}}>{text}</span>
        </div>
      ))}
      <div style={{marginTop:20}}><Btn label="Open My Dashboard →" onClick={finish}/></div>
    </div>,
  ];

  return (
    <div style={{background:C.bg,minHeight:"100vh",display:"flex",justifyContent:"center",fontFamily:"'Helvetica Neue',sans-serif"}}>
      <div style={{width:"100%",maxWidth:430,padding:"28px 20px 60px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:24}}>
          <div style={{display:"flex",alignItems:"center",gap:7}}><FlourishMark size={20}/><span>flourish</span></div>
          {step>0&&step<7&&<button onClick={()=>setStep(s=>s-1)} style={{background:"none",border:"none",color:C.muted,cursor:"pointer",fontSize:14}}>← Back</button>}
        </div>
        {step>0&&step<7&&<div style={{display:"flex",gap:4,marginBottom:28}}>{Array.from({length:7}).map((_,i)=><div key={i} style={{height:3,borderRadius:99,flex:i===step-1?2.5:1,background:i<step?C.green:C.border,transition:"all .4s"}}/>)}</div>}
        {screens[step]}
      </div>
    </div>
  );
}


// ─── NOTIFICATIONS ────────────────────────────────────────────────────────────
const INIT_NOTIFS=[
  {id:1,icon:"💡",title:"Today's safe spend: $47",body:"Based on your balance, bills, and forecast. Stay on track!",read:false,time:"9:01 AM",type:"autopilot"},
  {id:2,icon:"📅",title:"Rent due in 3 days",body:"$1,850 → Landlord. Your balance covers it — you're good.",read:false,time:"8:30 AM",type:"bill"},
  {id:3,icon:"🎯",title:"Debt payoff milestone!",body:"You're 68% through your Visa. At this rate, done by Oct 2025.",read:true,time:"Yesterday",type:"win"},
  {id:4,icon:"📈",title:"Score improved +2 this week",body:"Your Financial Health Score is now 74. Keep it up!",read:true,time:"Yesterday",type:"score"},
  {id:5,icon:"🧠",title:"Spending spike detected",body:"You spent 38% more in the 3 days after payday. Move $200 to savings now?",read:true,time:"Mar 6",type:"behavior"},
  {id:6,icon:"💰",title:"You could save $47/mo",body:"3 subscriptions you haven't used this month total $47. Review them in Spend.",read:true,time:"Mar 5",type:"opportunity"},
];

function Notifications({onClose}){
  const [notifs,setNotifs]=useState(INIT_NOTIFS);
  const unread=notifs.filter(n=>!n.read).length;
  return <div style={{color:C.cream}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
      <div>
        <div style={{fontSize:22,fontWeight:800,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif"}}>Notifications</div>
        {unread>0&&<div style={{color:C.red,fontSize:12,fontWeight:700}}>{unread} unread</div>}
      </div>
      <div style={{display:"flex",gap:8}}>
        {unread>0&&<button onClick={()=>setNotifs(ns=>ns.map(n=>({...n,read:true})))} style={{background:"none",border:`1px solid ${C.border}`,color:C.muted,borderRadius:8,padding:"5px 12px",cursor:"pointer",fontSize:12,fontFamily:"inherit"}}>Mark all read</button>}
        <button onClick={onClose} style={{background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,color:C.muted,borderRadius:8,padding:"5px 12px",cursor:"pointer",fontSize:13}}>← Back</button>
      </div>
    </div>
    {notifs.map(n=>(
      <div key={n.id} onClick={()=>setNotifs(ns=>ns.map(x=>x.id===n.id?{...x,read:true}:x))}
        style={{background:n.read?C.card:n.color+"0F",borderRadius:16,padding:"15px 17px",border:`1px solid ${n.read?C.border:n.color+"44"}`,marginBottom:10,cursor:"pointer",position:"relative"}}>
        <div style={{display:"flex",gap:12,alignItems:"flex-start"}}>
          <div style={{width:40,height:40,borderRadius:12,background:n.color+"18",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}><Icon id={n.icon||"bell"} size={18} color={n.color} strokeWidth={1.5}/></div>
          <div style={{flex:1}}>
            <div style={{display:"flex",justifyContent:"space-between"}}>
              <div style={{color:n.read?C.cream:n.color,fontWeight:700,fontSize:14}}>{n.title}</div>
              <button onClick={e=>{e.stopPropagation();setNotifs(ns=>ns.filter(x=>x.id!==n.id));}} style={{background:"none",border:"none",color:C.muted,cursor:"pointer",padding:"0 0 0 8px",fontSize:14}}>✕</button>
            </div>
            <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.55,marginTop:4}}>{n.body}</div>
            <div style={{color:C.muted,fontSize:11,marginTop:6}}>{n.time}</div>
          </div>
        </div>
        {!n.read&&<div style={{position:"absolute",top:15,right:42,width:8,height:8,borderRadius:"50%",background:n.color}}/>}
      </div>
    ))}
  </div>;
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard({data,setScreen,setShowNotifs,onUpgrade,checkInBonus=0,onCheckIn,onWhatIf,onWrapped}){
  const [mounted,setMounted]=useState(false);
  useEffect(()=>{const t=setTimeout(()=>setMounted(true),60);return()=>clearTimeout(t);},[]);
  // ── SafeSpendEngine → single source of truth for all safe-spend data
  const _ss         = SafeSpendEngine.calculate(data);
  const bal         = _ss.balance;
  const safe        = _ss.safeAmount;
  const overdraft   = _ss.overdraft;
  const soonBills   = _ss.soonBills;
  const soonTotal   = _ss.upcomingBills;
  const today       = new Date().getDate();
  const monthlyIncome = FinancialCalcEngine.cashFlow(data).monthlyIncome;
  const totalDebt=(data.debts||[]).reduce((a,d)=>a+parseFloat(d.balance||0),0);
  const netWorth=bal+DEMO.netWorthAdd-totalDebt;
  const unread=INIT_NOTIFS.filter(n=>!n.read).length;
  const spark=[-4200,-3800,-3100,-2600,-1900,netWorth];
  const sMin=Math.min(...spark),sMax=Math.max(...spark);
  const sN=spark.map(v=>90-((v-sMin)/(sMax-sMin)||0)*70);
  const heroColor=overdraft?C.red:C.green;
  const heroColorBright=overdraft?C.redBright:C.greenBright;

  const anim=(delay=0)=>mounted?{animation:`fadeUp 0.6s cubic-bezier(.16,1,.3,1) ${delay}ms both`}:{opacity:0};
  const {score:healthScore, pillars} = calcHealthScore(data);
  const adjScore = Math.min(100, healthScore + (checkInBonus||0));
  const scoreGrade = adjScore>=80?"Excellent":adjScore>=65?"Good":adjScore>=50?"Fair":adjScore>=35?"Needs Work":"Critical";
  const scoreColor = adjScore>=80?C.greenBright:adjScore>=65?C.tealBright:adjScore>=50?C.goldBright:adjScore>=35?C.orangeBright:C.redBright;
  const scoreBase  = adjScore>=80?C.green:adjScore>=65?C.teal:adjScore>=50?C.gold:adjScore>=35?C.orange:C.red;
  // AI Coach quick insight about score
  const topPillar = pillars.reduce((a,b)=>((b.max-b.pts)>=(a.max-a.pts)?b:a), pillars[0]);
  const scoreInsight = topPillar.label==="Emergency Fund"
    ? `Build your emergency fund to ${Math.ceil(3-(totalBal/(Math.max(1,(data.bills||[]).reduce((s,b)=>s+parseFloat(b.amount||0),0)||2400))))>0?Math.ceil(3-(totalBal/(Math.max(1,(data.bills||[]).reduce((s,b)=>s+parseFloat(b.amount||0),0)||2400)))):0}+ months → score +5`
    : topPillar.label==="Debt Ratio"
    ? `Pay an extra $150/mo on your highest-rate debt → score +4`
    : topPillar.label==="Budget"
    ? `Reduce discretionary spend by 10% this month → score +3`
    : topPillar.label==="Savings"
    ? `Open a TFSA or savings account → score +5`
    : `Improve ${topPillar.label.toLowerCase()} to boost your score`;

  return <div style={{display:"flex",flexDirection:"column",gap:16}}>

    {/* ── ENGINE STATUS: single-line, minimal ─────────────── */}
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:2}}>
      <div style={{display:"flex",alignItems:"center",gap:6}}>
        <div style={{width:6,height:6,borderRadius:"50%",background:C.green,boxShadow:`0 0 8px ${C.green}`,animation:"pulse 2.5s ease-in-out infinite"}}/>
        <span style={{color:C.muted,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,letterSpacing:0.3}}>6 engines live · Adaptive Autopilot</span>
      </div>
      <span style={{color:C.muted,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{new Date().toLocaleDateString("en-CA",{weekday:"short",month:"short",day:"numeric"})}</span>
    </div>

    {/* Header */}
    <div style={{...anim(0),display:"flex",justifyContent:"space-between",alignItems:"flex-start",paddingTop:4}}>
      <div>
  
        <div style={{fontSize:28,fontWeight:900,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif",lineHeight:1.15,marginTop:2}}>
          Hey {data.profile.name} 👋
        </div>
      </div>
      <button onClick={()=>setShowNotifs(true)} style={{position:"relative",background:unread>0?C.red+"22":C.card,border:`1px solid ${unread>0?C.red+"66":C.border}`,borderRadius:14,width:44,height:44,cursor:"pointer",color:C.cream,fontSize:19,display:"flex",alignItems:"center",justifyContent:"center",transition:"all .2s",flexShrink:0}}>
        <Icon id="bell" size={20} color={C.cream} strokeWidth={1.5}/>
        {unread>0&&<>
          <div style={{position:"absolute",top:-3,right:-3,width:16,height:16,borderRadius:"50%",background:C.red,color:"#fff",fontSize:8,fontWeight:800,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{unread}</div>
          <div style={{position:"absolute",top:-3,right:-3,width:16,height:16,borderRadius:"50%",background:C.red,animation:"ringPulse 1.5s ease-out infinite"}}/>
        </>}
      </button>
    </div>

    {/* HERO — Safe to Spend */}
    <div style={{...anim(80),cursor:"pointer",position:"relative",overflow:"hidden",borderRadius:28,
      background:overdraft
        ?"linear-gradient(155deg,#180610 0%,#200810 45%,#0C050A 100%)"
        :"linear-gradient(155deg,#051509 0%,#081E0D 45%,#060A0E 100%)",
      border:`1px solid ${heroColor}22`,
      boxShadow:`0 16px 72px rgba(0,0,0,0.8), 0 0 0 1px rgba(255,255,255,0.03), inset 0 1px 0 ${heroColor}18`,
      animation:mounted?"fadeUp 0.6s cubic-bezier(.16,1,.3,1) 80ms both":"none"
    }} onClick={()=>setScreen("plan")}>
      {/* Large ambient orb */}
      <div style={{position:"absolute",top:-80,right:-80,width:320,height:320,borderRadius:"50%",background:`radial-gradient(circle,${heroColor}12 0%,transparent 65%)`,pointerEvents:"none"}}/>
      <div style={{position:"absolute",bottom:-60,left:-60,width:240,height:240,borderRadius:"50%",background:`radial-gradient(circle,${heroColor}07 0%,transparent 70%)`,pointerEvents:"none"}}/>
      {/* Fine dot grid */}
      <div style={{position:"absolute",inset:0,backgroundImage:`radial-gradient(circle,${heroColor}18 1px,transparent 1px)`,backgroundSize:"28px 28px",pointerEvents:"none",opacity:0.4}}/>
      <div style={{position:"relative",padding:"26px 24px 22px"}}>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
          <div style={{width:6,height:6,borderRadius:"50%",background:overdraft?C.redBright:C.greenBright,boxShadow:`0 0 8px ${heroColor}`}}/>
          <div style={{color:overdraft?C.redBright+"99":C.greenBright+"99",fontSize:10,textTransform:"uppercase",letterSpacing:2.5,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>Today's Safe Limit</div>
        </div>
        <div style={{fontFamily:"'Playfair Display',Georgia,serif",fontWeight:900,lineHeight:0.9,marginBottom:14}}>
          <span style={{fontSize:28,color:heroColorBright+"88",verticalAlign:"top",marginTop:8,display:"inline-block"}}>$</span>
          <span style={{fontSize:76,color:heroColorBright,letterSpacing:-3,animation:mounted?"countUp 0.6s ease 300ms both":"none"}}>
            <CountUp to={safe} decimals={2} dur={1200}/>
          </span>
        </div>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div style={{color:C.muted,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>
            Balance <span style={{color:C.mutedHi}}>${bal.toFixed(2)}</span>
            <span style={{margin:"0 6px",opacity:0.4}}>·</span>
            bills deducted
          </div>
          <div style={{display:"flex",gap:8,alignItems:"center"}}>
          {onWhatIf&&<button onClick={e=>{e.stopPropagation();onWhatIf();}} style={{background:C.teal+"22",border:`1px solid ${C.teal}44`,color:C.tealBright,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,fontSize:10,padding:"5px 10px",borderRadius:99,cursor:"pointer"}}>What if? →</button>}
          <div style={{color:heroColor,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>Forecast →</div>
        </div>
        </div>
        {overdraft
          ?<div style={{marginTop:12,padding:"10px 14px",background:C.red+"18",borderRadius:14,border:`1px solid ${C.red}33`,color:C.cream,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>
            <strong style={{color:C.redBright}}>Overdraft risk</strong> — bills due exceed your balance. Hold all non-essential spending.
          </div>
          :soonBills.length>0&&<div style={{marginTop:10,padding:"8px 12px",background:C.gold+"12",borderRadius:12,border:`1px solid ${C.gold}22`,color:C.muted,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>
            ⚠️ {soonBills[0].name} <span style={{color:C.cream}}>${soonBills[0].amount}</span> due in {parseInt(soonBills[0].date)-today} days
          </div>}
      </div>
    </div>

    {/* ── TIME MACHINE — forecast + what-if overlay ──────────── */}
    <div style={{...anim(220),background:C.card,borderRadius:22,padding:"18px 18px 14px",border:`1px solid ${C.border}`,backdropFilter:"blur(12px)",boxShadow:"0 4px 28px rgba(0,0,0,0.45)"}}>
      <TimeMachine data={data}/>
    </div>

    {/* ── AUTOPILOT — Daily Money Plan ─────────────────────── */}
    <div style={{...anim(180)}}>
      <AutopilotCard data={data} setScreen={setScreen}/>
    </div>

    {/* ── DECISION ENGINE ──────────────────────────────────── */}
    <div style={{...anim(195)}}>
      <DecisionEngine data={data} safe={safe} bal={bal} monthlyIncome={monthlyIncome} soonBills={soonBills} todayDate={today} setScreen={setScreen}/>
    </div>

    {/* ── OPPORTUNITY DETECTION ────────────────────────────── */}
    <div style={{...anim(205)}}>
      <OpportunityDetector data={data} setScreen={setScreen}/>
    </div>

    {/* ── FINANCIAL HEALTH SCORE ────────────────────────────────────── */}
    <div style={{...anim(260),background:C.card,borderRadius:24,padding:"20px 20px 18px",border:`1px solid ${scoreBase}22`,position:"relative",overflow:"hidden",backdropFilter:"blur(12px)",boxShadow:`0 8px 40px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.03)`}}>
      <div style={{position:"absolute",inset:0,background:`radial-gradient(ellipse at 0% 50%,${scoreBase}15 0%,transparent 65%)`,pointerEvents:"none"}}/>
      <div style={{position:"absolute",top:-50,right:-50,width:160,height:160,borderRadius:"50%",background:`radial-gradient(circle,${scoreBase}10 0%,transparent 70%)`,pointerEvents:"none"}}/>
      <div style={{position:"relative",display:"flex",alignItems:"center",gap:18}}>
        <HealthScoreRing score={adjScore} size={108} strokeW={10} bonus={checkInBonus}/>
        <div style={{flex:1,minWidth:0}}>
          <div style={{color:C.muted,fontSize:9,textTransform:"uppercase",letterSpacing:1.8,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,marginBottom:4}}>Financial Health Score</div>
          <div style={{display:"flex",alignItems:"baseline",gap:6,marginBottom:6}}>
            <span style={{fontSize:36,fontWeight:900,color:scoreColor,fontFamily:"'Playfair Display',serif",lineHeight:1,letterSpacing:-1}}>{adjScore}</span>
            <span style={{color:C.muted,fontSize:14,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>/100</span>
          </div>
          <div style={{background:scoreBase+"14",borderRadius:10,padding:"8px 10px",marginBottom:8}}>
            <div style={{color:scoreBase,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.55}}>{scoreInsight}</div>
          </div>
          <div style={{display:"flex",gap:8}}>
            {onCheckIn&&<button onClick={onCheckIn} style={{flex:1,background:`linear-gradient(135deg,${C.green},${C.greenBright})`,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,fontSize:11,padding:"8px 10px",borderRadius:99,border:"none",cursor:"pointer",whiteSpace:"nowrap"}}>Weekly Check-In ✦</button>}
            <button onClick={()=>setScreen("coach")} style={{flex:1,background:"none",border:`1px solid ${scoreBase}44`,color:scoreBase,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,fontSize:11,padding:"8px 10px",borderRadius:99,cursor:"pointer",whiteSpace:"nowrap"}}>Ask AI Coach →</button>
          </div>
        </div>
      </div>
      {/* Pillar bars */}
      <div style={{marginTop:14,display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"8px 12px"}}>
        {pillars.map(p=>{
          const pct = p.pts / p.max;
          const pc = pct>=0.75?C.green:pct>=0.5?C.teal:pct>=0.25?C.gold:C.red;
          return <div key={p.label}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
              <span style={{color:C.muted,fontSize:8,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,textTransform:"uppercase",letterSpacing:0.5}}>{p.label}</span>
              <span style={{color:pc,fontSize:8,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700}}>{p.pts}/{p.max}</span>
            </div>
            <div style={{height:4,borderRadius:99,background:C.border,overflow:"hidden"}}>
              <div style={{height:"100%",width:`${pct*100}%`,background:pc,borderRadius:99,transition:"width 1s ease"}}/>
            </div>
          </div>;
        })}
      </div>
    </div>

    {/* Demo mode notice when using sample data */}
    {(!data.transactions||data.transactions.length===0)&&(
      <div style={{...anim(90),background:`${C.gold}10`,border:`1px solid ${C.gold}25`,borderRadius:16,padding:"11px 16px",display:"flex",gap:10,alignItems:"center"}}>
        <span style={{fontSize:16,flexShrink:0}}>🔗</span>
        <div style={{flex:1}}>
          <div style={{color:C.goldBright,fontWeight:700,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Sample data shown</div>
          <div style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",marginTop:1}}>Connect your bank in Settings to see real numbers</div>
        </div>
      </div>
    )}
    {/* Stats row */}
    <div style={{...anim(160),display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}}>
      {(()=>{
        const invAccts=(data.accounts||[]).filter(a=>a.type==="investment");
        const totalInv=invAccts.reduce((s,a)=>s+(a.balance||0),0);
        return totalInv>0?[
          {label:"Due Soon",value:`$${soonTotal.toFixed(0)}`,sub:"next 10 days",color:C.gold,icon:"calendar"},
          {label:"Invested",value:`$${(totalInv/1000).toFixed(1)}k`,sub:`${invAccts.length} acct${invAccts.length>1?"s":""}`,color:C.purple,icon:"chartUp"},
          {label:"Net Worth",value:`${(netWorth+totalInv)>=0?"+":""}$${(Math.abs(netWorth+totalInv)/1000).toFixed(1)}k`,sub:"incl. investments",color:C.teal,icon:"💎"},
        ]:[
          {label:"Due Soon",value:`$${soonTotal.toFixed(0)}`,sub:"next 10 days",color:C.gold,icon:"calendar"},
          {label:"Total Debt",value:totalDebt>0?`$${(totalDebt/1000).toFixed(1)}k`:"None!",sub:`${(data.debts||[]).length} accounts`,color:C.red,icon:"trendUp"},
          {label:"Net Worth",value:`${netWorth>=0?"+":""}$${(Math.abs(netWorth)/1000).toFixed(1)}k`,sub:"↑ trending",color:C.teal,icon:"chartUp"},
        ];
      })().map((s,i)=>(
        <div key={i} style={{background:C.card,borderRadius:18,padding:"16px 12px",textAlign:"center",border:`1px solid ${C.border}`,position:"relative",overflow:"hidden"}}>
          <div style={{position:"absolute",inset:0,background:`radial-gradient(ellipse at 50% 0%,${s.color}08 0%,transparent 70%)`,pointerEvents:"none"}}/>
          <div style={{marginBottom:6,display:"flex",justifyContent:"center"}}><Icon id={s.icon||"card"} size={18} color={C.mutedHi} strokeWidth={1.5}/></div>
          <div style={{color:C.muted,fontSize:8,textTransform:"uppercase",letterSpacing:1.4,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>{s.label}</div>
          <div style={{fontSize:20,fontWeight:800,color:s.color,fontFamily:"'Playfair Display',Georgia,serif",lineHeight:1.2,marginTop:3}}>{s.value}</div>
          <div style={{color:C.muted,fontSize:9,marginTop:2,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{s.sub}</div>
        </div>
      ))}
    </div>

    {/* Upgrade nudge for free users */}
    {!data.isPremium&&onUpgrade&&<div onClick={onUpgrade} style={{...anim(200),background:`linear-gradient(135deg,${C.purple}18,${C.surface})`,borderRadius:18,padding:"14px 18px",border:`1px solid ${C.purple}33`,display:"flex",alignItems:"center",justifyContent:"space-between",cursor:"pointer",marginBottom:4}} onMouseEnter={e=>e.currentTarget.style.borderColor=C.purple+"66"} onMouseLeave={e=>e.currentTarget.style.borderColor=C.purple+"33"}>
      <div style={{display:"flex",alignItems:"center",gap:12}}>
        <div style={{fontSize:24}}>✨</div>
        <div>
          <div style={{color:C.purpleBright,fontWeight:700,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Unlock Flourish Plus</div>
          <div style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>AI Coach · Tax Tips · Credit Coaching</div>
        </div>
      </div>
      <div style={{color:C.purple,fontSize:13,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Try Free →</div>
    </div>}

    {/* Credit score tile */}
    {data.profile?.creditKnown&&(()=>{
      const score=data.profile.creditScore||720;
      const sc=score>=750?C.greenBright:score>=700?C.tealBright:score>=650?C.goldBright:score>=600?C.orangeBright:C.redBright;
      const scBase=score>=750?C.green:score>=700?C.teal:score>=650?C.gold:score>=600?C.orange:C.red;
      const label=score>=750?"Excellent":score>=700?"Good":score>=650?"Fair":score>=600?"Poor":"Very Poor";
      return <div style={{...anim(220)}} onClick={()=>setScreen("goals")}>
        <div style={{background:C.card,borderRadius:20,padding:"16px 20px",border:`1px solid ${scBase}22`,cursor:"pointer",display:"flex",alignItems:"center",gap:16,position:"relative",overflow:"hidden"}}>
          <div style={{position:"absolute",inset:0,background:`radial-gradient(ellipse at 0% 50%,${scBase}10 0%,transparent 60%)`,pointerEvents:"none"}}/>
          <div style={{width:52,height:52,borderRadius:16,background:scBase+"18",border:`1.5px solid ${scBase}33`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <span style={{fontSize:22,fontWeight:900,color:sc,fontFamily:"'Playfair Display',serif"}}>{score>=750?"A":score>=700?"B":score>=650?"C":"D"}</span>
          </div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{color:C.muted,fontSize:9,textTransform:"uppercase",letterSpacing:1.4,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>Credit Score</div>
            <div style={{display:"flex",alignItems:"baseline",gap:6,marginTop:2}}>
              <span style={{fontSize:28,fontWeight:900,color:sc,fontFamily:"'Playfair Display',serif",letterSpacing:-1}}>{score}</span>
              <span style={{fontSize:13,color:scBase,fontWeight:600,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{label}</span>
            </div>
          </div>
          <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4}}>
            <span style={{color:scBase,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>Coach →</span>
            <div style={{background:C.bg,borderRadius:99,width:5,height:40,overflow:"hidden"}}>
              <div style={{height:`${Math.round((score-300)/6)}%`,background:`linear-gradient(to top,${sc},${scBase})`,borderRadius:99,transition:"height 1s"}}/>
            </div>
          </div>
        </div>
      </div>;
    })()}

    {/* Net worth sparkline */}
    <div style={{...anim(260)}}>
      <div style={{background:C.card,borderRadius:20,padding:"18px 20px",border:`1px solid ${C.border}`}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
          <div>
            <div style={{color:C.muted,fontSize:9,textTransform:"uppercase",letterSpacing:1.4,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>Net Worth Trend</div>
            <div style={{color:C.tealBright,fontWeight:900,fontSize:24,fontFamily:"'Playfair Display',Georgia,serif",marginTop:3}}>{netWorth>=0?"+":""}<span style={{fontSize:14,verticalAlign:"super",marginRight:1}}>$</span><CountUp to={Math.abs(netWorth)} decimals={0}/></div>
          </div>
          <div style={{background:C.teal+"18",border:`1px solid ${C.teal}33`,borderRadius:99,padding:"4px 10px",color:C.tealBright,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>↑ +$2,300 this month</div>
        </div>
        <svg width="100%" height="56" viewBox={`0 0 ${spark.length*50} 100`} preserveAspectRatio="none" style={{display:"block",overflow:"visible"}}>
          <defs>
            <linearGradient id="sg" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={C.teal} stopOpacity="0.4"/>
              <stop offset="100%" stopColor={C.teal} stopOpacity="0"/>
            </linearGradient>
            <filter id="gf"><feGaussianBlur stdDeviation="1.5"/></filter>
          </defs>
          <polyline points={sN.map((y,i)=>`${i*50},${y}`).join(" ")} fill="none" stroke={C.teal+"40"} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" filter="url(#gf)"/>
          <polyline points={sN.map((y,i)=>`${i*50},${y}`).join(" ")} fill="none" stroke={C.teal} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          <polygon points={`0,100 ${sN.map((y,i)=>`${i*50},${y}`).join(" ")} ${(spark.length-1)*50},100`} fill="url(#sg)"/>
          {sN.map((y,i)=><circle key={i} cx={i*50} cy={y} r={i===sN.length-1?5:2.5} fill={i===sN.length-1?C.tealBright:C.teal} style={i===sN.length-1?{filter:`drop-shadow(0 0 4px ${C.teal})`}:{}}/>)}
        </svg>
        <div style={{display:"flex",justifyContent:"space-between",marginTop:6}}>
          {["Oct","Nov","Dec","Jan","Feb","Now"].map((m,i)=><span key={i} style={{color:i===5?C.teal:C.muted,fontSize:9,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:i===5?700:400}}>{m}</span>)}
        </div>
      </div>
    </div>

    {/* Urgent alert */}
    {INIT_NOTIFS.filter(n=>!n.read&&n.type==="urgent").slice(0,1).map(n=>(
      <div key={n.id} style={{...anim(300),cursor:"pointer",background:`linear-gradient(135deg,${C.red}18 0%,${C.redDim} 100%)`,borderRadius:18,padding:"14px 16px",border:`1px solid ${C.red}33`,display:"flex",gap:12,alignItems:"flex-start"}} onClick={()=>setShowNotifs(true)}>
        <span style={{fontSize:22,flexShrink:0}}>{n.icon}</span>
        <div style={{flex:1}}>
          <div style={{color:C.redBright,fontWeight:700,fontSize:13,marginBottom:3,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{n.title}</div>
          <div style={{color:C.cream,fontSize:13,lineHeight:1.5,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{n.body}</div>
        </div>
        <span style={{color:C.red,fontSize:16,flexShrink:0}}>→</span>
      </div>
    ))}

    {/* Quick nav */}
    <div style={{...anim(340),display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
      {[
        {label:"2-Week Forecast",icon:"calendar",screen:"plan",color:C.teal,sub:"Cash flow ahead"},
        {label:"Debt Simulator",icon:"trendUp",screen:"goals",color:C.purple,sub:"Drag to freedom date"},
        {label:"AI Coach",icon:"sparkles",screen:"coach",color:C.green,sub:"Ask anything about your money",hero:true},
        {label:data.profile.status==="single"?"Solo Check-In":"Money Meeting",icon:data.profile.status==="single"?"🧘":"💑",screen:"family",color:C.pink,sub:"Weekly ritual"},
      ].concat(onWhatIf?[{label:"What If?",icon:"sparkles",screen:null,color:C.teal,sub:"Simulate any decision",whatIf:true}]:[]
      ).map((a,i)=>(
        <button key={a.label} onClick={()=>a.whatIf?onWhatIf():setScreen(a.screen)}
          style={{background:a.hero?`linear-gradient(135deg,${C.green}18,${C.greenDim})`:C.card,border:`${a.hero?"1.5px":"1px"} solid ${a.hero?C.green+"55":a.color+"22"}`,borderRadius:20,padding:"18px 16px",cursor:"pointer",textAlign:"left",fontFamily:"inherit",transition:"all .25s",position:"relative",overflow:"hidden"}}
          onMouseEnter={e=>{e.currentTarget.style.borderColor=a.color+"66";e.currentTarget.style.background=a.hero?`linear-gradient(135deg,${C.green}28,${C.greenDim})`:a.color+"0E";e.currentTarget.style.transform="translateY(-2px)";}}
          onMouseLeave={e=>{e.currentTarget.style.borderColor=a.hero?C.green+"55":a.color+"22";e.currentTarget.style.background=a.hero?`linear-gradient(135deg,${C.green}18,${C.greenDim})`:C.card;e.currentTarget.style.transform="translateY(0)";}}>
          <div style={{position:"absolute",top:-20,right:-20,width:70,height:70,borderRadius:"50%",background:`radial-gradient(circle,${a.color}12 0%,transparent 70%)`,pointerEvents:"none"}}/>
          {a.hero&&<div style={{position:"absolute",top:10,right:12,background:C.green,color:"#fff",fontSize:8,fontWeight:800,fontFamily:"'Plus Jakarta Sans',sans-serif",padding:"3px 7px",borderRadius:99,letterSpacing:0.5}}>✦ AI</div>}
          <div style={{marginBottom:8,fontSize:22}}>{typeof a.icon==="string"&&a.icon.length<=2?a.icon:<Icon id={typeof a.icon==="string"&&a.icon.length>2?a.icon:"sparkles"} size={22} color={a.hero?C.green:a.color} strokeWidth={1.6}/>}</div>
          <div style={{color:a.hero?C.green:a.color,fontWeight:700,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:3}}>{a.label}</div>
          <div style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{a.sub}</div>
        </button>
      ))}
    </div>
  </div>;
}


// ─── PLAN AHEAD ───────────────────────────────────────────────────────────────
function PlanAhead({data}){
  const [range,setRange]=useState(14);
  const [connected,setConnected]=useState(["Netflix","Hydro One"]);
  const [showConnect,setShowConnect]=useState(false);
  const [connecting,setConnecting]=useState(null);
  const PROVIDERS=[
    {name:"Netflix",icon:"🎬",color:"#E50914",amount:"18.99"},{name:"Spotify",icon:"🎵",color:C.green,amount:"11.99"},
    {name:"Amazon Prime",icon:"📦",color:"#FF9900",amount:"9.99"},{name:"Hydro One",icon:"⚡",color:C.gold,amount:"124.00"},
    {name:"Bell / Rogers",icon:"📱",color:C.blue,amount:"65.00"},{name:"Disney+",icon:"✨",color:"#113CCF",amount:"13.99"},
    {name:"Apple iCloud",icon:"☁️",color:"#888",amount:"3.99"},{name:"Planet Fitness",icon:"💪",color:C.purple,amount:"25.00"},
    {name:"Enbridge Gas",icon:"🔥",color:C.orange,amount:"89.00"},
  ];
  const doConnect=p=>{setConnecting(p.name);setTimeout(()=>{setConnected(c=>[...c,p.name]);setConnecting(null);},1400);};
  // ── ForecastEngine powers the plan ahead view
  const { forecast: _forecast, willGoNegative: willGoNeg, overdraftRisk, lowBalanceWarnings } = ForecastEngine.generate(data, Math.max(range, 30));
  const days = _forecast.slice(0, range).map(f => ({
    d: f.date, dayNum: f.date.getDate(),
    isPayday: f.isPayday, bills: f.bills,
    income: f.income, balance: f.balance, idx: f.day
  }));
  const { balance: bal } = SafeSpendEngine.calculate(data);
  const income = FinancialCalcEngine.cashFlow(data).monthlyIncome / 2; // bi-monthly
  const minBalance = Math.min(...days.map(d => d.balance));

  const hasBills = (data.bills||[]).length > 0;
  return <div style={{display:"flex",flexDirection:"column",gap:14}}>
    {!hasBills&&<EmptyState icon="📅" title="No bills tracked yet" body="Add your recurring bills in Settings to see a personalized cash-flow forecast." action={null} color={C.teal}/>}
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
      <div><div style={{fontSize:22,fontWeight:800,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif"}}>2-Week Forecast</div><div style={{color:C.muted,fontSize:12,marginTop:2}}>Your financial crystal ball</div></div>
      <div style={{display:"flex",gap:6}}>{[7,14].map(r=><button key={r} onClick={()=>setRange(r)} style={{background:range===r?C.teal+"33":C.cardAlt,border:`1px solid ${range===r?C.teal:C.border}`,color:range===r?C.teal:C.muted,borderRadius:99,padding:"5px 14px",cursor:"pointer",fontSize:12,fontWeight:700,fontFamily:"inherit"}}>{r}d</button>)}</div>
    </div>
    <div style={{background:C.cardAlt,borderRadius:12,padding:"9px 13px",border:`1px solid ${C.border}`,display:"flex",gap:7,alignItems:"flex-start"}}>
      <span style={{fontSize:12,flexShrink:0,marginTop:1}}>ℹ️</span>
      <span style={{color:C.muted,fontSize:10.5,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.6}}>Forecast is based on your income schedule and bill data. Actual balances may differ. Not financial advice.</span>
    </div>
    {willGoNeg&&<div style={{background:C.redDim,borderRadius:16,padding:"14px 16px",border:`1px solid ${C.red}55`}}>
      <div style={{color:C.redBright,fontWeight:800,marginBottom:4}}>Projected Overdraft</div>
      <div style={{color:C.cream,fontSize:13,lineHeight:1.5}}>Balance hits <strong style={{color:C.red}}>${minBalance.toFixed(2)}</strong> before your next deposit. Reduce spending now.</div>
    </div>}
    <Card style={{border:`1px solid ${C.teal}33`}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:connected.length>0?10:0}}>
        <div><div style={{color:C.teal,fontWeight:700,fontSize:14}}>🔌 Connected Providers</div><div style={{color:C.muted,fontSize:11}}>{connected.length} live · auto-update</div></div>
        <button onClick={()=>setShowConnect(s=>!s)} style={{background:C.teal+"22",border:`1px solid ${C.teal}44`,color:C.teal,borderRadius:99,padding:"5px 14px",cursor:"pointer",fontSize:12,fontWeight:700,fontFamily:"inherit"}}>{showConnect?"Done":"+ Connect"}</button>
      </div>
      {connected.length>0&&<div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:showConnect?10:0}}>
        {connected.map(name=>{const p=PROVIDERS.find(x=>x.name===name);return p?<div key={name} style={{background:(p.color||C.teal)+"22",border:`1px solid ${(p.color||C.teal)}44`,borderRadius:99,padding:"3px 10px",display:"flex",alignItems:"center",gap:5}}><span style={{fontSize:12}}>{p.icon}</span><span style={{color:C.cream,fontSize:11,fontWeight:600}}>{name}</span><span style={{color:C.green,fontSize:10}}>✓</span></div>:null;})}
      </div>}
      {showConnect&&<div style={{display:"flex",flexDirection:"column",gap:6,marginTop:4}}>
        {PROVIDERS.filter(p=>!connected.includes(p.name)).map(p=>(
          <button key={p.name} onClick={()=>doConnect(p)} disabled={connecting===p.name} style={{background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,borderRadius:12,padding:"10px 14px",color:C.cream,fontSize:13,fontWeight:600,display:"flex",alignItems:"center",gap:10,cursor:"pointer",fontFamily:"inherit",transition:"all .2s"}}
            onMouseEnter={e=>e.currentTarget.style.borderColor=p.color||C.teal} onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
            <span style={{fontSize:16}}>{p.icon}</span><span style={{flex:1}}>{p.name}</span><span style={{color:C.muted,fontSize:11}}>${p.amount}/mo</span>
            <span style={{color:connecting===p.name?C.gold:C.teal,fontSize:11}}>{connecting===p.name?"…":"Connect"}</span>
          </button>
        ))}
      </div>}
    </Card>
    <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,fontWeight:700}}>Day-by-Day Cash Flow</div>
    {days.filter((d,i)=>i===0||d.income>0||d.bills.length>0).map((day,i)=>{
      const isToday=day.idx===0,neg=day.balance<0,low=day.balance<150&&day.balance>=0;
      return <div key={i} style={{background:isToday?C.greenDim:neg?C.redDim:C.card,borderRadius:16,padding:"14px 16px",border:`1px solid ${isToday?C.green+"55":neg?C.red+"55":low?C.gold+"44":C.border}`}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
          <div>
            <div style={{color:isToday?C.greenBright:C.mutedHi,fontWeight:isToday?700:400,fontSize:13}}>{isToday?"Today":day.d.toLocaleDateString("en",{weekday:"short",month:"short",day:"numeric"})}</div>
            {day.income>0&&<div style={{color:C.green,fontWeight:700,fontSize:14,marginTop:3}}>+${day.income.toLocaleString()} deposited</div>}
            {day.bills.map((b,j)=><div key={j} style={{color:C.red,fontSize:13,marginTop:3}}>📤 {b.name}: –${parseFloat(b.amount).toFixed(2)}</div>)}
            {isToday&&!day.income&&!day.bills.length&&<div style={{color:C.muted,fontSize:12,marginTop:2}}>No scheduled activity</div>}
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{fontSize:18,fontWeight:800,fontFamily:"Georgia,serif",color:neg?C.redBright:low?C.goldBright:C.greenBright}}>${day.balance.toFixed(2)}</div>
            <div style={{color:C.muted,fontSize:10}}>balance</div>
          </div>
        </div>
        <Bar v={Math.max(0,day.balance)} max={bal+income} color={neg?C.red:low?C.gold:C.green} h={5}/>
        {neg&&<div style={{marginTop:8,color:C.redBright,fontSize:12,fontWeight:600}}>⚠️ Projected overdraft — NSF fees cost $45–48. Move money now.</div>}
        {low&&!neg&&<div style={{marginTop:8,color:C.goldBright,fontSize:12}}>Getting low — hold non-essential spending until next deposit.</div>}
      </div>;
    })}
  </div>;
}

// ─── SPEND ────────────────────────────────────────────────────────────────────
function SpendScreen({data}){
  const [tab,setTab]=useState("txn");
  const [catFilter,setCatFilter]=useState("All");
  const [dismissed,setDismissed]=useState([]);
  const isDemo=!(data.transactions&&data.transactions.length>0);
  const txns=isDemo?MOCK_TXN:data.transactions;
  const stats=computeStats(txns);
  const cats=["All",...Array.from(new Set(txns.map(t=>t.cat)))];
  const filtered=catFilter==="All"?txns:txns.filter(t=>t.cat===catFilter);
  const totalSpent=txns.filter(t=>t.amount>0).reduce((a,t)=>a+t.amount,0);
  const totalIn=txns.filter(t=>t.amount<0).reduce((a,t)=>a+Math.abs(t.amount),0);

  const cuts=[
    {id:1,icon:"☕",title:"Coffee is adding up",body:`${stats.coffeeCount} coffee runs this month totalling $${stats.coffee.toFixed(2)}. That's $${(stats.coffee*12).toFixed(0)}/year. Making coffee at home 4 days a week cuts this by 60%.`,saving:`$${Math.round(stats.coffee*0.6)}/mo`,effort:"Low",color:C.orange},
    {id:2,icon:"🍕",title:"Food delivery every week",body:`$${stats.delivery.toFixed(2)} on delivery this month. One fewer order per week saves $40–60/month reliably. Your wallet will notice in 30 days.`,saving:"$50/mo",effort:"Low",color:C.orange},
    {id:3,icon:"📦",title:"Amazon impulse purchases",body:"3 Amazon orders this month. Try the 48-hour rule: add to cart, wait 2 days. Most impulse buys get removed without regret.",saving:"$40–70/mo",effort:"Low",color:C.pink},
    {id:4,icon:"calendar",title:"Subscriptions creeping up",body:`$${stats.subs.toFixed(2)}/mo in subscriptions. Go through each one — did you use it last month? Most households find 1–2 to cancel painlessly.`,saving:"$15–35/mo",effort:"Low",color:C.purple},
    {id:5,icon:"chartUp",title:`${stats.busiest} is your expensive day`,body:`You spend significantly more on ${stats.busiest}s than any other day. Knowing this is half the battle — awareness alone cuts it 20–30%.`,saving:"$30–60/mo",effort:"Very Low",color:C.blue},
  ].filter(s=>!dismissed.includes(s.id));

  return <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
      <div><div style={{fontSize:22,fontWeight:800,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif"}}>Spending</div><div style={{color:C.muted,fontSize:12}}>Live from your bank</div></div>
      <div style={{textAlign:"right"}}><div style={{color:C.red,fontWeight:800,fontSize:15}}>–${totalSpent.toFixed(0)}</div><div style={{color:C.green,fontSize:11}}>+${totalIn.toFixed(0)} in</div></div>
    </div>
    <div style={{display:"flex",gap:6}}>
      {["txn","breakdown","cuts"].map(t=><button key={t} onClick={()=>setTab(t)} style={{flex:1,background:tab===t?C.orange+"22":C.cardAlt,border:`1px solid ${tab===t?C.orange:C.border}`,color:tab===t?C.orangeBright:C.muted,borderRadius:10,padding:"8px 0",cursor:"pointer",fontSize:11,fontWeight:700,fontFamily:"inherit"}}>
        {t==="txn"?"Transactions":t==="breakdown"?"Breakdown":"Smart Cuts"}
      </button>)}
    </div>
    {tab==="txn"&&<>
      <div style={{display:"flex",gap:6,overflowX:"auto",paddingBottom:4}}>
        {cats.map(c=><button key={c} onClick={()=>setCatFilter(c)} style={{background:catFilter===c?C.orange+"33":C.cardAlt,border:`1px solid ${catFilter===c?C.orange:C.border}`,color:catFilter===c?C.orangeBright:C.muted,borderRadius:99,padding:"4px 12px",cursor:"pointer",fontSize:11,fontWeight:700,whiteSpace:"nowrap",fontFamily:"inherit"}}>{c}</button>)}
      </div>
      {filtered.map(txn=>(
        <div key={txn.id} style={{background:C.card,borderRadius:14,padding:"13px 16px",border:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:12}}>
          <div style={{width:40,height:40,borderRadius:12,background:txn.color+"18",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}><Icon id={txnIcon(txn)} size={18} color={txn.color} strokeWidth={1.5}/></div>
          <div style={{flex:1}}>
            <div style={{color:C.cream,fontWeight:600,fontSize:14}}>{txn.name}</div>
            <div style={{display:"flex",gap:6,marginTop:2}}><Chip label={txn.cat} color={txn.color} size={10}/><span style={{color:C.muted,fontSize:10}}>{txn.date}</span></div>
          </div>
          <div style={{color:txn.amount<0?C.greenBright:C.cream,fontWeight:700,fontSize:15}}>{txn.amount<0?"+":"–"}${Math.abs(txn.amount).toFixed(2)}</div>
        </div>
      ))}
    </>}
    {tab==="breakdown"&&<>
      <Card style={{background:`linear-gradient(135deg,${C.orangeDim} 0%,${C.card} 100%)`,border:`1px solid ${C.orange}44`}}>
        <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.2}}>Total Spent This Month</div>
        <div style={{fontSize:38,fontWeight:900,color:C.orangeBright,fontFamily:"Georgia,serif"}}>${totalSpent.toFixed(0)}</div>
      </Card>
      {stats.topCats.map(([cat,amt],i)=>{
        const colors=[C.orange,C.pink,C.green,C.blue,C.purple,C.gold];
        const catTxns=txns.filter(t=>t.cat===cat&&t.amount>0);
        return <Card key={i}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
            <span style={{color:C.cream,fontSize:14,display:"flex",alignItems:"center",gap:8}}><span style={{fontSize:20}}>{catTxns[0]?.icon||"💰"}</span>{cat}</span>
            <span style={{color:colors[i%6],fontWeight:700}}>${amt.toFixed(0)} <span style={{color:C.muted,fontSize:11}}>({catTxns.length}×)</span></span>
          </div>
          <Bar v={amt} max={totalSpent} color={colors[i%6]}/>
          <div style={{color:C.muted,fontSize:11,marginTop:4}}>{Math.round(amt/totalSpent*100)}% of spending</div>
        </Card>;
      })}
    </>}
    {tab==="cuts"&&<>
      <Card style={{background:`linear-gradient(135deg,${C.orangeDim} 0%,${C.card} 100%)`,border:`1px solid ${C.orange}44`}}>
        <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.2}}>Potential Monthly Savings</div>
        <div style={{fontSize:32,fontWeight:900,color:C.goldBright,fontFamily:"Georgia,serif"}}>$200–350</div>
        <div style={{color:C.muted,fontSize:12}}>from {cuts.length} suggestions based on your real transactions</div>
      </Card>
      {cuts.length===0?<Card style={{textAlign:"center",padding:"30px 20px"}}><div style={{fontSize:40}}>🎉</div><div style={{color:C.greenBright,fontWeight:700,marginTop:10}}>All suggestions reviewed!</div></Card>
        :cuts.map(s=><Card key={s.id} glow={s.color}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
            <div style={{display:"flex",gap:10,alignItems:"center"}}><Icon id={s.icon||"card"} size={20} color={C.mutedHi} strokeWidth={1.5}/><span style={{color:s.color,fontWeight:800,fontSize:14}}>{s.title}</span></div>
            <button onClick={()=>setDismissed(d=>[...d,s.id])} style={{background:"none",border:"none",color:C.muted,cursor:"pointer",fontSize:16}}>✕</button>
          </div>
          <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.6,marginBottom:10}}>{s.body}</div>
          <div style={{display:"flex",gap:8}}><Chip label={`Save ${s.saving}`} color={C.green}/><Chip label={`Effort: ${s.effort}`} color={s.effort.includes("Very")?C.teal:C.green}/></div>
        </Card>)}
    </>}
  </div>;
}


// ─── GOALS ────────────────────────────────────────────────────────────────────
function Goals({data}){
  const [tab,setTab]=useState("sim");
  const [selDebt,setSelDebt]=useState(0);
  const [extra,setExtra]=useState(50);
  const [method,setMethod]=useState("avalanche");
  const debts=data.debts||[];
  const debt=debts.length>0?debts[selDebt]:{name:"Credit Card",balance:"3420",rate:"19.99",min:"68"};
  const noDebts = debts.length === 0;
  const bal=parseFloat(debt.balance||0),rate=parseFloat(debt.rate||0),minPay=parseFloat(debt.min||68);
  const mRate=rate/100/12;
  const calc=(xtra)=>{
    const pay=minPay+xtra;if(pay<=bal*mRate)return{months:999,interest:999999};
    let b=bal,m=0,int=0;while(b>0&&m<600){const i=b*mRate;int+=i;b=b+i-pay;m++;}
    return{months:m,interest:Math.max(0,int)};
  };
  const base=calc(0),curr=calc(extra);
  const saved=base.months-curr.months,intSaved=base.interest-curr.interest;
  const toYM=(m)=>{if(m>=600)return"Never";const y=Math.floor(m/12),mo=m%12;return y>0?`${y}y ${mo}m`:`${mo}mo`;};
  const payoffDate=()=>{const d=new Date();d.setMonth(d.getMonth()+curr.months);return d.toLocaleDateString("en",{month:"long",year:"numeric"});};
  const totalDebt=debts.reduce((a,d)=>a+parseFloat(d.balance||0),0);
  const netWorth=1243.88+DEMO.netWorthAdd-totalDebt;

  return <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}><div style={{fontSize:22,fontWeight:900,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif",letterSpacing:-0.5}}>Goals & Wealth</div><div style={{background:CC[data?.profile?.country||"CA"]?.currency==="USD"?C.blue+"22":C.green+"22",border:`1px solid ${CC[data?.profile?.country||"CA"]?.currency==="USD"?C.blue:C.green}33`,borderRadius:99,padding:"4px 12px",color:CC[data?.profile?.country||"CA"]?.currency==="USD"?C.blueBright:C.greenBright,fontSize:11,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{CC[data?.profile?.country||"CA"]?.flag} {CC[data?.profile?.country||"CA"]?.currency}</div></div>
    <div style={{display:"flex",gap:6}}>
      {[["sim","Simulator"],["worth","Net Worth"],["retire","Retirement"],["forecast","Wealth"],["personality","Personality"],["tax","Tax Tips"],["learn","Learn"]].map(([key,lbl])=>(
        <button key={key} onClick={()=>setTab(key)} style={{flex:1,background:tab===key?C.purple+"22":C.cardAlt,border:`1px solid ${tab===key?C.purple:C.border}`,color:tab===key?C.purpleBright:C.muted,borderRadius:10,padding:"8px 0",cursor:"pointer",fontSize:11,fontWeight:700,fontFamily:"inherit"}}>{lbl}</button>
      ))}
    </div>
    {tab==="sim"&&<>
      {noDebts&&<EmptyState icon="🎯" title="No debts tracked yet" body="Add debts during setup to simulate payoff strategies and see how much interest you can save." action="Go back to Setup" onAction={()=>{}} color={C.purple}/>}
      {!noDebts&&debts.length>1&&<div style={{display:"flex",gap:6,flexWrap:"wrap"}}>{debts.map((d,i)=><button key={i} onClick={()=>setSelDebt(i)} style={{background:selDebt===i?C.purple+"33":C.cardAlt,border:`1px solid ${selDebt===i?C.purple:C.border}`,color:selDebt===i?C.purpleBright:C.muted,borderRadius:10,padding:"6px 12px",cursor:"pointer",fontSize:12,fontWeight:700,fontFamily:"inherit"}}>{d.name}</button>)}</div>}
      {!noDebts&&<div style={{background:`linear-gradient(135deg,${C.purpleDim} 0%,${C.card} 100%)`,borderRadius:20,padding:"20px 22px",border:`1px solid ${C.purple}44`}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:18}}>
          <div>
            <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4}}>{debt.name}</div>
            <div style={{fontSize:36,fontWeight:900,color:C.purpleBright,fontFamily:"Georgia,serif",letterSpacing:-1}}>${bal.toLocaleString()}</div>
            <div style={{color:C.muted,fontSize:12}}>{rate}% interest · ${minPay}/mo minimum</div>
          </div>
          <div style={{textAlign:"right",background:C.green+"18",borderRadius:12,padding:"8px 12px",border:`1px solid ${C.green}33`}}>
            <div style={{color:C.muted,fontSize:10,textTransform:"uppercase"}}>Paid off</div>
            <div style={{color:C.greenBright,fontWeight:800,fontSize:15}}>{payoffDate()}</div>
            <div style={{color:C.muted,fontSize:11}}>{toYM(curr.months)}</div>
          </div>
        </div>
        <div style={{marginBottom:16}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
            <div style={{color:C.cream,fontSize:13,fontWeight:600}}>Extra monthly payment</div>
            <div style={{color:C.purpleBright,fontWeight:800,fontSize:20}}>+${extra}<span style={{color:C.muted,fontSize:12}}>/mo</span></div>
          </div>
          <input type="range" min={0} max={500} step={10} value={extra} onChange={e=>setExtra(Number(e.target.value))} style={{width:"100%",accentColor:C.purple,height:6,cursor:"pointer","--thumb-color":C.purple}}/>
          <div style={{display:"flex",justifyContent:"space-between",marginTop:4}}><span style={{color:C.muted,fontSize:10}}>+$0 (min only)</span><span style={{color:C.muted,fontSize:10}}>+$500/mo</span></div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <div style={{background:C.green+"15",borderRadius:12,padding:"12px 14px",border:`1px solid ${C.green}33`}}>
            <div style={{color:C.muted,fontSize:10,textTransform:"uppercase"}}>Time saved</div>
            <div style={{color:C.greenBright,fontWeight:800,fontSize:20,fontFamily:"Georgia,serif"}}>{saved>0?toYM(saved):"—"}</div>
          </div>
          <div style={{background:C.gold+"15",borderRadius:12,padding:"12px 14px",border:`1px solid ${C.gold}33`}}>
            <div style={{color:C.muted,fontSize:10,textTransform:"uppercase"}}>Interest saved</div>
            <div style={{color:C.goldBright,fontWeight:800,fontSize:20,fontFamily:"Georgia,serif"}}>{intSaved>0?`$${Math.round(intSaved).toLocaleString()}`:"—"}</div>
          </div>
        </div>
        {extra>0&&<div style={{marginTop:12,padding:"12px 14px",background:C.purple+"15",borderRadius:12,border:`1px solid ${C.purple}44`}}>
          <div style={{color:C.cream,fontSize:13,lineHeight:1.55}}>💡 Adding <strong style={{color:C.purpleBright}}>${extra}/month</strong> frees you <strong style={{color:C.greenBright}}>{toYM(saved)} earlier</strong> and saves <strong style={{color:C.goldBright}}>${Math.round(intSaved).toLocaleString()}</strong> in interest.</div>
        </div>}
      </div>
      <Card>
        <div style={{color:C.cream,fontWeight:700,marginBottom:12}}>Payoff Method</div>
        <div style={{display:"flex",gap:8}}>
          {[["avalanche","Avalanche","Highest rate first · saves the most"],["snowball","Snowball","Smallest balance first · fastest wins"]].map(([key,lbl,desc])=>(
            <button key={key} onClick={()=>setMethod(key)} style={{flex:1,background:method===key?C.purple+"22":C.cardAlt,border:`1px solid ${method===key?C.purple:C.border}`,borderRadius:12,padding:"12px 10px",cursor:"pointer",fontFamily:"inherit",textAlign:"center"}}>
              <div style={{color:method===key?C.purpleBright:C.cream,fontWeight:700,fontSize:13}}>{lbl}</div>
              <div style={{color:C.muted,fontSize:11,marginTop:4,lineHeight:1.4}}>{desc}</div>
            </button>
          ))}
        </div>
      </Card>
      {debts.length>0&&<Card>
        <div style={{color:C.cream,fontWeight:700,marginBottom:12}}>All Debts ({debts.length})</div>
        {[...debts].sort((a,b)=>parseFloat(b.rate||0)-parseFloat(a.rate||0)).map((d,i)=>{
          const colors=[C.red,C.gold,C.blue,C.purple];
          return <div key={i} style={{marginBottom:12}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}><span style={{color:C.cream,fontSize:13}}>{d.name}</span><span style={{color:colors[i%4],fontWeight:700}}>${parseFloat(d.balance).toLocaleString()} · {d.rate}%</span></div>
            <Bar v={parseFloat(d.balance)} max={totalDebt} color={colors[i%4]}/>
          </div>;
        })}
      </Card>}
    </>}
    {tab==="worth"&&(()=>{
      const country=data.profile?.country||"CA";
      const allAccts=data.accounts||[];
      const investments=allAccts.filter(a=>a.type==="investment");
      const totalInvested=investments.reduce((s,a)=>s+(a.balance||0),0);
      const totalGain=investments.reduce((s,a)=>s+(a.gain||0),0);
      const checking=allAccts.filter(a=>a.type==="checking").reduce((s,a)=>s+(a.balance||0),1243.88);
      const savings=allAccts.filter(a=>a.type==="savings").reduce((s,a)=>s+(a.balance||0),1840);
      const totalAssets=checking+savings+totalInvested;
      const totalDebt2=(data.debts||[]).reduce((a,d)=>a+parseFloat(d.balance||0),0);
      const realNetWorth=totalAssets-totalDebt2;
      const savLabel=country==="US"?"Savings / HYSA":"Savings / TFSA";
      const allItems=[
        {label:"Chequing / Checking",value:checking,type:"asset",color:C.green,icon:"🏦"},
        {label:savLabel,value:savings,type:"asset",color:C.teal,icon:"🛡️"},
        ...investments.map(inv=>({label:inv.name,value:inv.balance||0,type:"investment",color:C.purple,icon:"chartUp",gain:inv.gain,gainPct:inv.gainPct,ticker:inv.ticker})),
        ...(data.debts||[]).map(d=>({label:d.name,value:parseFloat(d.balance||0),type:"debt",color:C.red,icon:"💳"})),
      ];
      return <>
      <div style={{background:`linear-gradient(135deg,${C.tealDim} 0%,${C.card} 100%)`,borderRadius:20,padding:"22px",border:`1px solid ${C.teal}44`}}>
        <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,marginBottom:4,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>Your Net Worth</div>
        <div style={{fontSize:44,fontWeight:900,color:C.tealBright,fontFamily:"'Playfair Display',serif",letterSpacing:-1}}>{realNetWorth>=0?"+":""}$<CountUp to={Math.abs(realNetWorth)} decimals={0}/></div>
        <div style={{color:C.muted,fontSize:12,marginTop:4,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Assets minus liabilities · includes investments</div>
        {totalInvested>0&&<div style={{marginTop:12,display:"flex",gap:10}}>
          <div style={{flex:1,background:C.purple+"15",borderRadius:12,padding:"10px 14px",border:`1px solid ${C.purple}22`}}>
            <div style={{color:C.muted,fontSize:9,textTransform:"uppercase",letterSpacing:1,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Invested</div>
            <div style={{color:C.purpleBright,fontWeight:800,fontSize:18,fontFamily:"'Playfair Display',serif"}}>${totalInvested.toLocaleString()}</div>
          </div>
          <div style={{flex:1,background:C.green+"15",borderRadius:12,padding:"10px 14px",border:`1px solid ${C.green}22`}}>
            <div style={{color:C.muted,fontSize:9,textTransform:"uppercase",letterSpacing:1,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Total Gain</div>
            <div style={{color:C.greenBright,fontWeight:800,fontSize:18,fontFamily:"'Playfair Display',serif"}}>+${totalGain.toLocaleString()}</div>
          </div>
        </div>}
      </div>
      {allItems.map((item,i)=>(
        <div key={i} style={{background:C.card,borderRadius:16,padding:"14px 16px",border:`1px solid ${item.type==="investment"?C.purple+"33":C.border}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            <div style={{fontSize:20,width:32,textAlign:"center"}}>{item.icon}</div>
            <div>
              <div style={{color:C.cream,fontWeight:600,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{item.label}</div>
              {item.ticker&&<div style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{item.ticker}{item.gainPct?` · +${item.gainPct}%`:""}</div>}
              <Chip label={item.type==="investment"?"Investment 📈":item.type==="asset"?"Asset ↑":"Liability ↓"} color={item.color}/>
            </div>
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{color:item.color,fontWeight:800,fontSize:15}}>{item.type==="debt"?"–":"+"}${item.value.toLocaleString()}</div>
            {item.gain&&<div style={{color:C.greenBright,fontSize:11,fontWeight:600}}>+${item.gain.toLocaleString()}</div>}
          </div>
        </div>
      ))}</>; })()}

    {tab==="tax"&&(()=>{
      const cfg=CC[data.profile?.country||"CA"];
      const tips=cfg.taxTips;
      const highPriority=tips.filter(t=>t.priority==="high");
      const other=tips.filter(t=>t.priority!=="high");
      return <div style={{display:"flex",flexDirection:"column",gap:12}}>
        <div style={{background:C.goldDim,border:`1px solid ${C.gold}33`,borderRadius:16,padding:"14px 16px"}}>
          <div style={{color:C.goldBright,fontWeight:700,fontSize:13,marginBottom:4}}>{cfg.flag} {cfg.name}-specific tax opportunities</div>
          <div style={{color:C.muted,fontSize:12,lineHeight:1.6}}>Based on your country. Many people leave thousands unclaimed each year. Review each one.</div>
        </div>
        {highPriority.length>0&&<div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,paddingLeft:2}}>🔥 High Priority</div>}
        {tips.map((tip,i)=>(
          <div key={i} style={{background:C.card,borderRadius:18,padding:"18px",border:`1px solid ${tip.priority==="high"?C.gold+"44":C.border}`,position:"relative",overflow:"hidden"}}>
            {tip.priority==="high"&&<div style={{position:"absolute",top:0,left:0,right:0,height:2,background:`linear-gradient(90deg,${C.gold},${C.goldBright})`}}/>}
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
              <div style={{flex:1,paddingRight:12}}>
                <div style={{color:C.cream,fontWeight:800,fontSize:15,fontFamily:"'Playfair Display',serif",lineHeight:1.3,marginBottom:6}}>{tip.title}</div>
                <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.65}}>{tip.body}</div>
              </div>
              <div style={{textAlign:"center",flexShrink:0}}>
                <div style={{fontSize:20}}>{tip.flag}</div>
                {tip.priority==="high"&&<div style={{color:C.goldBright,fontSize:8,fontWeight:700,textTransform:"uppercase",letterSpacing:0.8,marginTop:2}}>Priority</div>}
              </div>
            </div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",paddingTop:10,borderTop:`1px solid ${C.border}`}}>
              <div>
                <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1}}>Potential savings</div>
                <div style={{color:C.goldBright,fontWeight:800,fontSize:15}}>{tip.savings}</div>
              </div>
              <div style={{background:C.gold+"18",border:`1px solid ${C.gold}33`,borderRadius:99,padding:"6px 14px",color:C.goldBright,fontSize:11,fontWeight:700,cursor:"pointer"}}>
                {tip.action} →
              </div>
            </div>
          </div>
        ))}
        {/* Benefits checker */}
        <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,paddingLeft:2,marginTop:4}}>🎁 Benefits You May Not Be Claiming</div>
        {cfg.benefitsChecker.map((b,i)=>(
          <div key={i} style={{background:C.card,borderRadius:14,padding:"14px 16px",border:`1px solid ${C.teal}22`,display:"flex",gap:12,alignItems:"flex-start"}}>
            <div style={{fontSize:24,flexShrink:0}}>{b.icon}</div>
            <div style={{flex:1}}>
              <div style={{color:C.cream,fontWeight:700,fontSize:13,marginBottom:2}}>{b.name}</div>
              <div style={{color:C.muted,fontSize:12,marginBottom:4}}>{b.eligible}</div>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{color:C.tealBright,fontWeight:700,fontSize:13}}>{b.amount}</span>
                <span style={{color:C.teal,fontSize:11,fontWeight:600}}>{b.apply} →</span>
              </div>
            </div>
          </div>
        ))}
      </div>;
    })()}

    {tab==="retire"&&(()=>{
      const cfg=CC[data.profile?.country||"CA"];
      const accts=cfg.retirementAccounts;
      return <div style={{display:"flex",flexDirection:"column",gap:14}}>
        <div style={{background:C.blueDim,border:`1px solid ${C.blue}33`,borderRadius:16,padding:"14px 16px"}}>
          <div style={{color:C.blueBright,fontWeight:700,fontSize:13,marginBottom:4}}>{cfg.flag} Registered & Tax-Advantaged Accounts</div>
          <div style={{color:C.muted,fontSize:12,lineHeight:1.6}}>These accounts are legal ways to keep more of your money. Most people don't maximize them.</div>
        </div>
        {accts.map((a,i)=>(
          <div key={i} style={{background:C.card,borderRadius:18,padding:"18px",border:`1px solid ${a.color}33`,position:"relative",overflow:"hidden"}}>
            <div style={{position:"absolute",top:0,left:0,right:0,height:2,background:`linear-gradient(90deg,${a.color},${a.color}88)`}}/>
            <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:12}}>
              <div style={{width:46,height:46,borderRadius:14,background:a.color+"18",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0}}>{a.icon}</div>
              <div>
                <div style={{color:a.color,fontWeight:900,fontSize:18,fontFamily:"'Playfair Display',serif"}}>{a.name}</div>
                <div style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{a.fullName}</div>
              </div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:12}}>
              <div style={{background:C.cardAlt,borderRadius:10,padding:"10px 12px"}}>
                <div style={{color:C.muted,fontSize:9,textTransform:"uppercase",letterSpacing:1.2,marginBottom:3,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Annual Limit</div>
                <div style={{color:C.cream,fontSize:13,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{a.annualLimit}</div>
              </div>
              <div style={{background:C.cardAlt,borderRadius:10,padding:"10px 12px"}}>
                <div style={{color:C.muted,fontSize:9,textTransform:"uppercase",letterSpacing:1.2,marginBottom:3,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Tax Treatment</div>
                <div style={{color:C.mutedHi,fontSize:12,lineHeight:1.5,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{a.taxNote}</div>
              </div>
            </div>
            <div style={{background:a.color+"12",border:`1px solid ${a.color}33`,borderRadius:12,padding:"10px 14px"}}>
              <span style={{color:a.color,fontSize:11,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>💡 Pro tip: </span>
              <span style={{color:C.cream,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{a.tip}</span>
            </div>
          </div>
        ))}
        {/* Emergency fund target */}
        <div style={{background:C.card,borderRadius:18,padding:"18px",border:`1px solid ${C.orange}33`}}>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
            <span style={{fontSize:24}}>🆘</span>
            <div style={{color:C.cream,fontWeight:800,fontSize:15,fontFamily:"'Playfair Display',serif"}}>Emergency Fund Target</div>
          </div>
          <div style={{color:C.orangeBright,fontSize:28,fontWeight:900,fontFamily:"'Playfair Display',serif",marginBottom:6}}>{cfg.emergencyMonths} months</div>
          <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.6,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{cfg.healthcareNote}</div>
        </div>
      </div>;
    })()}
    {tab==="forecast"&&<WealthForecast data={data}/>}
    {tab==="personality"&&<MoneyPersonality data={data}/>}
        {tab==="learn"&&(()=>{
      const cfg=CC[data.profile?.country||"CA"];
      return <div style={{display:"flex",flexDirection:"column",gap:12}}>
        <div style={{background:C.greenDim,border:`1px solid ${C.green}33`,borderRadius:16,padding:"12px 16px",marginBottom:4}}>
          <div style={{color:C.greenBright,fontWeight:700,fontSize:13}}>{cfg.flag} {cfg.name} Financial Essentials</div>
          <div style={{color:C.muted,fontSize:12,marginTop:2}}>Country-specific concepts that directly affect your money.</div>
        </div>
        {cfg.learnCards.concat([{emoji:"📈",title:"Compound interest: your best friend",body:"$100 at 7% for 30 years becomes $761. The same math works in reverse with debt. Start investing early. Pay debt fast.",key:"Time is the most powerful financial tool."}]).map((l,i)=>(
          <Card key={i}>
            <div style={{fontSize:28,marginBottom:8}}>{l.emoji}</div>
            <div style={{color:C.cream,fontWeight:900,fontSize:16,fontFamily:"'Playfair Display',Georgia,serif",marginBottom:8,lineHeight:1.3}}>{l.title}</div>
            <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.65,marginBottom:12}}>{l.body}</div>
            <div style={{background:C.green+"18",border:`1px solid ${C.green}33`,borderRadius:12,padding:"10px 14px"}}>
              <span style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Key takeaway · </span>
              <span style={{color:C.cream,fontSize:13,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{l.key}</span>
            </div>
          </Card>
        ))}
      </div>;
    })()}
  </div>;
}


// ─── FAMILY ───────────────────────────────────────────────────────────────────
function Family({data,household,setHousehold}){
  const [tab,setTab]=useState("meeting");
  const isCouple=data.profile.status!=="single";
  const [householdTab,setHouseholdTab]=useState("join"); // join | manage
  const [started,setStarted]=useState(false);
  const [checks,setChecks]=useState({});
  const [notes,setNotes]=useState({});
  const [mood,setMood]=useState(null);
  const [done2,setDone2]=useState(false);
  const [kidAge,setKidAge]=useState("8-12");
  const [chores,setChores]=useState([
    {id:1,task:"Make bed",reward:.50,done:true},{id:2,task:"Set the table",reward:.50,done:false},
    {id:3,task:"Take out garbage",reward:1.00,done:true},{id:4,task:"Vacuum living room",reward:2.00,done:false},
    {id:5,task:"Wash dishes",reward:1.50,done:false},{id:6,task:"Tidy bedroom",reward:1.00,done:false},
  ]);

  const agenda=isCouple?[
    {id:"bills",icon:"calendar",title:"Review upcoming bills together",desc:"Open Plan Ahead. Any surprises? Anything to prepare for?"},
    {id:"spend",icon:"chartUp",title:"Check where you each spent",desc:"No blame — just awareness. Anything consistently over budget?"},
    {id:"debt",icon:"trendUp",title:"Celebrate debt progress",desc:"Even $1 less is a win. Acknowledge the effort. If you missed a payment, figure out why without judgment."},
    {id:"goal",icon:"🎯",title:"Check in on your shared goal",desc:"Emergency fund? Vacation? House? How close? Does the goal still feel right?"},
    {id:"wins",icon:"star",title:"Name one win each",desc:"Both name one money win from this week. It rewires how you both feel about money."},
    {id:"next",icon:"📌",title:"One change for next week",desc:"Together pick ONE thing. Not ten. One achievable change. That's the habit loop."},
  ]:[
    {id:"bills",icon:"calendar",title:"What's coming up this week?",desc:"Open Plan Ahead. Any bill or expense you need to plan around?"},
    {id:"spend",icon:"chartUp",title:"How was your spending?",desc:"Honestly. No judgment. Anything feel out of control?"},
    {id:"mood",icon:"💭",title:"How do you feel about money right now?",desc:"Anxious? Calm? Overwhelmed? Your emotional state affects every decision."},
    {id:"win",icon:"star",title:"Name one win",desc:"Something you did right. Cooked at home? Resisted a sale? Put $20 away? Say it."},
    {id:"goal",icon:"🎯",title:"Check in on your goal",desc:"Emergency fund? Debt payoff? Even 1% closer is worth acknowledging."},
    {id:"next",icon:"📌",title:"One intention for next week",desc:"Not a list. One intention. Small wins build into lasting change."},
  ];

  const doneCount=Object.values(checks).filter(Boolean).length;
  const earned=chores.filter(c=>c.done).reduce((a,c)=>a+c.reward,0);

  const kidLessons={
    "4-7":[
      {emoji:"🪙",title:"Money is for trading",body:"When you want something at the store, you give money and get the thing. Money is just a trade ticket!",key:"Money is how we trade for things we want."},
      {emoji:"🐷",title:"Saving means waiting",body:"If a toy costs $10 and you have $3, you need to save $7 more. Saving means keeping money safe until you have enough.",key:"Waiting for something makes it even better."},
    ],
    "8-12":[
      {emoji:"🏦",title:"What banks do",body:"A bank keeps your money safe and pays you interest to use it. Like a super-safe piggy bank that rewards patience.",key:"Banks keep money safe AND pay you to use them."},
      {emoji:"💳",title:"Credit cards are loans",body:"A credit card lets you buy now, pay later. If you don't pay it ALL back quickly, they charge you extra — that's how people get into trouble.",key:"Pay your credit card in full every month, always."},
      {emoji:"📈",title:"Money can grow",body:"$100 at 7% becomes $386 in 20 years without doing anything. This is compound interest — money making more money.",key:"Start saving young. Time is the secret ingredient."},
    ],
    "13+":[
      {emoji:"💰",title:"Budget like a boss",body:"50% needs, 30% wants, 20% savings. Without a budget, money just disappears. A budget is a plan for the life you actually want.",key:"A budget gives your money direction."},
      {emoji:"🚫",title:"Debt borrows from your future self",body:"When you go into debt, you're spending money you haven't earned yet — and paying extra for the privilege.",key:"Debt is expensive. Use it wisely or not at all."},
      {emoji:"📊",title:"Start investing at your first job",body:"$50/month at 7% starting at 16 = $245,000 at retirement. Starting at 30 = $68,000. Starting early nearly triples your outcome.",key:"Invest with your very first paycheck."},
    ],
  };

  return <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <div><div style={{fontSize:22,fontWeight:800,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif"}}>Family</div><div style={{color:C.muted,fontSize:12}}>Money is a team sport</div></div>
    <div style={{display:"flex",gap:6}}>
      {[["meeting",isCouple?"Money Meeting":"Check-In"],["kids","Kids Zone"],["household","Household"]].map(([t,lbl])=>(
        <button key={t} onClick={()=>setTab(t)} style={{flex:1,background:tab===t?C.purple+"22":C.cardAlt,border:`1px solid ${tab===t?C.purple:C.border}`,color:tab===t?C.purpleBright:C.muted,borderRadius:12,padding:"10px",cursor:"pointer",fontWeight:700,fontSize:12,fontFamily:"inherit"}}>
          {lbl}
        </button>
      ))}
    </div>
    {tab==="meeting"&&<>
      {!started&&!done2&&<>
        <Card style={{background:C.purpleDim,border:`1px solid ${C.purple}44`}}>
          <div style={{color:C.purpleBright,fontWeight:800,fontSize:16,marginBottom:8}}>{isCouple?"💑 Weekly Money Meeting":"🧘 Weekly Check-In"}</div>
          <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.65}}>{isCouple?`The #1 habit of couples who build wealth: a 15-minute weekly money talk. No fights, no blame — just a structured check-in.${data.profile.partnerName?` Ready to go with ${data.profile.partnerName}?`:""}`:
            "10 minutes a week. Honest reflection on where your money went and where you're heading."}</div>
        </Card>
        <Card>
          <div style={{color:C.cream,fontWeight:700,marginBottom:10}}>Today's agenda</div>
          {agenda.map((a,i)=><div key={i} style={{display:"flex",gap:10,padding:"7px 0",borderBottom:i<agenda.length-1?`1px solid ${C.border}`:"none"}}><span style={{fontSize:16}}>{a.icon}</span><span style={{color:C.mutedHi,fontSize:13}}>{a.title}</span></div>)}
        </Card>
        <Btn label={isCouple?"Start Meeting ▶":"Start Check-In ▶"} onClick={()=>setStarted(true)} color={C.purple}/>
      </>}
      {started&&!done2&&<>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <Chip label={`${doneCount}/${agenda.length} done`} color={doneCount===agenda.length?C.green:C.purple}/>
          <div style={{display:"flex",gap:3}}>{agenda.map((a,i)=><div key={i} style={{width:28,height:3,borderRadius:99,background:checks[a.id]?C.purple:C.border,transition:"background .3s"}}/>)}</div>
        </div>
        {agenda.map(item=>(
          <div key={item.id} style={{background:checks[item.id]?C.purpleDim:C.card,borderRadius:16,padding:"16px 18px",border:`1px solid ${checks[item.id]?C.purple+"66":C.border}`,transition:"all .3s"}}>
            <div style={{display:"flex",gap:12}}>
              <div onClick={()=>setChecks(c=>({...c,[item.id]:!c[item.id]}))} style={{width:22,height:22,borderRadius:6,border:`2px solid ${checks[item.id]?C.purple:C.border}`,background:checks[item.id]?C.purple:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:2,transition:"all .2s"}}>
                {checks[item.id]&&<span style={{color:C.bg,fontSize:12,fontWeight:900}}>✓</span>}
              </div>
              <div style={{flex:1}}>
                <div style={{color:C.cream,fontWeight:700,fontSize:14,marginBottom:4}}>{item.icon} {item.title}</div>
                <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.55,marginBottom:10}}>{item.desc}</div>
                <textarea value={notes[item.id]||""} onChange={e=>setNotes(n=>({...n,[item.id]:e.target.value}))} placeholder="Notes…"
                  style={{width:"100%",background:C.cardAlt,border:`1px solid ${C.border}`,borderRadius:10,color:C.cream,padding:"9px 12px",fontSize:13,fontFamily:"inherit",resize:"none",outline:"none",height:56,boxSizing:"border-box"}}/>
              </div>
            </div>
          </div>
        ))}
        {!isCouple&&<Card>
          <div style={{color:C.cream,fontWeight:700,marginBottom:10}}>How do you feel right now?</div>
          <div style={{display:"flex",gap:8,justifyContent:"center"}}>
            {["😰","😟","😐","🙂","😊","🤩"].map(e=><button key={e} onClick={()=>setMood(e)} style={{fontSize:28,background:mood===e?C.purple+"33":"none",border:`2px solid ${mood===e?C.purple:"transparent"}`,borderRadius:12,padding:6,cursor:"pointer",transition:"all .2s"}}>{e}</button>)}
          </div>
        </Card>}
        <Btn label={doneCount===agenda.length?"Complete ✓":`Finish (${doneCount}/${agenda.length} done)`} onClick={()=>setDone2(true)} color={doneCount===agenda.length?C.purple:C.muted}/>
      </>}
      {done2&&<div style={{textAlign:"center"}}>
        <div style={{display:"flex",justifyContent:"center",marginBottom:6}}><Icon id="sparkles" size={48} color={C.green} strokeWidth={1.3}/></div>
        <div style={{fontSize:22,fontWeight:800,color:C.purpleBright,fontFamily:"Georgia,serif",marginTop:12,marginBottom:8}}>{isCouple?"Meeting complete!":"Check-in done!"}</div>
        <div style={{color:C.mutedHi,fontSize:14,lineHeight:1.7,marginBottom:20}}>{isCouple?"You just did what most couples never do: talked openly about money. That's the habit that builds wealth.":"10 minutes every week. This is the habit."}</div>
        <Btn label="Start New" onClick={()=>{setStarted(false);setDone2(false);setChecks({});setNotes({});setMood(null);}} outline color={C.purple}/>
      </div>}
    </>}
    {tab==="kids"&&<>
      <div style={{display:"flex",gap:6}}>
        {["4-7","8-12","13+"].map(age=><button key={age} onClick={()=>setKidAge(age)} style={{flex:1,background:kidAge===age?C.pink+"22":C.cardAlt,border:`1px solid ${kidAge===age?C.pink:C.border}`,color:kidAge===age?C.pinkBright:C.muted,borderRadius:10,padding:"9px 0",cursor:"pointer",fontSize:12,fontWeight:700,fontFamily:"inherit"}}>
          {age==="4-7"?"🐣 4–7":age==="8-12"?"🌱 8–12":"🌳 13+"}
        </button>)}
      </div>
      {kidLessons[kidAge].map((l,i)=>(
        <Card key={i} style={{border:`1px solid ${C.pink}22`}}>
          <div style={{fontSize:30,marginBottom:8}}>{l.emoji}</div>
          <div style={{color:C.cream,fontWeight:800,fontSize:15,fontFamily:"Georgia,serif",marginBottom:8}}>{l.title}</div>
          <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.65,marginBottom:10}}>{l.body}</div>
          <Chip label={l.key} color={C.pink} size={12}/>
        </Card>
      ))}
      <Card style={{background:`linear-gradient(135deg,${C.goldDim} 0%,${C.card} 100%)`,border:`1px solid ${C.gold}33`}}>
        <div style={{color:C.gold,fontWeight:800,marginBottom:8}}>🫙 The 3 Jar Method</div>
        <div style={{color:C.mutedHi,fontSize:13,marginBottom:12}}>Split every dollar your child earns into 3 jars.</div>
        <div style={{display:"flex",gap:8}}>
          {[{name:"Spend",emoji:"🎮",color:C.orange,desc:"Fun now"},{name:"Save",emoji:"🏦",color:C.blue,desc:"Big goals"},{name:"Give",emoji:"❤️",color:C.pink,desc:"Others"}].map((j,i)=>(
            <div key={i} style={{flex:1,background:j.color+"18",border:`1px solid ${j.color}33`,borderRadius:12,padding:"12px 8px",textAlign:"center"}}>
              <div style={{fontSize:22}}>{j.emoji}</div>
              <div style={{color:j.color,fontWeight:700,fontSize:13,marginTop:4}}>{j.name}</div>
              <div style={{color:C.muted,fontSize:10,marginTop:2}}>{j.desc}</div>
            </div>
          ))}
        </div>
      </Card>
      <Card>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <div style={{color:C.greenBright,fontWeight:700}}>🏡 Chore Chart</div>
          <div style={{color:C.greenBright,fontWeight:800}}>${earned.toFixed(2)} earned this week</div>
        </div>
        <Bar v={earned} max={chores.reduce((a,c)=>a+c.reward,0)} color={C.green} h={6}/>
        <div style={{marginTop:12}}>
          {chores.map(ch=>(
            <div key={ch.id} onClick={()=>setChores(c=>c.map(x=>x.id===ch.id?{...x,done:!x.done}:x))} style={{display:"flex",gap:10,alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${C.border}`,cursor:"pointer"}}>
              <div style={{width:22,height:22,borderRadius:6,border:`2px solid ${ch.done?C.green:C.border}`,background:ch.done?C.green:"none",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,transition:"all .2s"}}>
                {ch.done&&<span style={{color:C.bg,fontSize:12,fontWeight:900}}>✓</span>}
              </div>
              <span style={{flex:1,color:C.cream,fontSize:14,textDecoration:ch.done?"line-through":"none"}}>{ch.task}</span>
              <span style={{color:C.gold,fontWeight:700}}>+${ch.reward.toFixed(2)}</span>
            </div>
          ))}
        </div>
      </Card>

    {tab==="household"&&(()=>{
      const [householdCode,setHouseholdCode]=useState("");
      const genCode=()=>Math.random().toString(36).substring(2,8).toUpperCase();
      if(household){return(
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <div style={{background:`linear-gradient(135deg,${C.green}18,${C.greenDim})`,borderRadius:20,padding:"22px",border:`1px solid ${C.green}33`,textAlign:"center"}}>
            <div style={{marginBottom:10,display:"flex",justifyContent:"center"}}><Icon id="house2" size={34} color={C.muted} strokeWidth={1.4}/></div>
            <div style={{color:C.greenBright,fontWeight:900,fontSize:20,fontFamily:"'Playfair Display',serif",marginBottom:6}}>Household Connected</div>
            <div style={{background:C.bg,borderRadius:14,padding:"14px 20px",display:"inline-block",marginBottom:12}}>
              <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:2,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:4}}>Household Code</div>
              <div style={{color:C.greenBright,fontWeight:900,fontSize:28,fontFamily:"'Playfair Display',serif",letterSpacing:4}}>{household.code}</div>
            </div>
            <div style={{color:C.muted,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.6}}>Share this code with your partner. They enter it in their Flourish app to join.</div>
          </div>
          {household.partnerName&&<div style={{background:C.card,borderRadius:16,padding:"16px 20px",border:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:12}}>
            <div style={{width:40,height:40,borderRadius:99,background:C.pink+"22",border:`1px solid ${C.pink}33`,display:"flex",alignItems:"center",justifyContent:"center"}}><Icon id="user" size={18} color={C.mutedHi} strokeWidth={1.5}/></div>
            <div>
              <div style={{color:C.cream,fontWeight:700,fontSize:14,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{household.partnerName}</div>
              <div style={{color:C.green,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>✓ Connected to your household</div>
            </div>
          </div>}
          <div style={{background:C.card,borderRadius:16,padding:"16px 20px",border:`1px solid ${C.border}`}}>
            <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.2,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:12,fontWeight:600}}>Shared Goals</div>
            {(household.sharedGoals||["Emergency fund: $5,000","Vacation: $2,000","Pay off credit card"]).map((g,i)=>(
              <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:i<2?`1px solid ${C.border}`:"none"}}>
                <div style={{width:8,height:8,borderRadius:99,background:C.green,flexShrink:0}}/>
                <div style={{color:C.cream,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{g}</div>
              </div>
            ))}
          </div>
          <button onClick={()=>setHousehold(null)} style={{background:"none",border:`1px solid ${C.red}33`,borderRadius:12,padding:"10px",color:C.red,fontSize:13,cursor:"pointer",fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Leave Household</button>
        </div>
      );}
      return(
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <div style={{background:C.purpleDim,borderRadius:20,padding:"20px",border:`1px solid ${C.purple}33`,textAlign:"center"}}>
            <div style={{marginBottom:10,display:"flex",justifyContent:"center"}}><Icon id="house2" size={38} color={C.green} strokeWidth={1.4}/></div>
            <div style={{color:C.purpleBright,fontWeight:900,fontSize:20,fontFamily:"'Playfair Display',serif",marginBottom:8}}>Household Sharing</div>
            <div style={{color:C.muted,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.7,marginBottom:0}}>Connect with a partner. See combined net worth, track shared goals, and run Money Meetings together — each person keeps their own account.</div>
          </div>
          <div style={{display:"flex",gap:8}}>
            {[["join","Join Existing"],["create","Create New"]].map(([t,lbl])=>(
              <button key={t} onClick={()=>setHouseholdTab(t)} style={{flex:1,background:householdTab===t?C.purple+"22":C.cardAlt,border:`1px solid ${householdTab===t?C.purple:C.border}`,color:householdTab===t?C.purpleBright:C.muted,borderRadius:10,padding:"10px",cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:"inherit"}}>{lbl}</button>
            ))}
          </div>
          {householdTab==="create"&&<>
            <div style={{background:C.card,borderRadius:16,padding:"20px",border:`1px solid ${C.border}`,textAlign:"center"}}>
              <div style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:8}}>Your household code:</div>
              <div style={{color:C.greenBright,fontWeight:900,fontSize:34,fontFamily:"'Playfair Display',serif",letterSpacing:5,marginBottom:8}}>FLRSH1</div>
              <div style={{color:C.muted,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Share with your partner to connect</div>
            </div>
            <div>
              <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.2,marginBottom:6,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Partner Name (optional)</div>
              <input value={householdCode} onChange={e=>setHouseholdCode(e.target.value)} placeholder="e.g. Jordan" style={{width:"100%",background:C.cardAlt,border:`1px solid ${C.border}`,borderRadius:10,padding:"12px 14px",color:C.cream,fontSize:14,fontFamily:"'Plus Jakarta Sans',sans-serif",boxSizing:"border-box"}}/>
            </div>
            <button onClick={()=>setHousehold({code:"FLRSH1",partnerName:householdCode||"Partner",sharedGoals:["Emergency fund: $5,000","Vacation: $2,000","Pay off credit card"]})}
              style={{background:`linear-gradient(135deg,${C.green},${C.greenBright})`,color:"#FFFFFF",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:15,padding:"14px",borderRadius:99,border:"none",cursor:"pointer",boxShadow:`0 6px 24px ${C.green}35`}}>
              Create Household →
            </button>
          </>}
          {householdTab==="join"&&<>
            <div>
              <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.2,marginBottom:6,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Enter Household Code</div>
              <input value={householdCode} onChange={e=>setHouseholdCode(e.target.value.toUpperCase())} placeholder="e.g. FLRSH1" maxLength={6} style={{width:"100%",background:C.cardAlt,border:`1px solid ${C.border}`,borderRadius:10,padding:"12px 14px",color:C.cream,fontSize:18,fontFamily:"'Playfair Display',serif",letterSpacing:4,boxSizing:"border-box",textTransform:"uppercase",textAlign:"center"}}/>
            </div>
            <button onClick={()=>setHousehold({code:householdCode||"FLRSH1",partnerName:data.profile?.partnerName||"Partner",sharedGoals:["Emergency fund: $5,000","Vacation: $2,000","Pay off credit card"]})}
              style={{background:`linear-gradient(135deg,${C.purple},${C.purpleBright})`,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:15,padding:"14px",borderRadius:99,border:"none",cursor:"pointer",boxShadow:`0 6px 24px ${C.purple}35`}}>
              Join Household →
            </button>
          </>}
        </div>
      );
    })()}
    </>}
  </div>;
}


// ─── AI COACH ─────────────────────────────────────────────────────────────────
function AICoach({data, isOnline=true}){ // Obsidian dark
  const [insights,setInsights]=useState([]);
  const [loading,setLoading]=useState(false);
  const [chatMode,setChatMode]=useState(false);
  const [messages,setMessages]=useState([]);
  const [input,setInput]=useState("");
  const [chatLoading,setChatLoading]=useState(false);
  const [generated,setGenerated]=useState(false);
  const chatRef=useRef(null);
  const txns=data.transactions||MOCK_TXN;
  const stats=computeStats(txns);

  // BehaviorEngine powers rich context for AI
  const behaviorData = BehaviorEngine.analyze(data);
  const { score: healthScore, pillars: healthPillars } = calcHealthScore(data);
  const { safeAmount, riskLevel } = SafeSpendEngine.calculate(data);
  const { cashFlow: cf, monthlyIncome: mi } = FinancialCalcEngine.cashFlow(data);

  const buildCtx=()=>{
    const txSummary=txns.slice(0,20).map(t=>`${t.date}: ${t.name} ${t.amount>0?`$${t.amount} (${t.cat})`:`INCOME $${Math.abs(t.amount)}`}`).join("\n");
    const accts=(data.accounts||MOCK_ACCOUNTS).map(a=>`- ${a.name}: $${a.balance} (${a.type})`).join("\n");
    const cfg=CC[data.profile?.country||"CA"];
    const profileCtx=`PROFILE:\n- Name: ${data.profile?.name||"User"}\n- Country: ${cfg.name} (${cfg.currency})\n- Province/State: ${data.profile?.province||""}\n- Relationship: ${data.profile?.status||"single"}\n- Children: ${data.profile?.hasKids?"Yes":"No"}\n- Credit Score: ${data.profile?.creditScore||"Unknown"}`;
    const incomeCtx=data.incomes?.length>0?`INCOME SOURCES:\n${data.incomes.map(i=>`- ${i.label}: $${i.amount} ${i.freq} (${i.type})`).join("\n")}`:"INCOME: Not specified";
    const behaviorCtx=`BEHAVIOR PATTERNS:\n${behaviorData.insights.map(i=>`- [${i.type.toUpperCase()}] ${i.title}: ${i.body}`).join("\n")||"- No significant patterns detected"}\n- Spending stability score: ${Math.round(behaviorData.spendingStability*100)}%\n- Payday spike ratio: ${behaviorData.spikeRatio?.toFixed(2)||"N/A"}x`;
    const engineCtx=`FINANCIAL ENGINES OUTPUT:\n- Financial Health Score: ${healthScore}/100\n- Safe to Spend Today: $${safeAmount.toFixed(0)} (risk: ${riskLevel})\n- Monthly Cash Flow: ${cf>=0?"+":""}$${cf.toFixed(0)}\n- Savings Rate: ${Math.round(FinancialCalcEngine.savingsRate(data)*100)}%\n- Debt Ratio: ${Math.round(FinancialCalcEngine.debtRatio(data)*100)}% of annual income\n- Emergency Fund: ${FinancialCalcEngine.emergencyFundMonths(data).toFixed(1)} months\n\nHEALTH PILLARS:\n${healthPillars.map(p=>`- ${p.label}: ${p.pts}/${p.max} pts (${p.detail})`).join("\n")}`;
    return `${profileCtx}\n\n${incomeCtx}\n\nACCOUNTS:\n${accts}\n\nSPENDING SUMMARY (last 30 days):\n- Total spent: $${stats.totalSpent.toFixed(2)} ${cfg.currency}\n- Coffee: ${stats.coffeeCount} times, $${stats.coffee.toFixed(2)}\n- Food delivery: $${stats.delivery.toFixed(2)}\n- Subscriptions: $${stats.subs.toFixed(2)}/mo\n- Busiest day: ${stats.busiest}\n\nTOP CATEGORIES:\n${stats.topCats.map(([c,a])=>`- ${c}: $${a.toFixed(2)}`).join("\n")}\n\n${behaviorCtx}\n\n${engineCtx}\n\nRECENT TRANSACTIONS:\n${txSummary}`;
  };

  const generateInsights=async()=>{
    if(!isOnline){setInsights([{type:"warning",icon:"📡",title:"You're offline",body:"AI coaching requires an internet connection. Your data is saved locally and will be ready when you reconnect.",saving:"—",priority:"low"}]);return;}
    setLoading(true);setInsights([]);
    try{
      const _sys = `You are Flourish, a warm non-judgmental financial coach. The user is in ${CC[data.profile?.country||"CA"]?.name||"Canada"} using ${CC[data.profile?.country||"CA"]?.currency||"CAD"}. Give country-specific advice — reference ${data.profile?.country==="US"?"401k/IRA/HSA/EITC":"RRSP/TFSA/FHSA/CCB/GST credit"} where relevant. Analyze real transaction data. Use exact numbers and merchant names. Be conversational and specific. Respond ONLY with valid JSON:\n{"insights":[{"type":"pattern|warning|win|opportunity","icon":"emoji","title":"short title","body":"insight with specific numbers and country-specific advice","saving":"estimated monthly saving in ${CC[data.profile?.country||"CA"]?.currency||"CAD"}","priority":"high|medium|low"}]}\nGenerate exactly 5 insights.`;
      const r=await fetch("/api/coach",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
        type:"insights",
        payload:{ system:_sys, prompt:`Analyze this user's real financial data and give 5 specific insights:\n\n${buildCtx()}` }
      })});
      const d=await r.json();
      const text=d.content?.[0]?.text||"{}";
      const parsed=JSON.parse(text.replace(/```json|```/g,"").trim());
      setInsights(parsed.insights||[]);setGenerated(true);
    }catch(e){
      setInsights([{type:"warning",icon:"⚠️",title:"Connection issue",body:"Couldn't reach the AI right now. Your data is safe. Tap \"Analyze My Spending\" to retry.",saving:"—",priority:"low",canRetry:true}]);
    }
    setLoading(false);
  };

  const sendChat=async()=>{
    if(!input.trim()||chatLoading)return;
    const userMsg=input.trim();setInput("");
    const newMessages=[...messages,{role:"user",content:userMsg}];
    setMessages(newMessages);setChatLoading(true);
    try{
      const _chatSys = `You are Flourish — a warm, direct financial coach with access to this user's real bank data.\n\n${buildCtx()}\n\nBe conversational. Use specific numbers from their data. Keep responses concise — 2–4 sentences unless they ask for detail. Sound like a smart friend, not a financial advisor. Never be preachy.`;
      const r=await fetch("/api/coach",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
        type:"chat",
        payload:{ system:_chatSys, messages:newMessages }
      })});
      const d=await r.json();
      const reply=d.content?.[0]?.text||"Connection issue — try again.";
      setMessages([...newMessages,{role:"assistant",content:reply}]);
    }catch{setMessages([...newMessages,{role:"assistant",content:isOnline?"I had trouble connecting — tap to try again.":"You're offline right now. I'll be ready when you reconnect 📡"}]);}
    setChatLoading(false);
    setTimeout(()=>chatRef.current?.scrollTo({top:99999,behavior:"smooth"}),100);
  };

  const typeColors={pattern:C.blue,warning:C.red,win:C.green,opportunity:C.gold};

  if(chatMode)return(
    <div style={{display:"flex",flexDirection:"column",height:"70vh"}}>
      <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:16}}>
        <button onClick={()=>setChatMode(false)} style={{background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,color:C.cream,borderRadius:10,padding:"7px 14px",cursor:"pointer",fontSize:13}}>← Back</button>
        <div><div style={{fontSize:18,fontWeight:800,color:C.cream,fontFamily:"Georgia,serif"}}>Ask Your Coach</div><div style={{color:C.muted,fontSize:11}}>Has full access to your transaction data</div></div>
      </div>
      <div ref={chatRef} style={{flex:1,overflowY:"auto",display:"flex",flexDirection:"column",gap:12,marginBottom:14}}>
        <div style={{background:C.greenDim,borderRadius:16,padding:"14px 16px",border:`1px solid ${C.green}44`,alignSelf:"flex-start",maxWidth:"85%"}}>
          <div style={{color:C.cream,fontWeight:700,fontSize:13,marginBottom:4,display:"flex",alignItems:"center",gap:5}}><FlourishMark size={16}/><span>Flourish</span></div>
          <div style={{color:C.cream,fontSize:14,lineHeight:1.6}}>I've read through all your transactions. Ask me anything — your biggest patterns, where to cut, what your habits look like, anything.</div>
        </div>
        {messages.map((msg,i)=>(
          <div key={i} style={{background:msg.role==="user"?C.purpleDim:C.greenDim,borderRadius:16,padding:"12px 16px",border:`1px solid ${msg.role==="user"?C.purple+"44":C.green+"44"}`,alignSelf:msg.role==="user"?"flex-end":"flex-start",maxWidth:"85%"}}>
            {msg.role==="assistant"&&<div style={{color:C.cream,fontWeight:700,fontSize:12,marginBottom:4,display:"flex",alignItems:"center",gap:5}}><FlourishMark size={16}/><span>Flourish</span></div>}
            <div style={{color:C.cream,fontSize:14,lineHeight:1.6}}>{msg.content}</div>
          </div>
        ))}
        {chatLoading&&<div style={{background:C.greenDim,borderRadius:16,padding:"14px 16px",border:`1px solid ${C.green}44`,alignSelf:"flex-start"}}>
          <div style={{color:C.cream,fontWeight:700,fontSize:12,marginBottom:6,display:"flex",alignItems:"center",gap:5}}><FlourishMark size={16}/><span>Flourish</span></div>
          <div style={{display:"flex",gap:5}}>{[0,1,2].map(i=><div key={i} style={{width:7,height:7,borderRadius:"50%",background:C.green,opacity:.3+i*.3}}/>)}</div>
        </div>}
      </div>
      <div style={{display:"flex",gap:10,background:C.cardAlt,borderRadius:14,padding:"10px 14px",border:`1px solid ${C.border}`}}>
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&isOnline&&sendChat()} placeholder={isOnline?"Ask about your spending, debt, savings…":"You're offline — reconnect to chat"} disabled={!isOnline}
          style={{flex:1,background:"none",border:"none",outline:"none",color:isOnline?C.cream:C.muted,fontSize:14,fontFamily:"inherit"}}/>
        <button onClick={sendChat} disabled={!input.trim()||chatLoading} style={{background:input.trim()?C.green:C.border,border:"none",borderRadius:10,padding:"8px 14px",color:C.bg,fontWeight:700,cursor:input.trim()?"pointer":"not-allowed",fontSize:14,transition:"all .2s"}}>→</button>
      </div>
      <div style={{display:"flex",gap:6,marginTop:10,flexWrap:"wrap"}}>
        {["Where can I cut spending?","Why is my balance low?","How fast can I pay off my debt?","What's my worst habit?"].map(q=>(
          <button key={q} onClick={()=>setInput(q)} style={{background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,borderRadius:99,padding:"5px 12px",color:C.muted,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>{q}</button>
        ))}
      </div>
    </div>
  );

  return <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
      <div><div style={{fontSize:22,fontWeight:800,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif"}}>AI Coach 🧠</div><div style={{color:C.muted,fontSize:12,marginTop:2}}>Powered by your real transactions</div></div>
      <button onClick={()=>setChatMode(true)} style={{background:C.greenDim,border:`1px solid ${C.green}44`,borderRadius:12,padding:"8px 14px",color:C.greenBright,fontWeight:700,fontSize:12,cursor:"pointer",fontFamily:"inherit"}}>💬 Chat</button>
    </div>
    <Card style={{background:`linear-gradient(135deg,${C.tealDim} 0%,${C.card} 100%)`,border:`1px solid ${C.teal}44`}}>
      <div style={{color:C.tealBright,fontWeight:700,marginBottom:10}}>What the AI can see</div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
        {[["card",`${txns.length} transactions`,"30 days imported"],["coffee",`${stats.coffeeCount} coffee runs`,`$${stats.coffee.toFixed(2)} total`],["bag","Food delivery",`$${stats.delivery.toFixed(2)} total`],["calendar","Busiest day",stats.busiest]].map(([iconId,label,sub],i)=>(
          <div key={i} style={{background:C.cardAlt,borderRadius:12,padding:"10px 12px",border:`1px solid ${C.border}`,display:"flex",gap:8,alignItems:"center"}}>
            <span style={{fontSize:18}}>{icon}</span>
            <div><div style={{color:C.cream,fontWeight:600,fontSize:13}}>{label}</div><div style={{color:C.muted,fontSize:11}}>{sub}</div></div>
          </div>
        ))}
      </div>
    </Card>
    <Card>
      <div style={{color:C.cream,fontWeight:700,marginBottom:12}}>Spending by Category</div>
      {stats.topCats.map(([cat,amt],i)=>{
        const colors=[C.orange,C.pink,C.green,C.blue,C.purple,C.gold];
        return <div key={i} style={{marginBottom:12}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}><span style={{color:C.cream,fontSize:13}}>{cat}</span><span style={{color:colors[i%6],fontWeight:700,fontSize:12}}>${amt.toFixed(2)}</span></div>
          <Bar v={amt} max={stats.totalSpent} color={colors[i%6]}/>
        </div>;
      })}
    </Card>
    {!generated&&!loading&&(
      {/* ── BEHAVIOR INSIGHTS from BehaviorEngine ── */}
      {behaviorData.insights.length>0&&!chatMode&&(
        <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:4}}>
          <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.8,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,marginBottom:2}}>Detected Patterns</div>
          {behaviorData.insights.slice(0,3).map((ins,i)=>(
            <div key={i} style={{background:C.card,border:`1.5px solid ${ins.color}33`,borderRadius:16,padding:"12px 14px",display:"flex",gap:10,alignItems:"flex-start"}}>
              <span style={{fontSize:18,flexShrink:0}}>{ins.icon}</span>
              <div style={{flex:1}}>
                <div style={{color:ins.color,fontWeight:700,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:3}}>{ins.title}</div>
                <div style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.55}}>{ins.body}</div>
                {ins.saving&&<div style={{color:C.greenBright,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:700,marginTop:4}}>💡 {ins.saving}</div>}
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Financial disclaimer */}
      <div style={{background:C.cardAlt,borderRadius:12,padding:"10px 14px",border:`1px solid ${C.border}`,marginBottom:4,display:"flex",gap:8,alignItems:"flex-start"}}>
        <span style={{fontSize:13,flexShrink:0,marginTop:1}}>ℹ️</span>
        <span style={{color:C.muted,fontSize:10.5,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.6}}>Flourish provides <strong style={{color:C.mutedHi}}>financial education and coaching</strong>, not regulated financial advice. Always verify decisions with a qualified advisor for major financial choices.</span>
      </div>
            <button onClick={generateInsights} style={{background:`linear-gradient(135deg,${C.green},${C.teal})`,border:"none",borderRadius:16,padding:"18px 24px",color:C.bg,fontWeight:800,fontSize:17,cursor:"pointer",fontFamily:"Georgia,serif",letterSpacing:.3,boxShadow:`0 0 30px ${C.green}33`,transition:"opacity .2s"}}
        onMouseEnter={e=>e.currentTarget.style.opacity=".88"} onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
        Analyze My Spending
      </button>
    )}
    {loading&&<Card style={{textAlign:"center",padding:"30px 20px"}}>
      <div style={{marginBottom:12,display:"flex",justifyContent:"center"}}><Icon id="sparkles" size={38} color={C.green} strokeWidth={1.3}/></div>
      <div style={{color:C.greenBright,fontWeight:700,fontSize:16,marginBottom:8}}>Reading your transactions…</div>
      <div style={{color:C.muted,fontSize:13,lineHeight:1.6}}>Looking for patterns and opportunities specific to your spending. Takes a few seconds.</div>
      <div style={{display:"flex",justifyContent:"center",gap:6,marginTop:16}}>{[0,1,2,3].map(i=><div key={i} style={{width:8,height:8,borderRadius:"50%",background:C.green,opacity:.3+i*.2}}/>)}</div>
    </Card>}
    {insights.length>0&&<>
      <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,fontWeight:700}}>Your Personalized Insights</div>
      {insights.map((ins,i)=>{
        const tc=typeColors[ins.type]||C.blue;
        return <Card key={i} glow={tc} style={{border:`1px solid ${tc}33`}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
            <div style={{display:"flex",gap:10,alignItems:"center"}}>
              <div style={{width:40,height:40,borderRadius:12,background:tc+"18",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}><Icon id={txnIcon(ins)} size={18} color={tc} strokeWidth={1.5}/></div>
              <div style={{color:tc,fontWeight:800,fontSize:15}}>{ins.title}</div>
            </div>
            <Chip label={ins.priority} color={{high:C.red,medium:C.gold,low:C.green}[ins.priority]||C.green}/>
          </div>
          <div style={{color:C.mutedHi,fontSize:14,lineHeight:1.65,marginBottom:12}}>{ins.body}</div>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <Chip label={ins.type} color={tc}/>
            {ins.saving!=="—"&&<Chip label={`💰 ${ins.saving}`} color={C.green}/>}
          </div>
        </Card>;
      })}
      <button onClick={generateInsights} style={{background:"none",border:`1px solid ${C.border}`,borderRadius:13,padding:"12px 24px",color:C.muted,fontWeight:600,fontSize:13,cursor:"pointer",fontFamily:"inherit",transition:"all .2s"}}
        onMouseEnter={e=>e.currentTarget.style.borderColor=C.green} onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
        🔄 Refresh Analysis
      </button>
    </>}
  </div>;
}

// ─── CREDIT SCORE ─────────────────────────────────────────────────────────────
function CreditScreen({data}){
  const [tab,setTab]=useState("overview");
  const rawScore=data.profile?.creditScore||680;
  const known=data.profile?.creditKnown;
  const totalDebt=(data.debts||[]).reduce((a,d)=>a+parseFloat(d.balance||0),0);
  const creditLimit=totalDebt>0?totalDebt/0.74:4600; // back-calculate from ~74% util
  const utilPct=totalDebt>0?Math.round(totalDebt/creditLimit*100):0;
  // Estimate score from utilization if not known
  const score=known?rawScore:Math.max(580,750-Math.round(utilPct*1.2));
  const scoreColor=score>=750?C.green:score>=700?C.teal:score>=650?C.gold:score>=600?C.orange:C.red;
  const scoreTier=score>=750?"Excellent":score>=700?"Very Good":score>=650?"Good":score>=600?"Fair":"Needs Work";
  const scoreIcon=score>=750?"🌟":score>=700?"👍":score>=650?"✓":score>=600?"⚠️":"🔧";
  const pct=Math.round((score-300)/600*100);
  // Credit factors
  const factors=[
    {name:"Payment History",weight:"35%",status:score>=700?"Good":"Fair",tip:"No missed payments detected from your connected accounts.",color:score>=700?C.green:C.gold,icon:"calendar"},
    {name:"Credit Utilization",weight:"30%",status:utilPct>70?"High":utilPct>30?"Fair":"Good",tip:utilPct>30?`Your ${data.debts?.[0]?.name||"credit card"} is at ${utilPct}% utilization. Pay it to $${Math.round(creditLimit*0.29).toLocaleString()} to drop below 30% and potentially gain 20–40 points.`:"You're under 30% utilization — this factor is helping your score.",color:utilPct>70?C.red:utilPct>30?C.gold:C.green,icon:"💳"},
    {name:"Credit Age",weight:"15%",status:"Good",tip:"Longer account history helps. Avoid closing old accounts even if unused.",color:C.teal,icon:"🕐"},
    {name:"Credit Mix",weight:"10%",status:"Good",tip:"Having both revolving (cards) and installment (loans) credit helps.",color:C.blue,icon:"🔀"},
    {name:"New Credit",weight:"10%",status:"Good",tip:"No recent hard inquiries detected. Every application causes a small temporary dip.",color:C.green,icon:"🆕"},
  ];
  // Score history (simulated trend)
  const history=[
    {month:"Oct",score:score-45},{month:"Nov",score:score-28},{month:"Dec",score:score-15},
    {month:"Jan",score:score-8},{month:"Feb",score:score-3},{month:"Now",score},
  ];
  const hMin=Math.min(...history.map(h=>h.score))-10;
  const hMax=Math.max(...history.map(h=>h.score))+10;
  const hNorm=history.map(h=>80-((h.score-hMin)/(hMax-hMin))*60);
  // Improvement tips
  const tips=[
    utilPct>30&&{icon:"card",title:`Lower your ${data.debts?.[0]?.name||"credit card"} utilization`,body:`You're at ${utilPct}% utilization. Pay it down to $${Math.round(creditLimit*0.29).toLocaleString()} (29%) to potentially gain 20–40 points within 30–60 days. This is the single fastest improvement you can make.`,impact:"High",points:"+20–40 pts"},
    {icon:"calendar",title:"Keep paying on time",body:"Payment history is 35% of your score. One missed payment can drop your score 80–100 points and takes 2 years to fully recover. Set up autopay for at least the minimum on every account.",impact:"Critical",points:"Protect +100"},
    {icon:"shield",title:"Don't apply for new credit right now",body:"Every credit application is a hard pull. Each one temporarily drops your score 5–10 points. Space applications at least 6 months apart.",impact:"Medium",points:"Prevent –10"},
    {icon:"bank",title:"Don't close old accounts",body:"Closing an account reduces your available credit (raises utilization) and shortens your average account age. Keep old cards open even if unused.",impact:"Medium",points:"Prevent –15"},
    score<720&&{icon:"chartUp",title:"Consider a credit builder product",body:"If you're rebuilding, a secured card or credit builder loan from a credit union reports positive payment history every month. Some people add 50–80 points in a year.",impact:"High",points:"+50–80 pts in 1yr"},
  ].filter(Boolean);

  return <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <div style={{fontSize:22,fontWeight:800,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif"}}>Credit Score</div>
    <div style={{display:"flex",gap:6}}>
      {["overview","factors","improve","connect"].map(t=><button key={t} onClick={()=>setTab(t)} style={{flex:1,background:tab===t?scoreColor+"22":C.cardAlt,border:`1px solid ${tab===t?scoreColor:C.border}`,color:tab===t?scoreColor:C.muted,borderRadius:10,padding:"8px 0",cursor:"pointer",fontSize:11,fontWeight:700,fontFamily:"inherit"}}>
        {t==="overview"?"Score":t==="factors"?"Factors":t==="improve"?"Improve":"Connect"}
      </button>)}
    </div>

    {tab==="overview"&&<>
      {!known&&<div style={{background:C.goldDim,borderRadius:14,padding:"12px 16px",border:`1px solid ${C.gold}44`}}>
        <div style={{color:C.goldBright,fontWeight:700,fontSize:13,marginBottom:4}}>📊 Estimated score</div>
        <div style={{color:C.mutedHi,fontSize:12,lineHeight:1.5}}>Based on your debt utilization. Add your real score in Settings for precise coaching.</div>
      </div>}
      <div style={{background:`linear-gradient(135deg,${scoreColor}18 0%,${C.card} 100%)`,borderRadius:20,padding:"24px 22px",border:`1px solid ${scoreColor}44`,textAlign:"center"}}>
        <div style={{fontSize:64,fontWeight:900,fontFamily:"Georgia,serif",color:scoreColor,lineHeight:1}}>{score}</div>
        <Chip label={`${scoreIcon} ${scoreTier}`} color={scoreColor} size={14}/>
        <div style={{color:C.muted,fontSize:12,marginTop:10,marginBottom:20}}>Out of 900 · {known?"Entered by you":"Estimated"}</div>
        <div style={{background:"rgba(255,255,255,0.06)",borderRadius:99,height:10,overflow:"hidden",position:"relative",marginBottom:8}}>
          {[{pct:16.7,color:C.red},{pct:16.7,color:C.orange},{pct:16.7,color:C.gold},{pct:16.7,color:C.teal},{pct:16.6,color:C.greenBright},{pct:16.6,color:C.green}].reduce((acc,seg)=>{
            const segments=[...acc.segs,<div key={acc.pos} style={{position:"absolute",left:`${acc.pos}%`,width:`${seg.pct}%`,height:"100%",background:seg.color,opacity:.35}}/>];
            return{pos:acc.pos+seg.pct,segs:segments};
          },{pos:0,segs:[]}).segs}
          <div style={{position:"absolute",left:`${pct-1}%`,top:-2,width:4,height:14,borderRadius:99,background:scoreColor,boxShadow:`0 0 8px ${scoreColor}`,transition:"left 1s cubic-bezier(.4,0,.2,1)"}}/>
        </div>
        <div style={{display:"flex",justifyContent:"space-between"}}>{["300","Poor","Fair","Good","V.Good","Excel","900"].map((l,i)=><span key={i} style={{color:C.muted,fontSize:9}}>{l}</span>)}</div>
      </div>
      <Card>
        <div style={{color:C.cream,fontWeight:700,marginBottom:12}}>6-Month Trend</div>
        <svg width="100%" height="50" viewBox={`0 0 ${history.length*50} 100`} preserveAspectRatio="none" style={{display:"block"}}>
          <defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={scoreColor} stopOpacity="0.3"/><stop offset="100%" stopColor={scoreColor} stopOpacity="0"/></linearGradient></defs>
          <polyline points={hNorm.map((y,i)=>`${i*50},${y}`).join(" ")} fill="none" stroke={scoreColor} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          <polygon points={`0,100 ${hNorm.map((y,i)=>`${i*50},${y}`).join(" ")} ${(history.length-1)*50},100`} fill="url(#cg)"/>
          {hNorm.map((y,i)=><circle key={i} cx={i*50} cy={y} r={i===hNorm.length-1?5:2.5} fill={i===hNorm.length-1?scoreColor:scoreColor}/>)}
        </svg>
        <div style={{display:"flex",justifyContent:"space-between",marginTop:4}}>{history.map((h,i)=><div key={i} style={{textAlign:"center"}}><div style={{color:C.muted,fontSize:9}}>{h.month}</div><div style={{color:i===history.length-1?scoreColor:C.muted,fontSize:9,fontWeight:i===history.length-1?700:400}}>{h.score}</div></div>)}</div>
      </Card>
      <Card style={{background:C.greenDim,border:`1px solid ${C.green}33`}}>
        <div style={{color:C.greenBright,fontWeight:700,marginBottom:6}}>What your score unlocks</div>
        {[[750,"Prime mortgage rates (save $100s/mo)","🏠"],[720,"Best credit card rewards & 0% offers","💳"],[700,"Low-rate car loans","🚗"],[680,"Most approvals, standard rates","✓"],[650,"Limited options, higher rates","⚠️"]].map(([sc,txt,icon],i)=>(
          <div key={i} style={{display:"flex",gap:10,padding:"7px 0",borderBottom:i<4?`1px solid ${C.border}`:"none",opacity:score>=sc?1:.45}}>
            <span style={{fontSize:14}}>{icon}</span>
            <span style={{flex:1,color:score>=sc?C.cream:C.muted,fontSize:13}}>{txt}</span>
            <span style={{color:score>=sc?C.green:C.muted,fontWeight:700,fontSize:12}}>{sc}+</span>
          </div>
        ))}
      </Card>
    </>}

    {tab==="factors"&&factors.map((f,i)=>(
      <Card key={i} style={{border:`1px solid ${f.color}33`}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            <div style={{width:40,height:40,borderRadius:12,background:f.color+"22",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>{f.icon}</div>
            <div><div style={{color:C.cream,fontWeight:700,fontSize:14}}>{f.name}</div><div style={{color:C.muted,fontSize:11}}>Weight: {f.weight}</div></div>
          </div>
          <Chip label={f.status} color={f.color}/>
        </div>
        <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.6}}>{f.tip}</div>
      </Card>
    ))}

    {tab==="improve"&&<>
      <Card style={{background:`linear-gradient(135deg,${scoreColor}18 0%,${C.card} 100%)`,border:`1px solid ${scoreColor}44`}}>
        <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.2}}>Your score today</div>
        <div style={{fontSize:32,fontWeight:900,color:scoreColor,fontFamily:"Georgia,serif"}}>{score} <span style={{color:C.muted,fontSize:14,fontWeight:400}}>→</span> <span style={{color:C.greenBright}}>750+</span></div>
        <div style={{color:C.muted,fontSize:12,marginTop:4}}>Estimated with consistent action: 6–18 months</div>
      </Card>
      {tips.map((tip,i)=>(
        <Card key={i} style={{border:`1px solid ${tip.impact==="Critical"?C.red:tip.impact==="High"?C.gold:C.blue}33`}}>
          <div style={{display:"flex",gap:10,alignItems:"flex-start",marginBottom:10}}>
            <span style={{fontSize:24}}>{tip.icon}</span>
            <div style={{flex:1}}><div style={{color:C.cream,fontWeight:700,fontSize:14}}>{tip.title}</div></div>
            <Chip label={tip.points} color={tip.impact==="Critical"?C.green:tip.impact==="High"?C.gold:C.blue}/>
          </div>
          <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.6}}>{tip.body}</div>
          <div style={{marginTop:8}}><Chip label={`Priority: ${tip.impact}`} color={tip.impact==="Critical"?C.red:tip.impact==="High"?C.gold:C.blue}/></div>
        </Card>
      ))}
    </>}

    {tab==="connect"&&<div style={{display:"flex",flexDirection:"column",gap:12}}>
      <Card style={{background:C.tealDim,border:`1px solid ${C.teal}44`}}>
        <div style={{color:C.tealBright,fontWeight:700,marginBottom:8}}>🔗 Live Credit Monitoring</div>
        <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.6,marginBottom:12}}>Connect a credit monitoring service to get your real score updated monthly, with automatic coaching when it changes.</div>
        <div style={{color:C.muted,fontSize:11}}>All connections are soft-pull only. Your score will not be affected.</div>
      </Card>
      {[
        {name:"Borrowell",flag:"🇨🇦",bureau:"Equifax",freq:"Weekly updates",desc:"Canada's most popular free credit score service. Uses Equifax. Free AI-powered product recommendations.",color:"#2E8B57",available:true},
        {name:"Credit Karma",flag:"🇨🇦🇺🇸",bureau:"TransUnion + Equifax",freq:"Weekly updates",desc:"Available in both Canada and the US. Uses TransUnion primarily. Free with detailed factor breakdown.",color:"#00D672",available:true},
        {name:"Experian",flag:"🇺🇸",bureau:"Experian",freq:"Monthly updates",desc:"US only. Provides your FICO Score directly from Experian. Most lenders use FICO for approval decisions.",color:"#3F4DE0",available:true},
        {name:"Plaid (via bank)",flag:"🏦",bureau:"Auto-detected",freq:"Real-time",desc:"If your bank shares credit data via Plaid, Flourish can pull your score directly. Already connected if your bank supports it.",color:C.blue,available:false},
      ].map(provider=>(
        <div key={provider.name} style={{background:C.card,borderRadius:16,padding:"16px 18px",border:`1px solid ${C.border}`}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
            <div style={{display:"flex",gap:10,alignItems:"center"}}>
              <div style={{width:44,height:44,borderRadius:12,background:provider.color+"22",border:`1px solid ${provider.color}44`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22}}>{provider.flag}</div>
              <div><div style={{color:C.cream,fontWeight:700}}>{provider.name}</div><div style={{color:C.muted,fontSize:11}}>{provider.bureau} · {provider.freq}</div></div>
            </div>
            {provider.available?<Chip label="Free" color={C.green}/>:<Chip label="Coming soon" color={C.muted}/>}
          </div>
          <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.55,marginBottom:12}}>{provider.desc}</div>
          <Btn label={provider.available?`Connect ${provider.name} →`:"Notify me when available"} onClick={()=>{}} color={provider.available?provider.color:C.muted} small disabled={!provider.available}/>
        </div>
      ))}
      <Card style={{background:C.goldDim,border:`1px solid ${C.gold}44`}}>
        <div style={{color:C.gold,fontWeight:700,marginBottom:6}}>💡 Why connect?</div>
        <div style={{color:C.mutedHi,fontSize:13,lineHeight:1.65}}>Right now, Flourish estimates your score from your debt data. A live connection means: real score, real alerts when it changes, and coaching that triggers automatically when your utilization spikes or a payment is missed.</div>
      </Card>
    </div>}
  </div>;
}

// ─── SETTINGS ─────────────────────────────────────────────────────────────────
function Settings({data,onClose,onReset}){
  const [notifToggles,setNotifToggles]=useState({overdraft:true,bills:true,coach:true,meeting:false,patterns:true});
  return <div style={{color:C.cream}}>
    <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:20}}>
      <button onClick={onClose} style={{background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,color:C.cream,borderRadius:10,padding:"7px 14px",cursor:"pointer",fontSize:13}}>← Back</button>
      <div style={{fontSize:22,fontWeight:800,color:C.cream,fontFamily:"'Playfair Display',Georgia,serif"}}>Settings</div>
    </div>
    <button onClick={handleShare} style={{background:`linear-gradient(135deg,${C.green},#1A3D2A)`,borderRadius:18,padding:"16px 20px",border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"space-between",fontFamily:"inherit",width:"100%",marginBottom:10}}>
      <div style={{display:"flex",alignItems:"center",gap:12}}>
        <span style={{fontSize:26}}>🌱</span>
        <div style={{textAlign:"left"}}>
          <div style={{color:"#fff",fontWeight:800,fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:15}}>Share Flourish</div>
          <div style={{color:"rgba(255,255,255,0.55)",fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif",marginTop:2}}>Invite a friend · help them thrive</div>
        </div>
      </div>
      <span style={{background:"rgba(255,255,255,0.15)",borderRadius:99,padding:"6px 14px",color:"#fff",fontSize:11,fontWeight:700}}>Share ↗</span>
    </button>
    {[{icon:"user",label:"Profile & Income",sub:`${data.profile.name} · ${data.profile.country}`},{icon:"🏦",label:"Connected Accounts",sub:`${data.accounts?.length||0} accounts`},{icon:"calendar",label:"Manage Bills",sub:`${data.bills?.length||0} tracked`},{icon:"trendUp",label:"Manage Debts",sub:`${data.debts?.length||0} in plan`},{icon:"target",label:"Savings Goals",sub:"Emergency fund & more"},{icon:"users",label:"Family Settings",sub:`${data.profile.status} · ${data.profile.hasKids?"has kids":"no kids"}`}].map((item,i)=>(
      <div key={i} style={{background:C.card,borderRadius:16,padding:"14px 18px",marginBottom:10,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:12,cursor:"pointer",transition:"all .2s"}}
        onMouseEnter={e=>e.currentTarget.style.borderColor=C.borderHi} onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
        <span style={{fontSize:22}}>{item.icon}</span>
        <div style={{flex:1}}><div style={{color:C.cream,fontWeight:600}}>{item.label}</div><div style={{color:C.muted,fontSize:12}}>{item.sub}</div></div>
        <span style={{color:C.muted}}>›</span>
      </div>
    ))}
    <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,fontWeight:700,marginTop:20,marginBottom:10}}>Notifications</div>
    {[["overdraft","zap","Overdraft warnings"],["bills","calendar","Bill due soon alerts"],["coach","sparkles","AI coach insights"],["meeting","users","Money meeting reminders"],["patterns","chartUp","Spending pattern alerts"]].map(([key,icon,label])=>(
      <div key={key} style={{background:C.card,borderRadius:14,padding:"13px 16px",marginBottom:8,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:12}}>
        <span style={{fontSize:20}}>{icon}</span>
        <div style={{color:C.cream,fontSize:14,flex:1}}>{label}</div>
        <Toggle on={notifToggles[key]} onChange={v=>setNotifToggles(t=>({...t,[key]:v}))}/>
      </div>
    ))}
    <div style={{marginTop:24,padding:"16px",background:C.redDim,borderRadius:16,border:`1px solid ${C.red}33`}}>
      <div style={{color:C.red,fontWeight:700,marginBottom:4}}>Delete All Data</div>
      <div style={{color:C.mutedHi,fontSize:13,marginBottom:12}}>Remove all your financial data from Flourish. This cannot be undone.</div>
      <Btn label="Delete My Data" onClick={()=>{if(window.confirm("Delete all your data? This cannot be undone.")){clearState();window.location.reload();}}} color={C.red} small/>
    </div>
    {onReset&&(
      <button onClick={()=>{if(window.confirm("Reset app and go back to setup?"))onReset();}} style={{width:"100%",marginTop:8,background:"none",border:`1px solid ${C.border}`,borderRadius:14,padding:"11px",fontFamily:"inherit",fontWeight:600,color:C.muted,cursor:"pointer",fontSize:12}}>
        🔄 Reset to onboarding
      </button>
    )}
    <div style={{textAlign:"center",color:C.muted,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",marginTop:12,letterSpacing:0.3}}>
      Flourish v1.0 · flourishmoney.app · © 2026 GrowSmart Inc.
    </div>
  </div>;
}



// ─── DESKTOP SIDEBAR PANEL ────────────────────────────────────────────────────
function DesktopSidebar({data,setScreen}){
  const txns=data.transactions||MOCK_TXN;
  const today=new Date().getDate();
  const soonBills=(data.bills||[]).filter(b=>{const d=parseInt(b.date);return d>=today&&d<=today+10;});
  const investments=(data.accounts||[]).filter(a=>a.type==="investment");
  const totalInvested=investments.reduce((a,i)=>a+(i.balance||0),0);
  const totalGain=investments.reduce((a,i)=>a+(i.gain||0),0);

  return <>
    {/* Investment Portfolio Card */}
    {investments.length>0&&<div style={{background:C.card,borderRadius:20,padding:"20px",border:`1px solid ${C.teal}22`}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
        <div>
          <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>Investment Portfolio</div>
          <div style={{color:C.tealBright,fontWeight:900,fontSize:26,fontFamily:"'Playfair Display',serif",marginTop:3}}>${totalInvested.toLocaleString()}</div>
        </div>
        <div style={{background:C.teal+"18",border:`1px solid ${C.teal}33`,borderRadius:99,padding:"5px 12px",color:C.tealBright,fontSize:11,fontWeight:700}}>+${totalGain.toLocaleString()} total</div>
      </div>
      {investments.map((inv,i)=>(
        <div key={i} style={{background:C.cardAlt,borderRadius:12,padding:"12px 14px",marginBottom:8,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <div style={{color:C.cream,fontWeight:600,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{inv.name}</div>
            <div style={{color:C.muted,fontSize:11,marginTop:2}}>{inv.ticker}</div>
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{color:C.cream,fontWeight:700,fontSize:14}}>${inv.balance?.toLocaleString()}</div>
            <div style={{color:C.greenBright,fontSize:11,fontWeight:600}}>+{inv.gainPct}%</div>
          </div>
        </div>
      ))}
    </div>}

    {/* Upcoming bills */}
    <div style={{background:C.card,borderRadius:20,padding:"20px",border:`1px solid ${C.border}`}}>
      <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600,marginBottom:12}}>Upcoming Bills</div>
      {soonBills.length===0&&<div style={{color:C.muted,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>No bills due in the next 10 days 🎉</div>}
      {soonBills.map((b,i)=>(
        <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 0",borderBottom:i<soonBills.length-1?`1px solid ${C.border}`:"none"}}>
          <div>
            <div style={{color:C.cream,fontSize:13,fontWeight:600,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{b.name}</div>
            <div style={{color:C.muted,fontSize:11}}>Due the {b.date}{b.date==="1"?"st":b.date==="2"?"nd":b.date==="3"?"rd":"th"}</div>
          </div>
          <div style={{color:C.gold,fontWeight:700,fontSize:14}}>${b.amount}</div>
        </div>
      ))}
    </div>

    {/* Recent transactions */}
    <div style={{background:C.card,borderRadius:20,padding:"20px",border:`1px solid ${C.border}`}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
        <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.4,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>Recent Activity</div>
        <button onClick={()=>setScreen("spend")} style={{background:"none",border:"none",color:C.green,fontSize:11,cursor:"pointer",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>See all →</button>
      </div>
      {txns.filter(t=>t.amount>0).slice(0,5).map((t,i)=>(
        <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 0",borderBottom:i<4?`1px solid ${C.border}`:"none"}}>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            <div style={{width:32,height:32,borderRadius:10,background:t.color+"18",display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,flexShrink:0}}>{t.icon}</div>
            <div>
              <div style={{color:C.cream,fontSize:13,fontWeight:600,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{t.name}</div>
              <div style={{color:C.muted,fontSize:11}}>{t.date}</div>
            </div>
          </div>
          <div style={{color:C.cream,fontWeight:700,fontSize:13}}>${t.amount.toFixed(2)}</div>
        </div>
      ))}
    </div>

    {/* AI Coach quick prompt */}
    <div onClick={()=>setScreen("coach")} style={{background:`linear-gradient(135deg,${C.greenDim},${C.card})`,borderRadius:20,padding:"20px",border:`1px solid ${C.green}22`,cursor:"pointer",transition:"all .2s"}} onMouseEnter={e=>{e.currentTarget.style.borderColor=C.green+"44";e.currentTarget.style.transform="translateY(-2px)";}} onMouseLeave={e=>{e.currentTarget.style.borderColor=C.green+"22";e.currentTarget.style.transform="none";}}>
      <div style={{marginBottom:10,display:"flex",justifyContent:"center"}}><Icon id="sparkles" size={26} color={C.green} strokeWidth={1.35}/></div>
      <div style={{color:C.cream,fontWeight:800,fontSize:15,fontFamily:"'Playfair Display',serif",marginBottom:6}}>Ask your AI Coach</div>
      <div style={{color:C.muted,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.6}}>Get personalized advice based on your real transactions and {data.profile?.country==="US"?"401k/IRA":"RRSP/TFSA"} situation.</div>
      <div style={{color:C.green,fontSize:12,fontWeight:700,marginTop:10,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Start coaching session →</div>
    </div>
  </>;
}


// ─── PREMIUM GATE ─────────────────────────────────────────────────────────────
function PremiumGate({feature,desc,onUpgrade}){
  return(
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",textAlign:"center",padding:"60px 20px",gap:20,minHeight:400}}>
      <div style={{width:72,height:72,borderRadius:24,background:`linear-gradient(135deg,${C.purple}30,${C.purple}08)`,border:`1px solid ${C.purple}44`,display:"flex",alignItems:"center",justifyContent:"center"}}><Icon id="sparkles" size={32} color={C.purpleBright} strokeWidth={1.35}/></div>
      <div>
        <div style={{color:C.cream,fontWeight:900,fontSize:22,fontFamily:"'Playfair Display',serif",marginBottom:8}}>{feature}</div>
        <div style={{color:C.muted,fontSize:14,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.7,maxWidth:280}}>{desc}</div>
      </div>
      <div style={{background:C.purpleDim,borderRadius:16,padding:"14px 20px",border:`1px solid ${C.purple}33`,maxWidth:280}}>
        <div style={{color:C.purpleBright,fontWeight:700,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Flourish Plus includes:</div>
        <div style={{marginTop:8,display:"flex",flexDirection:"column",gap:4}}>
          {["AI Coach with real data","Full credit coaching","Tax tips & benefits checker","Investment tracking","Household sharing","Debt simulator"].map((f,i)=>(
            <div key={i} style={{color:C.mutedHi,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",textAlign:"left",display:"flex",alignItems:"center",gap:7}}><Icon id="check" size={14} color={C.green} strokeWidth={2.0}/>{f}</div>
          ))}
        </div>
      </div>
      <button onClick={onUpgrade} style={{background:`linear-gradient(135deg,${C.purple},${C.purpleBright})`,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:15,padding:"14px 36px",borderRadius:99,border:"none",cursor:"pointer",boxShadow:`0 6px 24px ${C.purple}40`}}>
        Unlock Flourish Plus →
      </button>
      <div style={{color:C.muted,fontSize:11,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>7-day free trial · Cancel anytime</div>
    </div>
  );
}

// ─── PAYWALL ──────────────────────────────────────────────────────────────────
function Paywall({onClose,onUpgrade,country}){
  const [selected,setSelected]=useState("annual");
  const isCA=country==="CA";
  const plans={
    annual:{label:"Annual",price:isCA?"$79.99/yr":"$59.99/yr",monthly:isCA?"$6.67/mo":"$5.00/mo",save:"Save 33%",badge:"Best Value"},
    monthly:{label:"Monthly",price:isCA?"$9.99/mo":"$7.99/mo",monthly:null,save:null,badge:null},
  };
  const features=[
    {icon:"sparkles",title:"AI Coach",desc:"Personalized advice from your real transaction data"},
    {icon:"target",title:"Tax Tips & Benefits",desc:isCA?"RRSP, TFSA, CCB, GST credit, Trillium and more":"EITC, Child Tax Credit, 401k, HSA and more"},
    {icon:"shield",title:"Credit Coaching",desc:"Full factor breakdown + improvement plan"},
    {icon:"chartUp",title:"Investment Tracking",desc:isCA?"RRSP, TFSA, Questrade, Wealthsimple":"401k, IRA, Fidelity, Vanguard"},
    {icon:"house2",title:"Household Sharing",desc:"Connect with a partner, track shared goals"},
    {icon:"target",title:"Debt Simulator",desc:"See exactly when you'll be debt-free"},
    {icon:"chartUp",title:"Spending Insights",desc:"AI-powered pattern detection & smart cut suggestions"},
  ];

  return(
    <div style={{background:C.bg,minHeight:"100vh",fontFamily:"'Plus Jakarta Sans',sans-serif",color:C.cream,display:"flex",justifyContent:"center"}}>
      <div style={{width:"100%",maxWidth:430,padding:"24px 20px 60px"}}>
        {/* Header */}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:28}}>
          <div style={{fontSize:20,fontWeight:800,color:C.cream,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"flex",alignItems:"center",gap:7}}><FlourishMark size={21}/><span>Flourish Plus</span></div>
          <button onClick={onClose} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:10,padding:"7px 14px",color:C.muted,fontSize:13,cursor:"pointer",fontFamily:"inherit"}}>✕ Maybe Later</button>
        </div>

        {/* Hero */}
        <div style={{textAlign:"center",marginBottom:28}}>
          <div style={{marginBottom:10,display:"flex",justifyContent:"center"}}><Icon id="sparkles" size={40} color={C.purpleBright} strokeWidth={1.3}/></div>
          <div style={{fontFamily:"'Playfair Display',serif",fontWeight:900,fontSize:28,color:C.cream,marginBottom:8,lineHeight:1.2}}>Unlock your full financial picture</div>
          <div style={{color:C.muted,fontSize:14,lineHeight:1.7}}>Everything in free, plus the tools that actually change your finances.</div>
        </div>

        {/* Plan selector */}
        <div style={{display:"flex",gap:10,marginBottom:20}}>
          {Object.entries(plans).map(([key,plan])=>(
            <button key={key} onClick={()=>setSelected(key)} style={{flex:1,background:selected===key?C.purple+"22":C.card,border:`2px solid ${selected===key?C.purple:C.border}`,borderRadius:16,padding:"14px 12px",cursor:"pointer",textAlign:"center",position:"relative",transition:"all .2s"}}>
              {plan.badge&&<div style={{position:"absolute",top:-10,left:"50%",transform:"translateX(-50%)",background:C.purple,color:"#fff",fontSize:9,fontWeight:800,borderRadius:99,padding:"3px 10px",whiteSpace:"nowrap"}}>{plan.badge}</div>}
              <div style={{color:selected===key?C.purpleBright:C.muted,fontWeight:700,fontSize:12,marginBottom:4,fontFamily:"inherit"}}>{plan.label}</div>
              <div style={{color:selected===key?C.cream:C.mutedHi,fontWeight:900,fontSize:18,fontFamily:"'Playfair Display',serif"}}>{plan.price}</div>
              {plan.monthly&&<div style={{color:C.muted,fontSize:11,marginTop:2}}>{plan.monthly} · billed annually</div>}
              {plan.save&&<div style={{color:C.greenBright,fontSize:10,fontWeight:700,marginTop:4}}>{plan.save}</div>}
            </button>
          ))}
        </div>

        {/* Features list */}
        <div style={{display:"flex",flexDirection:"column",gap:10,marginBottom:24}}>
          {features.map((f,i)=>(
            <div key={i} style={{display:"flex",gap:12,alignItems:"flex-start",background:C.card,borderRadius:14,padding:"13px 14px",border:`1px solid ${C.border}`}}>
              <div style={{flexShrink:0,marginTop:2}}><Icon id={f.icon||"sparkles"} size={20} color={C.purpleBright} strokeWidth={1.5}/></div>
              <div>
                <div style={{color:C.cream,fontWeight:700,fontSize:13}}>{f.title}</div>
                <div style={{color:C.muted,fontSize:12,marginTop:2,lineHeight:1.5}}>{f.desc}</div>
              </div>
              <div style={{color:C.green,fontSize:16,flexShrink:0,marginTop:2}}>✓</div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <button onClick={onUpgrade} style={{width:"100%",background:`linear-gradient(135deg,${C.purple} 0%,${C.purpleBright} 100%)`,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:16,padding:"16px",borderRadius:99,border:"none",cursor:"pointer",boxShadow:`0 8px 32px ${C.purple}40`,marginBottom:12}}>
          Start Free 7-Day Trial →
        </button>
        <div style={{textAlign:"center",color:C.muted,fontSize:11,lineHeight:1.7}}>
          7 days free, then {plans[selected].price}. Cancel anytime.<br/>
          Payment processed securely. No hidden fees.
        </div>

        {/* Trust footer */}
        <div style={{marginTop:20,display:"flex",justifyContent:"center",gap:16}}>
          {["🔒 Bank-level security","🇨🇦🇺🇸 Canada & USA","✓ PIPEDA compliant"].map((t,i)=>(
            <div key={i} style={{color:C.muted,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"flex",alignItems:"center",gap:4}}>{t}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── APP ROOT ─────────────────────────────────────────────────────────────────
const NAV=[
  {id:"home",  icon:"home",     label:"Home"},
  {id:"plan",  icon:"calendar", label:"Plan"},
  {id:"spend", icon:"card",     label:"Spend"},
  {id:"coach", icon:"sparkles", label:"Coach"},
  {id:"family",icon:"users",    label:"Family"},
];

// ── PERSISTENCE HELPERS ───────────────────────────────────────────────────────
const STORAGE_KEY = "flourish_v1";
function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}
function saveState(patch) {
  try {
    const cur = loadState() || {};
    localStorage.setItem(STORAGE_KEY, JSON.stringify({...cur, ...patch}));
  } catch {}
}
function clearState() {
  try { localStorage.removeItem(STORAGE_KEY); } catch {}
}

export default function FlourishApp(){
  // ── Hydrate from localStorage on first render ──────────────────
  const saved = loadState();
  const [onboarded,setOnboarded]=useState(()=>saved?.onboarded||false);
  const [appData,setAppData]=useState(()=>saved?.appData||null);
  const [screen,setScreen]=useState("home");
  const [showNotifs,setShowNotifs]=useState(false);
  const [showSettings,setShowSettings]=useState(false);
  const [household,setHousehold]=useState(()=>saved?.household||null);
  const [isPremium,setIsPremium]=useState(()=>saved?.isPremium||false);
  const [showPaywall,setShowPaywall]=useState(false);
  const [checkInBonus,setCheckInBonus]=useState(()=>saved?.checkInBonus||0);
  const [showCheckIn,setShowCheckIn]=useState(false);
  const [showWhatIf,setShowWhatIf]=useState(false);
  const [showWrapped,setShowWrapped]=useState(false);
  const [isOnline,setIsOnline]=useState(()=>navigator.onLine);
  const {w}=useWindowSize();
  const isDesktop=w>=960;

  // ── Persist state changes to localStorage ──────────────────────
  useEffect(()=>{ saveState({onboarded,appData,household,isPremium,checkInBonus}); },
    [onboarded,appData,household,isPremium,checkInBonus]);

  // ── Online/offline detection ────────────────────────────────────
  useEffect(()=>{
    const on=()=>setIsOnline(true);
    const off=()=>setIsOnline(false);
    window.addEventListener("online",on);
    window.addEventListener("offline",off);
    return()=>{window.removeEventListener("online",on);window.removeEventListener("offline",off);};
  },[]);

  // ── Offline banner (shown as overlay, not blocking) ───────────
  // rendered inside the main shell below

  if(showWrapped)return <MoneyWrapped data={appData||{}} onClose={()=>setShowWrapped(false)}/>;
  if(showWhatIf)return <WhatIfSimulator data={appData||{}} onClose={()=>setShowWhatIf(false)}/>;
  if(showCheckIn)return <WeeklyCheckInModal data={appData||{}} onClose={()=>setShowCheckIn(false)} onComplete={(pts)=>{setCheckInBonus(prev=>Math.min(20,prev+pts));setShowCheckIn(false);}}/>;
  if(!onboarded)return <Onboarding onComplete={d=>{setAppData(d);setOnboarded(true);}}/>;
  if(showPaywall)return <Paywall onClose={()=>setShowPaywall(false)} onUpgrade={()=>{setIsPremium(true);setShowPaywall(false);}} country={appData?.profile?.country||"CA"}/>;

  const unread=INIT_NOTIFS.filter(n=>!n.read).length;
  const dataWithHousehold={...appData,household,isPremium};

  // ── Pass isOnline down to AICoach + reset helper ──────────────
  const handleReset = () => { clearState(); window.location.reload(); };

  const content=()=>{
    if(showNotifs)return <Notifications onClose={()=>setShowNotifs(false)}/>;
    if(showSettings)return <Settings data={appData} onClose={()=>setShowSettings(false)} onReset={handleReset}/>;
    if(screen==="home")return <Dashboard data={dataWithHousehold} setScreen={setScreen} setShowNotifs={setShowNotifs} isDesktop={isDesktop} onUpgrade={()=>setShowPaywall(true)} checkInBonus={checkInBonus} onCheckIn={()=>setShowCheckIn(true)} onWhatIf={()=>setShowWhatIf(true)} onWrapped={()=>setShowWrapped(true)}/>;
    if(screen==="plan")return <PlanAhead data={dataWithHousehold}/>;
    if(screen==="spend")return <SpendScreen data={dataWithHousehold}/>;
    if(screen==="coach")return isPremium?<AICoach data={dataWithHousehold} isOnline={isOnline}/>:<PremiumGate feature="AI Coach" desc="Get personalized coaching from your real transaction data." onUpgrade={()=>setShowPaywall(true)}/>;
    if(screen==="family")return <Family data={dataWithHousehold} household={household} setHousehold={setHousehold}/>;
    if(screen==="goals")return <Goals data={dataWithHousehold} onUpgrade={()=>setShowPaywall(true)}/>;
    if(screen==="credit")return isPremium?<CreditScreen data={dataWithHousehold}/>:<PremiumGate feature="Credit Coaching" desc="Full credit score breakdown, factor analysis, and a personalized improvement plan." onUpgrade={()=>setShowPaywall(true)}/>;
    return <Dashboard data={dataWithHousehold} setScreen={setScreen} setShowNotifs={setShowNotifs} isDesktop={isDesktop} onUpgrade={()=>setShowPaywall(true)} checkInBonus={checkInBonus} onCheckIn={()=>setShowCheckIn(true)} onWhatIf={()=>setShowWhatIf(true)} onWrapped={()=>setShowWrapped(true)}/>;
  };

  const ALL_NAV=[
    {id:"home",icon:"◈",label:"Home"},
    {id:"plan",icon:"🗓",label:"Plan"},
    {id:"spend",icon:"💳",label:"Spend"},
    {id:"coach",icon:"sparkles",label:"Coach"},
    {id:"family",icon:"👪",label:"Family"},
    {id:"goals",icon:"chartUp",label:"Goals"},
  ];

  const globalStyles=`
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
@keyframes fadeUp    { from{opacity:0;transform:translateY(22px)}  to{opacity:1;transform:translateY(0)} }
@keyframes fadeIn    { from{opacity:0}                              to{opacity:1} }
@keyframes slideUp   { from{opacity:0;transform:translateY(10px)}  to{opacity:1;transform:translateY(0)} }
@keyframes slideIn   { from{opacity:0;transform:translateX(-14px)} to{opacity:1;transform:translateX(0)} }
@keyframes pulse     { 0%,100%{opacity:1} 50%{opacity:0.45} }
@keyframes shimmer   { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
@keyframes mintGlow  { 0%,100%{box-shadow:0 0 0 0 rgba(0,214,143,0)} 50%{box-shadow:0 0 60px 8px rgba(0,214,143,0.12)} }
@keyframes goldGlow  { 0%,100%{box-shadow:0 0 0 0 rgba(240,196,66,0)} 50%{box-shadow:0 0 60px 8px rgba(240,196,66,0.10)} }
@keyframes ringPulse { 0%{transform:scale(1);opacity:0.7} 100%{transform:scale(2.4);opacity:0} }
@keyframes floatUp   { 0%{transform:translateY(0)} 50%{transform:translateY(-4px)} 100%{transform:translateY(0)} }
@keyframes numberIn  { from{opacity:0;transform:translateY(8px) scale(0.97)} to{opacity:1;transform:translateY(0) scale(1)} }
@keyframes gradShift { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
* { -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale; box-sizing:border-box; }
::-webkit-scrollbar { width:0; background:transparent; }
input,button,select,textarea { font-family:inherit; }
    input[type=range]{-webkit-appearance:none;appearance:none;background:transparent}
    input[type=range]::-webkit-slider-runnable-track{background:rgba(255,255,255,0.08);border-radius:99px;height:6px}
    input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;margin-top:-4px;width:16px;height:16px;border-radius:50%;background:var(--thumb-color,#00D68F);cursor:pointer;box-shadow:0 0 8px var(--thumb-color,#00D68F)66}
    input[type=range]:focus{outline:none}
    ::selection{background:rgba(0,214,143,0.25);color:#EDE8E1}
    body{background:#060A0E}
`
  if(isDesktop) return (
    <div style={{background:C.bg,minHeight:"100vh",fontFamily:"'Plus Jakarta Sans',sans-serif",color:C.cream,display:"flex"}}>
      <style dangerouslySetInnerHTML={{__html:globalStyles}}/>

      {/* ── DESKTOP SIDEBAR ─────────────────────────────────────────── */}
      <div style={{width:240,minHeight:"100vh",background:C.surface,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",position:"sticky",top:0,height:"100vh",flexShrink:0}}>
        {/* Logo */}
        <div style={{padding:"28px 24px 20px"}}>
          <button onClick={()=>{setShowNotifs(false);setShowSettings(false);setScreen("home");}} style={{background:"none",border:"none",cursor:"pointer",padding:0,display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:38,height:38,borderRadius:12,background:"rgba(0,214,143,0.10)",border:"1px solid rgba(0,214,143,0.25)",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 2px 8px rgba(0,0,0,0.12)"}}><FlourishMark size={24}/></div>
            <span style={{fontSize:22,fontWeight:800,color:C.cream,fontFamily:"'Plus Jakarta Sans',sans-serif",letterSpacing:-0.3}}>flourish</span>
          </button>
          {appData&&<div style={{color:C.muted,fontSize:11,marginTop:8,fontFamily:"'Plus Jakarta Sans',sans-serif",paddingLeft:2}}>{CC[appData.profile?.country||"CA"]?.flag} {CC[appData.profile?.country||"CA"]?.name} · {CC[appData.profile?.country||"CA"]?.currency}</div>}
        </div>

        {/* Nav items */}
        <div style={{flex:1,padding:"0 12px",display:"flex",flexDirection:"column",gap:2}}>
          {ALL_NAV.map(n=>{
            const active=(screen===n.id||(n.id==="goals"&&screen==="credit"))&&!showNotifs&&!showSettings;
            return(
              <button key={n.id} className="nav-item" onClick={()=>{setShowNotifs(false);setShowSettings(false);setScreen(n.id);}}
                style={{background:active?C.green+"18":"transparent",border:`1px solid ${active?C.green+"33":"transparent"}`,borderRadius:12,padding:"11px 16px",cursor:"pointer",display:"flex",alignItems:"center",gap:12,color:active?C.greenBright:C.muted,fontWeight:active?700:400,fontSize:14,fontFamily:"'Plus Jakarta Sans',sans-serif",transition:"all .18s",textAlign:"left",width:"100%"}}>
                <Icon id={n.icon} size={17} color={active?C.greenBright:C.muted} strokeWidth={active?1.9:1.4}/>
                {n.label}
                {n.id==="home"&&unread>0&&<div style={{marginLeft:"auto",width:18,height:18,borderRadius:99,background:C.red,color:"#fff",fontSize:9,fontWeight:800,display:"flex",alignItems:"center",justifyContent:"center"}}>{unread}</div>}
              </button>
            );
          })}
        </div>

        {/* Sidebar footer */}
        <div style={{padding:"16px 12px",borderTop:`1px solid ${C.border}`}}>
          {appData&&<div style={{background:C.card,borderRadius:12,padding:"12px 14px",marginBottom:8}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:32,height:32,borderRadius:99,background:C.green+"22",border:`1px solid ${C.green}33`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14}}><Icon id="user" size={15} color={C.green} strokeWidth={1.5}/></div>
              <div>
                <div style={{color:C.cream,fontWeight:700,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{appData.profile?.name||"User"}</div>
                {household&&<div style={{color:C.green,fontSize:10,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>🏠 Household connected</div>}
              </div>
            </div>
          </div>}
          <button onClick={()=>{setShowNotifs(false);setShowSettings(true);}}
            style={{width:"100%",background:"none",border:`1px solid ${C.border}`,borderRadius:10,padding:"9px 14px",cursor:"pointer",color:C.muted,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"flex",alignItems:"center",gap:8,transition:"all .18s"}}
            onMouseEnter={e=>{e.currentTarget.style.borderColor=C.borderHi;e.currentTarget.style.color=C.cream;}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor=C.border;e.currentTarget.style.color=C.muted;}}>
            Settings
          </button>
        </div>
      </div>

      {/* ── DESKTOP MAIN CONTENT ────────────────────────────────────── */}
      <div style={{flex:1,minHeight:"100vh",display:"flex",flexDirection:"column",maxWidth:"calc(100vw - 240px)"}}>
        {/* Top bar */}
        <div style={{padding:"20px 36px 16px",background:`${C.bg}F8`,backdropFilter:"blur(12px)",position:"sticky",top:0,zIndex:20,display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:`1px solid ${C.border}`}}>
          <div>
            <div style={{color:C.cream,fontWeight:700,fontSize:18,fontFamily:"'Playfair Display',serif"}}>
              {showNotifs?"Notifications":showSettings?"Settings":screen==="home"?"Dashboard":screen==="plan"?"Plan Ahead":screen==="spend"?"Spending":screen==="coach"?"AI Coach":screen==="family"?"Family":screen==="goals"||screen==="credit"?"Goals & Wealth":"Dashboard"}
            </div>
            <div style={{color:C.muted,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",marginTop:2}}>{new Date().toLocaleDateString(CC[appData?.profile?.country||"CA"]?.locale||"en-CA",{weekday:"long",month:"long",day:"numeric"})}</div>
          </div>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            {household&&<div style={{background:C.green+"18",border:`1px solid ${C.green}33`,borderRadius:99,padding:"6px 14px",color:C.greenBright,fontSize:12,fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:600}}>🏠 Household #{household.code}</div>}
            <button onClick={()=>{setShowSettings(false);setShowNotifs(true);}} style={{position:"relative",background:C.card,border:`1px solid ${unread>0?C.red+"55":C.border}`,borderRadius:12,padding:"10px 14px",cursor:"pointer",fontSize:18,transition:"all .18s"}} onMouseEnter={e=>e.currentTarget.style.borderColor=C.borderHi} onMouseLeave={e=>e.currentTarget.style.borderColor=unread>0?C.red+"55":C.border}>
              <Icon id="bell" size={18} color={C.mutedHi} strokeWidth={1.5}/>
              {unread>0&&<div style={{position:"absolute",top:-4,right:-4,width:18,height:18,borderRadius:99,background:C.red,color:"#fff",fontSize:9,fontWeight:800,display:"flex",alignItems:"center",justifyContent:"center"}}>{unread}</div>}
            </button>
          </div>
        </div>

        {/* Two-column for home, single for others */}
        {screen==="home"&&!showNotifs&&!showSettings?(
          <div style={{display:"grid",gridTemplateColumns:"1fr 380px",gap:28,padding:"28px 36px 40px",overflowY:"auto",flex:1}}>
            <div><Dashboard data={dataWithHousehold} setScreen={setScreen} setShowNotifs={setShowNotifs} isDesktop={true} checkInBonus={checkInBonus} onCheckIn={()=>setShowCheckIn(true)} onWhatIf={()=>setShowWhatIf(true)} onWrapped={()=>setShowWrapped(true)}/></div>
            <div style={{display:"flex",flexDirection:"column",gap:16}}>
              <DesktopSidebar data={dataWithHousehold} setScreen={setScreen}/>
            </div>
          </div>
        ):(
          <div style={{flex:1,padding:"28px 36px 40px",overflowY:"auto",maxWidth:860}}>
            {content()}
          </div>
        )}
      </div>
    </div>
  );

  // ── MOBILE LAYOUT ────────────────────────────────────────────────────────
  return(
    <div style={{background:C.bg,minHeight:"100vh",fontFamily:"'Plus Jakarta Sans',sans-serif",color:C.cream,display:"flex",justifyContent:"center"}}>
      <style dangerouslySetInnerHTML={{__html:globalStyles}}/>
      {/* Ambient mesh background */}
      <div style={{position:"fixed",inset:0,pointerEvents:"none",zIndex:0,overflow:"hidden"}}>
        <div style={{position:"absolute",top:-200,left:-200,width:600,height:600,borderRadius:"50%",background:"radial-gradient(circle,rgba(0,214,143,0.04) 0%,transparent 70%)"}}/>
        <div style={{position:"absolute",bottom:-150,right:-150,width:500,height:500,borderRadius:"50%",background:"radial-gradient(circle,rgba(155,125,255,0.04) 0%,transparent 70%)"}}/>
      </div>
      <div style={{width:"100%",maxWidth:430,minHeight:"100vh",display:"flex",flexDirection:"column",position:"relative",zIndex:1}}>
        {/* ── OFFLINE BANNER ─────────────────────────── */}
        {!isOnline&&(
          <div style={{position:"fixed",top:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,zIndex:9999,background:"#180800",borderBottom:`2px solid ${C.orange}44`,padding:"9px 20px",display:"flex",alignItems:"center",gap:10}}>
            <span style={{fontSize:14}}>📡</span>
            <span style={{color:C.goldBright,fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:12,fontWeight:700}}>Offline — AI features paused. Your data is saved.</span>
          </div>
        )}
        <div style={{padding:"14px 20px 12px",background:"rgba(6,10,14,0.85)",backdropFilter:"blur(24px)",WebkitBackdropFilter:"blur(24px)",position:"sticky",top:0,zIndex:30,display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
          <button onClick={()=>{setShowNotifs(false);setShowSettings(false);setScreen("home");}} style={{display:"flex",alignItems:"center",gap:9,background:"none",border:"none",cursor:"pointer",padding:0}}>
            <FlourishMark size={22}/>
            <span style={{fontFamily:"'Plus Jakarta Sans',sans-serif",fontWeight:800,fontSize:17,color:C.cream,letterSpacing:-0.3}}>flourish</span>
          </button>
          <div style={{display:"flex",gap:8}}>
            <button onClick={()=>{setShowSettings(false);setShowNotifs(true);}} style={{position:"relative",background:"rgba(255,255,255,0.07)",border:`1px solid ${unread>0?C.red+"55":C.border}`,borderRadius:12,padding:"8px 12px",cursor:"pointer"}}>
              <Icon id="bell" size={17} color={unread>0?C.redBright:C.mutedHi} strokeWidth={1.5}/>
              {unread>0&&<div style={{position:"absolute",top:-4,right:-4,width:17,height:17,borderRadius:99,background:C.red,color:"#fff",fontSize:9,fontWeight:800,display:"flex",alignItems:"center",justifyContent:"center",boxShadow:`0 0 8px ${C.red}88`}}>{unread}</div>}
            </button>
            <button onClick={()=>{setShowNotifs(false);setShowSettings(true);}} style={{background:"rgba(255,255,255,0.07)",border:`1px solid ${C.border}`,borderRadius:12,padding:"8px 12px",cursor:"pointer"}}><Icon id="settings" size={17} color={C.mutedHi} strokeWidth={1.5}/></button>
          </div>
        </div>
        <div style={{flex:1,padding:"16px 18px 120px",overflowY:"auto",overscrollBehavior:"contain"}}>{content()}</div>
        {!showNotifs&&!showSettings&&(
          {/* Floating pill nav */}
          <div style={{position:"fixed",bottom:20,left:"50%",transform:"translateX(-50%)",zIndex:50,width:"calc(100% - 48px)",maxWidth:382}}>
            <div style={{background:"rgba(15,23,32,0.92)",backdropFilter:"blur(28px)",WebkitBackdropFilter:"blur(28px)",borderRadius:28,border:"1px solid rgba(255,255,255,0.10)",boxShadow:"0 8px 40px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.07)",padding:"8px 10px",display:"flex",justifyContent:"space-around"}}>
            {ALL_NAV.map(n=>{
              const active=(screen===n.id||(n.id==="goals"&&screen==="credit"))&&!showNotifs&&!showSettings;
              return(
                <button key={n.id} onClick={()=>{setShowNotifs(false);setShowSettings(false);setScreen(n.id);}} style={{background:"none",border:"none",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:4,padding:"4px 10px",borderRadius:20,transition:"all .22s"}}>
                  <div style={{width:38,height:28,borderRadius:14,
                    background:active?`linear-gradient(135deg,${C.green}30,${C.teal}18)`:"transparent",
                    display:"flex",alignItems:"center",justifyContent:"center",
                    transition:"all .22s",
                    boxShadow:active?`0 0 14px ${C.green}33`:"none"}}>
                    <Icon id={n.icon} size={18} color={active?C.greenBright:C.muted} strokeWidth={active?2:1.4}/>
                  </div>
                  <span style={{fontSize:9,fontWeight:active?800:500,fontFamily:"'Plus Jakarta Sans',sans-serif",color:active?C.greenBright:C.muted,letterSpacing:active?0.2:0,transition:"all .22s"}}>{n.label}</span>
                </button>
              );
            })}
            </div>
          </div>
          </div>
        )}
      </div>
    </div>
  );
}
